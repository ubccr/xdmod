-- MySQL dump 10.19  Distrib 10.3.35-MariaDB, for Linux (aarch64)
--
-- Host: localhost    Database: modw_filters
-- ------------------------------------------------------
-- Server version	10.3.35-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `modw_filters`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `modw_filters` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `modw_filters`;

--
-- Table structure for table `Cloud_configuration`
--

DROP TABLE IF EXISTS `Cloud_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_configuration` (
  `configuration` varchar(256) NOT NULL,
  PRIMARY KEY (`configuration`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_configuration`
--

LOCK TABLES `Cloud_configuration` WRITE;
/*!40000 ALTER TABLE `Cloud_configuration` DISABLE KEYS */;
INSERT INTO `Cloud_configuration` VALUES ('c1.m1'),('c1.m4'),('c2.m4'),('c2.m8'),('c4.m16'),('g1.v100x-16q'),('g1.v100x-4q'),('g1.v100x-8q'),('m1.large'),('m1.medium'),('m1.quad'),('m1.small'),('m1.tiny'),('m1.xlarge'),('m1.xxlarge'),('m2.medium'),('p1.cda170011'),('p1.phy140033'),('s1.large'),('s1.xlarge'),('s1.xxlarge');
/*!40000 ALTER TABLE `Cloud_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_configuration___person`
--

DROP TABLE IF EXISTS `Cloud_configuration___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_configuration___person` (
  `configuration` varchar(256) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`configuration`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_configuration___person`
--

LOCK TABLES `Cloud_configuration___person` WRITE;
/*!40000 ALTER TABLE `Cloud_configuration___person` DISABLE KEYS */;
INSERT INTO `Cloud_configuration___person` VALUES ('c1.m1',128),('c1.m1',130),('c1.m1',131),('c1.m4',128),('c1.m4',131),('c2.m4',128),('c2.m4',130),('c2.m8',128),('c4.m16',128),('c4.m16',130),('g1.v100x-16q',289),('g1.v100x-4q',289),('g1.v100x-8q',289),('g1.v100x-8q',290),('g1.v100x-8q',291),('g1.v100x-8q',292),('g1.v100x-8q',293),('m1.large',138),('m1.large',139),('m1.large',140),('m1.large',142),('m1.large',144),('m1.large',145),('m1.large',149),('m1.large',155),('m1.large',156),('m1.large',158),('m1.large',162),('m1.large',168),('m1.large',176),('m1.large',214),('m1.large',231),('m1.large',247),('m1.large',256),('m1.large',262),('m1.large',264),('m1.large',286),('m1.large',295),('m1.large',303),('m1.large',304),('m1.large',305),('m1.large',328),('m1.large',339),('m1.large',371),('m1.large',394),('m1.large',437),('m1.large',441),('m1.large',459),('m1.large',466),('m1.large',474),('m1.large',477),('m1.medium',138),('m1.medium',141),('m1.medium',142),('m1.medium',144),('m1.medium',145),('m1.medium',146),('m1.medium',155),('m1.medium',158),('m1.medium',159),('m1.medium',162),('m1.medium',163),('m1.medium',168),('m1.medium',170),('m1.medium',171),('m1.medium',172),('m1.medium',174),('m1.medium',179),('m1.medium',180),('m1.medium',181),('m1.medium',183),('m1.medium',193),('m1.medium',194),('m1.medium',196),('m1.medium',200),('m1.medium',201),('m1.medium',206),('m1.medium',207),('m1.medium',209),('m1.medium',211),('m1.medium',216),('m1.medium',218),('m1.medium',221),('m1.medium',225),('m1.medium',226),('m1.medium',227),('m1.medium',234),('m1.medium',237),('m1.medium',239),('m1.medium',240),('m1.medium',241),('m1.medium',243),('m1.medium',246),('m1.medium',247),('m1.medium',249),('m1.medium',256),('m1.medium',267),('m1.medium',268),('m1.medium',269),('m1.medium',271),('m1.medium',272),('m1.medium',273),('m1.medium',274),('m1.medium',277),('m1.medium',281),('m1.medium',285),('m1.medium',297),('m1.medium',298),('m1.medium',301),('m1.medium',303),('m1.medium',309),('m1.medium',311),('m1.medium',314),('m1.medium',317),('m1.medium',318),('m1.medium',321),('m1.medium',322),('m1.medium',326),('m1.medium',340),('m1.medium',342),('m1.medium',347),('m1.medium',348),('m1.medium',349),('m1.medium',358),('m1.medium',359),('m1.medium',364),('m1.medium',369),('m1.medium',371),('m1.medium',372),('m1.medium',375),('m1.medium',378),('m1.medium',380),('m1.medium',382),('m1.medium',387),('m1.medium',389),('m1.medium',395),('m1.medium',396),('m1.medium',399),('m1.medium',405),('m1.medium',406),('m1.medium',408),('m1.medium',410),('m1.medium',411),('m1.medium',412),('m1.medium',413),('m1.medium',416),('m1.medium',417),('m1.medium',418),('m1.medium',422),('m1.medium',423),('m1.medium',424),('m1.medium',427),('m1.medium',428),('m1.medium',429),('m1.medium',432),('m1.medium',444),('m1.medium',445),('m1.medium',447),('m1.medium',449),('m1.medium',455),('m1.medium',465),('m1.medium',468),('m1.medium',471),('m1.medium',473),('m1.quad',134),('m1.quad',159),('m1.quad',169),('m1.quad',170),('m1.quad',222),('m1.quad',226),('m1.quad',232),('m1.quad',235),('m1.quad',270),('m1.quad',288),('m1.quad',344),('m1.quad',401),('m1.quad',419),('m1.quad',435),('m1.small',130),('m1.small',133),('m1.small',134),('m1.small',136),('m1.small',141),('m1.small',142),('m1.small',144),('m1.small',146),('m1.small',149),('m1.small',150),('m1.small',158),('m1.small',159),('m1.small',163),('m1.small',166),('m1.small',167),('m1.small',168),('m1.small',170),('m1.small',175),('m1.small',177),('m1.small',178),('m1.small',179),('m1.small',182),('m1.small',193),('m1.small',196),('m1.small',203),('m1.small',206),('m1.small',208),('m1.small',215),('m1.small',216),('m1.small',220),('m1.small',222),('m1.small',223),('m1.small',229),('m1.small',232),('m1.small',235),('m1.small',236),('m1.small',237),('m1.small',239),('m1.small',242),('m1.small',243),('m1.small',245),('m1.small',247),('m1.small',248),('m1.small',252),('m1.small',253),('m1.small',254),('m1.small',256),('m1.small',257),('m1.small',258),('m1.small',259),('m1.small',260),('m1.small',261),('m1.small',266),('m1.small',275),('m1.small',276),('m1.small',280),('m1.small',281),('m1.small',284),('m1.small',285),('m1.small',307),('m1.small',312),('m1.small',313),('m1.small',315),('m1.small',323),('m1.small',324),('m1.small',327),('m1.small',341),('m1.small',346),('m1.small',347),('m1.small',350),('m1.small',352),('m1.small',354),('m1.small',355),('m1.small',356),('m1.small',361),('m1.small',367),('m1.small',368),('m1.small',376),('m1.small',379),('m1.small',384),('m1.small',385),('m1.small',389),('m1.small',397),('m1.small',400),('m1.small',401),('m1.small',402),('m1.small',404),('m1.small',409),('m1.small',420),('m1.small',421),('m1.small',425),('m1.small',431),('m1.small',448),('m1.small',454),('m1.small',456),('m1.small',462),('m1.small',475),('m1.tiny',134),('m1.tiny',135),('m1.tiny',137),('m1.tiny',139),('m1.tiny',143),('m1.tiny',149),('m1.tiny',150),('m1.tiny',151),('m1.tiny',152),('m1.tiny',153),('m1.tiny',161),('m1.tiny',163),('m1.tiny',165),('m1.tiny',173),('m1.tiny',185),('m1.tiny',186),('m1.tiny',187),('m1.tiny',188),('m1.tiny',189),('m1.tiny',190),('m1.tiny',191),('m1.tiny',197),('m1.tiny',203),('m1.tiny',204),('m1.tiny',206),('m1.tiny',208),('m1.tiny',217),('m1.tiny',220),('m1.tiny',222),('m1.tiny',233),('m1.tiny',236),('m1.tiny',238),('m1.tiny',239),('m1.tiny',243),('m1.tiny',251),('m1.tiny',255),('m1.tiny',263),('m1.tiny',265),('m1.tiny',278),('m1.tiny',279),('m1.tiny',282),('m1.tiny',287),('m1.tiny',297),('m1.tiny',300),('m1.tiny',308),('m1.tiny',310),('m1.tiny',312),('m1.tiny',316),('m1.tiny',319),('m1.tiny',325),('m1.tiny',327),('m1.tiny',330),('m1.tiny',331),('m1.tiny',332),('m1.tiny',333),('m1.tiny',334),('m1.tiny',335),('m1.tiny',338),('m1.tiny',345),('m1.tiny',353),('m1.tiny',360),('m1.tiny',374),('m1.tiny',387),('m1.tiny',388),('m1.tiny',392),('m1.tiny',403),('m1.tiny',407),('m1.tiny',430),('m1.tiny',438),('m1.tiny',439),('m1.tiny',443),('m1.tiny',446),('m1.tiny',457),('m1.tiny',458),('m1.tiny',460),('m1.tiny',461),('m1.tiny',463),('m1.tiny',464),('m1.tiny',467),('m1.xlarge',138),('m1.xlarge',142),('m1.xlarge',158),('m1.xlarge',162),('m1.xlarge',210),('m1.xlarge',250),('m1.xlarge',302),('m1.xlarge',366),('m1.xlarge',376),('m1.xlarge',383),('m1.xlarge',398),('m1.xlarge',433),('m1.xlarge',436),('m1.xlarge',469),('m1.xxlarge',140),('m1.xxlarge',142),('m1.xxlarge',148),('m1.xxlarge',153),('m1.xxlarge',154),('m1.xxlarge',160),('m1.xxlarge',166),('m1.xxlarge',205),('m1.xxlarge',299),('m1.xxlarge',373),('m2.medium',289),('p1.cda170011',175),('p1.cda170011',386),('p1.phy140033',199),('s1.large',141),('s1.large',155),('s1.large',157),('s1.large',160),('s1.large',162),('s1.large',168),('s1.large',195),('s1.large',212),('s1.large',219),('s1.large',222),('s1.large',230),('s1.large',265),('s1.large',277),('s1.large',348),('s1.large',371),('s1.xlarge',143),('s1.xlarge',159),('s1.xlarge',193),('s1.xlarge',195),('s1.xlarge',244),('s1.xlarge',278),('s1.xlarge',294),('s1.xlarge',295),('s1.xlarge',337),('s1.xlarge',343),('s1.xlarge',377),('s1.xlarge',381),('s1.xlarge',450),('s1.xlarge',472),('s1.xxlarge',153),('s1.xxlarge',154),('s1.xxlarge',172),('s1.xxlarge',202),('s1.xxlarge',212),('s1.xxlarge',228),('s1.xxlarge',286),('s1.xxlarge',299),('s1.xxlarge',336),('s1.xxlarge',362),('s1.xxlarge',365),('s1.xxlarge',426);
/*!40000 ALTER TABLE `Cloud_configuration___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_configuration___pi`
--

DROP TABLE IF EXISTS `Cloud_configuration___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_configuration___pi` (
  `configuration` varchar(256) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`configuration`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_configuration___pi`
--

LOCK TABLES `Cloud_configuration___pi` WRITE;
/*!40000 ALTER TABLE `Cloud_configuration___pi` DISABLE KEYS */;
INSERT INTO `Cloud_configuration___pi` VALUES ('c1.m1',102),('c1.m4',102),('c2.m4',102),('c2.m8',102),('c4.m16',102),('g1.v100x-16q',-1),('g1.v100x-4q',-1),('g1.v100x-8q',-1),('m1.large',-1),('m1.large',15),('m1.medium',-1),('m1.medium',15),('m1.medium',79),('m1.medium',102),('m1.quad',-1),('m1.small',-1),('m1.small',15),('m1.small',79),('m1.small',102),('m1.tiny',-1),('m1.tiny',15),('m1.tiny',79),('m1.tiny',102),('m1.xlarge',-1),('m1.xlarge',15),('m1.xxlarge',-1),('m1.xxlarge',15),('m2.medium',-1),('p1.cda170011',-1),('p1.phy140033',-1),('s1.large',-1),('s1.large',102),('s1.xlarge',-1),('s1.xlarge',15),('s1.xlarge',79),('s1.xxlarge',-1),('s1.xxlarge',15),('s1.xxlarge',102);
/*!40000 ALTER TABLE `Cloud_configuration___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_configuration___provider`
--

DROP TABLE IF EXISTS `Cloud_configuration___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_configuration___provider` (
  `configuration` varchar(256) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`configuration`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_configuration___provider`
--

LOCK TABLES `Cloud_configuration___provider` WRITE;
/*!40000 ALTER TABLE `Cloud_configuration___provider` DISABLE KEYS */;
INSERT INTO `Cloud_configuration___provider` VALUES ('c1.m1',1),('c1.m4',1),('c2.m4',1),('c2.m8',1),('c4.m16',1),('g1.v100x-16q',1),('g1.v100x-4q',1),('g1.v100x-8q',1),('m1.large',1),('m1.medium',1),('m1.quad',1),('m1.small',1),('m1.tiny',1),('m1.xlarge',1),('m1.xxlarge',1),('m2.medium',1),('p1.cda170011',1),('p1.phy140033',1),('s1.large',1),('s1.xlarge',1),('s1.xxlarge',1);
/*!40000 ALTER TABLE `Cloud_configuration___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_domain`
--

DROP TABLE IF EXISTS `Cloud_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_domain` (
  `domain` varchar(64) NOT NULL,
  PRIMARY KEY (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_domain`
--

LOCK TABLES `Cloud_domain` WRITE;
/*!40000 ALTER TABLE `Cloud_domain` DISABLE KEYS */;
INSERT INTO `Cloud_domain` VALUES ('adjunct'),('Default'),('tacc');
/*!40000 ALTER TABLE `Cloud_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_domain___person`
--

DROP TABLE IF EXISTS `Cloud_domain___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_domain___person` (
  `domain` varchar(64) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`domain`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_domain___person`
--

LOCK TABLES `Cloud_domain___person` WRITE;
/*!40000 ALTER TABLE `Cloud_domain___person` DISABLE KEYS */;
INSERT INTO `Cloud_domain___person` VALUES ('adjunct',150),('adjunct',153),('adjunct',173),('adjunct',260),('adjunct',376),('Default',128),('Default',130),('Default',131),('Default',136),('Default',137),('Default',139),('Default',140),('Default',142),('Default',143),('Default',144),('Default',146),('Default',148),('Default',149),('Default',154),('Default',155),('Default',157),('Default',159),('Default',160),('Default',161),('Default',162),('Default',165),('Default',167),('Default',169),('Default',171),('Default',172),('Default',174),('Default',176),('Default',177),('Default',180),('Default',181),('Default',182),('Default',183),('Default',193),('Default',195),('Default',196),('Default',197),('Default',200),('Default',202),('Default',204),('Default',205),('Default',206),('Default',207),('Default',208),('Default',209),('Default',210),('Default',211),('Default',212),('Default',214),('Default',217),('Default',219),('Default',220),('Default',221),('Default',223),('Default',225),('Default',226),('Default',227),('Default',228),('Default',229),('Default',230),('Default',231),('Default',232),('Default',233),('Default',234),('Default',236),('Default',237),('Default',238),('Default',239),('Default',240),('Default',241),('Default',244),('Default',245),('Default',246),('Default',248),('Default',250),('Default',251),('Default',252),('Default',253),('Default',254),('Default',255),('Default',257),('Default',258),('Default',261),('Default',262),('Default',263),('Default',264),('Default',265),('Default',266),('Default',267),('Default',268),('Default',269),('Default',271),('Default',272),('Default',273),('Default',274),('Default',276),('Default',277),('Default',278),('Default',279),('Default',280),('Default',282),('Default',284),('Default',286),('Default',287),('Default',294),('Default',297),('Default',298),('Default',300),('Default',301),('Default',302),('Default',304),('Default',305),('Default',307),('Default',308),('Default',310),('Default',311),('Default',312),('Default',313),('Default',314),('Default',315),('Default',316),('Default',317),('Default',318),('Default',319),('Default',321),('Default',322),('Default',323),('Default',324),('Default',325),('Default',326),('Default',327),('Default',328),('Default',330),('Default',331),('Default',332),('Default',333),('Default',334),('Default',335),('Default',336),('Default',338),('Default',339),('Default',340),('Default',341),('Default',343),('Default',345),('Default',346),('Default',347),('Default',348),('Default',349),('Default',350),('Default',352),('Default',353),('Default',354),('Default',355),('Default',356),('Default',358),('Default',359),('Default',360),('Default',361),('Default',362),('Default',364),('Default',365),('Default',367),('Default',368),('Default',369),('Default',371),('Default',372),('Default',373),('Default',374),('Default',377),('Default',378),('Default',380),('Default',381),('Default',382),('Default',383),('Default',384),('Default',385),('Default',387),('Default',388),('Default',389),('Default',392),('Default',394),('Default',396),('Default',397),('Default',398),('Default',399),('Default',400),('Default',401),('Default',402),('Default',403),('Default',404),('Default',405),('Default',406),('Default',407),('Default',409),('Default',410),('Default',412),('Default',413),('Default',416),('Default',417),('Default',418),('Default',419),('Default',420),('Default',421),('Default',422),('Default',423),('Default',425),('Default',426),('Default',427),('Default',428),('Default',429),('Default',430),('Default',431),('Default',432),('Default',433),('Default',436),('Default',437),('Default',438),('Default',439),('Default',441),('Default',443),('Default',444),('Default',445),('Default',447),('Default',448),('Default',449),('Default',450),('Default',454),('Default',455),('Default',456),('Default',457),('Default',458),('Default',459),('Default',460),('Default',461),('Default',462),('Default',463),('Default',464),('Default',466),('Default',467),('Default',468),('Default',469),('Default',471),('Default',472),('Default',473),('Default',474),('Default',475),('Default',477),('tacc',133),('tacc',134),('tacc',135),('tacc',138),('tacc',141),('tacc',142),('tacc',144),('tacc',145),('tacc',146),('tacc',149),('tacc',151),('tacc',152),('tacc',156),('tacc',158),('tacc',160),('tacc',163),('tacc',166),('tacc',168),('tacc',170),('tacc',175),('tacc',178),('tacc',179),('tacc',185),('tacc',186),('tacc',187),('tacc',188),('tacc',189),('tacc',190),('tacc',191),('tacc',194),('tacc',199),('tacc',201),('tacc',203),('tacc',215),('tacc',216),('tacc',218),('tacc',222),('tacc',235),('tacc',242),('tacc',243),('tacc',247),('tacc',249),('tacc',256),('tacc',259),('tacc',270),('tacc',275),('tacc',277),('tacc',281),('tacc',285),('tacc',288),('tacc',289),('tacc',290),('tacc',291),('tacc',292),('tacc',293),('tacc',295),('tacc',299),('tacc',303),('tacc',309),('tacc',321),('tacc',327),('tacc',337),('tacc',342),('tacc',344),('tacc',366),('tacc',375),('tacc',379),('tacc',386),('tacc',395),('tacc',408),('tacc',411),('tacc',424),('tacc',427),('tacc',435),('tacc',446),('tacc',465);
/*!40000 ALTER TABLE `Cloud_domain___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_domain___pi`
--

DROP TABLE IF EXISTS `Cloud_domain___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_domain___pi` (
  `domain` varchar(64) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`domain`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_domain___pi`
--

LOCK TABLES `Cloud_domain___pi` WRITE;
/*!40000 ALTER TABLE `Cloud_domain___pi` DISABLE KEYS */;
INSERT INTO `Cloud_domain___pi` VALUES ('adjunct',-1),('adjunct',102),('Default',-1),('Default',15),('Default',79),('Default',102),('tacc',-1);
/*!40000 ALTER TABLE `Cloud_domain___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_domain___provider`
--

DROP TABLE IF EXISTS `Cloud_domain___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_domain___provider` (
  `domain` varchar(64) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`domain`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_domain___provider`
--

LOCK TABLES `Cloud_domain___provider` WRITE;
/*!40000 ALTER TABLE `Cloud_domain___provider` DISABLE KEYS */;
INSERT INTO `Cloud_domain___provider` VALUES ('adjunct',1),('Default',1),('tacc',1);
/*!40000 ALTER TABLE `Cloud_domain___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_fieldofscience`
--

DROP TABLE IF EXISTS `Cloud_fieldofscience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_fieldofscience` (
  `fieldofscience` int(11) NOT NULL,
  PRIMARY KEY (`fieldofscience`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_fieldofscience`
--

LOCK TABLES `Cloud_fieldofscience` WRITE;
/*!40000 ALTER TABLE `Cloud_fieldofscience` DISABLE KEYS */;
INSERT INTO `Cloud_fieldofscience` VALUES (1),(59),(91),(115);
/*!40000 ALTER TABLE `Cloud_fieldofscience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_fieldofscience___person`
--

DROP TABLE IF EXISTS `Cloud_fieldofscience___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_fieldofscience___person` (
  `fieldofscience` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`fieldofscience`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_fieldofscience___person`
--

LOCK TABLES `Cloud_fieldofscience___person` WRITE;
/*!40000 ALTER TABLE `Cloud_fieldofscience___person` DISABLE KEYS */;
INSERT INTO `Cloud_fieldofscience___person` VALUES (1,133),(1,134),(1,135),(1,136),(1,137),(1,138),(1,140),(1,141),(1,142),(1,143),(1,144),(1,145),(1,146),(1,148),(1,149),(1,150),(1,151),(1,152),(1,153),(1,155),(1,156),(1,157),(1,158),(1,159),(1,160),(1,161),(1,162),(1,163),(1,165),(1,166),(1,167),(1,168),(1,169),(1,170),(1,171),(1,172),(1,173),(1,174),(1,175),(1,176),(1,177),(1,178),(1,179),(1,180),(1,181),(1,182),(1,183),(1,185),(1,186),(1,187),(1,188),(1,189),(1,190),(1,191),(1,193),(1,194),(1,195),(1,196),(1,197),(1,199),(1,200),(1,201),(1,202),(1,203),(1,205),(1,206),(1,207),(1,208),(1,209),(1,211),(1,212),(1,215),(1,216),(1,217),(1,218),(1,220),(1,221),(1,222),(1,223),(1,225),(1,226),(1,227),(1,230),(1,231),(1,232),(1,233),(1,234),(1,235),(1,236),(1,238),(1,239),(1,240),(1,241),(1,242),(1,243),(1,246),(1,247),(1,248),(1,249),(1,250),(1,251),(1,252),(1,253),(1,254),(1,255),(1,256),(1,257),(1,258),(1,259),(1,261),(1,262),(1,263),(1,264),(1,265),(1,266),(1,267),(1,268),(1,269),(1,270),(1,271),(1,272),(1,273),(1,274),(1,275),(1,276),(1,277),(1,278),(1,279),(1,281),(1,282),(1,285),(1,286),(1,287),(1,288),(1,289),(1,290),(1,291),(1,292),(1,293),(1,295),(1,297),(1,298),(1,299),(1,300),(1,301),(1,302),(1,303),(1,304),(1,305),(1,307),(1,308),(1,309),(1,310),(1,311),(1,312),(1,313),(1,314),(1,315),(1,316),(1,317),(1,318),(1,319),(1,321),(1,324),(1,325),(1,326),(1,327),(1,328),(1,331),(1,332),(1,333),(1,334),(1,336),(1,337),(1,338),(1,339),(1,341),(1,342),(1,343),(1,344),(1,345),(1,346),(1,347),(1,348),(1,349),(1,350),(1,352),(1,354),(1,355),(1,356),(1,358),(1,359),(1,360),(1,361),(1,362),(1,364),(1,365),(1,366),(1,367),(1,368),(1,369),(1,371),(1,372),(1,373),(1,374),(1,375),(1,376),(1,377),(1,378),(1,379),(1,381),(1,382),(1,383),(1,384),(1,385),(1,386),(1,387),(1,388),(1,389),(1,392),(1,394),(1,395),(1,396),(1,397),(1,398),(1,399),(1,400),(1,401),(1,403),(1,404),(1,405),(1,406),(1,407),(1,408),(1,409),(1,410),(1,411),(1,412),(1,413),(1,416),(1,418),(1,419),(1,420),(1,422),(1,423),(1,424),(1,425),(1,426),(1,427),(1,428),(1,429),(1,430),(1,432),(1,433),(1,435),(1,436),(1,437),(1,438),(1,439),(1,441),(1,443),(1,444),(1,445),(1,446),(1,447),(1,448),(1,449),(1,450),(1,454),(1,455),(1,456),(1,457),(1,458),(1,459),(1,460),(1,461),(1,462),(1,463),(1,464),(1,465),(1,466),(1,467),(1,468),(1,469),(1,471),(1,472),(1,473),(1,474),(1,475),(1,477),(59,139),(59,154),(59,210),(59,214),(59,245),(59,280),(59,294),(59,427),(59,431),(91,128),(91,130),(91,131),(91,204),(91,219),(91,228),(91,229),(91,237),(91,260),(91,284),(91,322),(91,353),(91,380),(91,402),(91,417),(91,421),(115,244),(115,323),(115,330),(115,335),(115,340);
/*!40000 ALTER TABLE `Cloud_fieldofscience___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_fieldofscience___pi`
--

DROP TABLE IF EXISTS `Cloud_fieldofscience___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_fieldofscience___pi` (
  `fieldofscience` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`fieldofscience`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_fieldofscience___pi`
--

LOCK TABLES `Cloud_fieldofscience___pi` WRITE;
/*!40000 ALTER TABLE `Cloud_fieldofscience___pi` DISABLE KEYS */;
INSERT INTO `Cloud_fieldofscience___pi` VALUES (1,-1),(59,15),(91,102),(115,79);
/*!40000 ALTER TABLE `Cloud_fieldofscience___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_fieldofscience___provider`
--

DROP TABLE IF EXISTS `Cloud_fieldofscience___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_fieldofscience___provider` (
  `fieldofscience` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`fieldofscience`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_fieldofscience___provider`
--

LOCK TABLES `Cloud_fieldofscience___provider` WRITE;
/*!40000 ALTER TABLE `Cloud_fieldofscience___provider` DISABLE KEYS */;
INSERT INTO `Cloud_fieldofscience___provider` VALUES (1,1),(59,1),(91,1),(115,1);
/*!40000 ALTER TABLE `Cloud_fieldofscience___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_instance_state`
--

DROP TABLE IF EXISTS `Cloud_instance_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_instance_state` (
  `instance_state` int(11) NOT NULL,
  PRIMARY KEY (`instance_state`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_instance_state`
--

LOCK TABLES `Cloud_instance_state` WRITE;
/*!40000 ALTER TABLE `Cloud_instance_state` DISABLE KEYS */;
INSERT INTO `Cloud_instance_state` VALUES (1),(2),(3);
/*!40000 ALTER TABLE `Cloud_instance_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_instance_state___person`
--

DROP TABLE IF EXISTS `Cloud_instance_state___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_instance_state___person` (
  `instance_state` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`instance_state`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_instance_state___person`
--

LOCK TABLES `Cloud_instance_state___person` WRITE;
/*!40000 ALTER TABLE `Cloud_instance_state___person` DISABLE KEYS */;
INSERT INTO `Cloud_instance_state___person` VALUES (1,128),(1,130),(1,131),(1,133),(1,134),(1,135),(1,136),(1,137),(1,138),(1,139),(1,140),(1,141),(1,142),(1,143),(1,144),(1,145),(1,146),(1,148),(1,149),(1,150),(1,151),(1,152),(1,153),(1,154),(1,155),(1,156),(1,157),(1,158),(1,159),(1,160),(1,161),(1,162),(1,163),(1,165),(1,166),(1,167),(1,168),(1,169),(1,170),(1,171),(1,172),(1,173),(1,174),(1,175),(1,176),(1,177),(1,178),(1,179),(1,180),(1,181),(1,182),(1,183),(1,185),(1,186),(1,187),(1,188),(1,190),(1,191),(1,193),(1,194),(1,195),(1,196),(1,197),(1,199),(1,200),(1,201),(1,202),(1,203),(1,204),(1,205),(1,206),(1,207),(1,208),(1,209),(1,210),(1,211),(1,212),(1,214),(1,215),(1,216),(1,217),(1,218),(1,219),(1,220),(1,221),(1,222),(1,223),(1,225),(1,226),(1,227),(1,228),(1,229),(1,230),(1,231),(1,232),(1,233),(1,234),(1,235),(1,236),(1,237),(1,238),(1,239),(1,240),(1,241),(1,242),(1,243),(1,244),(1,245),(1,246),(1,247),(1,248),(1,249),(1,250),(1,251),(1,252),(1,253),(1,254),(1,255),(1,256),(1,257),(1,258),(1,259),(1,260),(1,261),(1,262),(1,263),(1,264),(1,265),(1,266),(1,267),(1,268),(1,269),(1,270),(1,271),(1,272),(1,273),(1,274),(1,275),(1,276),(1,277),(1,278),(1,279),(1,280),(1,281),(1,282),(1,284),(1,285),(1,286),(1,287),(1,288),(1,289),(1,290),(1,291),(1,292),(1,293),(1,294),(1,295),(1,297),(1,298),(1,299),(1,300),(1,301),(1,302),(1,303),(1,304),(1,305),(1,307),(1,308),(1,309),(1,310),(1,311),(1,312),(1,313),(1,314),(1,315),(1,316),(1,317),(1,318),(1,319),(1,321),(1,322),(1,323),(1,324),(1,325),(1,326),(1,327),(1,328),(1,330),(1,331),(1,332),(1,333),(1,334),(1,335),(1,336),(1,337),(1,338),(1,339),(1,340),(1,341),(1,342),(1,343),(1,344),(1,345),(1,346),(1,347),(1,348),(1,349),(1,350),(1,352),(1,353),(1,354),(1,355),(1,356),(1,358),(1,359),(1,360),(1,361),(1,362),(1,364),(1,365),(1,366),(1,367),(1,368),(1,369),(1,371),(1,372),(1,373),(1,374),(1,375),(1,376),(1,377),(1,378),(1,379),(1,380),(1,381),(1,382),(1,383),(1,384),(1,385),(1,386),(1,387),(1,388),(1,389),(1,392),(1,394),(1,395),(1,396),(1,397),(1,398),(1,399),(1,400),(1,401),(1,402),(1,403),(1,404),(1,405),(1,406),(1,407),(1,408),(1,409),(1,410),(1,411),(1,412),(1,413),(1,416),(1,417),(1,418),(1,419),(1,420),(1,421),(1,422),(1,423),(1,424),(1,425),(1,426),(1,427),(1,428),(1,429),(1,430),(1,431),(1,432),(1,433),(1,435),(1,436),(1,437),(1,438),(1,439),(1,441),(1,443),(1,444),(1,445),(1,446),(1,447),(1,448),(1,449),(1,450),(1,454),(1,455),(1,456),(1,457),(1,458),(1,459),(1,460),(1,461),(1,462),(1,463),(1,464),(1,465),(1,466),(1,467),(1,468),(1,469),(1,471),(1,473),(1,474),(1,475),(1,477),(2,128),(2,130),(2,131),(2,135),(2,140),(2,142),(2,144),(2,145),(2,152),(2,154),(2,158),(2,185),(2,186),(2,187),(2,188),(2,189),(2,190),(2,191),(2,193),(2,195),(2,202),(2,208),(2,222),(2,247),(2,262),(2,305),(2,307),(2,325),(2,449),(2,466),(2,472),(2,477),(3,181),(3,182),(3,222),(3,466),(3,475),(3,477);
/*!40000 ALTER TABLE `Cloud_instance_state___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_instance_state___pi`
--

DROP TABLE IF EXISTS `Cloud_instance_state___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_instance_state___pi` (
  `instance_state` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`instance_state`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_instance_state___pi`
--

LOCK TABLES `Cloud_instance_state___pi` WRITE;
/*!40000 ALTER TABLE `Cloud_instance_state___pi` DISABLE KEYS */;
INSERT INTO `Cloud_instance_state___pi` VALUES (1,-1),(1,15),(1,79),(1,102),(2,-1),(2,15),(2,102),(3,-1);
/*!40000 ALTER TABLE `Cloud_instance_state___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_instance_state___provider`
--

DROP TABLE IF EXISTS `Cloud_instance_state___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_instance_state___provider` (
  `instance_state` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`instance_state`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_instance_state___provider`
--

LOCK TABLES `Cloud_instance_state___provider` WRITE;
/*!40000 ALTER TABLE `Cloud_instance_state___provider` DISABLE KEYS */;
INSERT INTO `Cloud_instance_state___provider` VALUES (1,1),(2,1),(3,1);
/*!40000 ALTER TABLE `Cloud_instance_state___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_nsfdirectorate`
--

DROP TABLE IF EXISTS `Cloud_nsfdirectorate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_nsfdirectorate` (
  `nsfdirectorate` int(11) NOT NULL,
  PRIMARY KEY (`nsfdirectorate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_nsfdirectorate`
--

LOCK TABLES `Cloud_nsfdirectorate` WRITE;
/*!40000 ALTER TABLE `Cloud_nsfdirectorate` DISABLE KEYS */;
INSERT INTO `Cloud_nsfdirectorate` VALUES (1),(2),(5),(6);
/*!40000 ALTER TABLE `Cloud_nsfdirectorate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_nsfdirectorate___person`
--

DROP TABLE IF EXISTS `Cloud_nsfdirectorate___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_nsfdirectorate___person` (
  `nsfdirectorate` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`nsfdirectorate`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_nsfdirectorate___person`
--

LOCK TABLES `Cloud_nsfdirectorate___person` WRITE;
/*!40000 ALTER TABLE `Cloud_nsfdirectorate___person` DISABLE KEYS */;
INSERT INTO `Cloud_nsfdirectorate___person` VALUES (1,133),(1,134),(1,135),(1,136),(1,137),(1,138),(1,140),(1,141),(1,142),(1,143),(1,144),(1,145),(1,146),(1,148),(1,149),(1,150),(1,151),(1,152),(1,153),(1,155),(1,156),(1,157),(1,158),(1,159),(1,160),(1,161),(1,162),(1,163),(1,165),(1,166),(1,167),(1,168),(1,169),(1,170),(1,171),(1,172),(1,173),(1,174),(1,175),(1,176),(1,177),(1,178),(1,179),(1,180),(1,181),(1,182),(1,183),(1,185),(1,186),(1,187),(1,188),(1,189),(1,190),(1,191),(1,193),(1,194),(1,195),(1,196),(1,197),(1,199),(1,200),(1,201),(1,202),(1,203),(1,205),(1,206),(1,207),(1,208),(1,209),(1,211),(1,212),(1,215),(1,216),(1,217),(1,218),(1,220),(1,221),(1,222),(1,223),(1,225),(1,226),(1,227),(1,230),(1,231),(1,232),(1,233),(1,234),(1,235),(1,236),(1,238),(1,239),(1,240),(1,241),(1,242),(1,243),(1,246),(1,247),(1,248),(1,249),(1,250),(1,251),(1,252),(1,253),(1,254),(1,255),(1,256),(1,257),(1,258),(1,259),(1,261),(1,262),(1,263),(1,264),(1,265),(1,266),(1,267),(1,268),(1,269),(1,270),(1,271),(1,272),(1,273),(1,274),(1,275),(1,276),(1,277),(1,278),(1,279),(1,281),(1,282),(1,285),(1,286),(1,287),(1,288),(1,289),(1,290),(1,291),(1,292),(1,293),(1,295),(1,297),(1,298),(1,299),(1,300),(1,301),(1,302),(1,303),(1,304),(1,305),(1,307),(1,308),(1,309),(1,310),(1,311),(1,312),(1,313),(1,314),(1,315),(1,316),(1,317),(1,318),(1,319),(1,321),(1,324),(1,325),(1,326),(1,327),(1,328),(1,331),(1,332),(1,333),(1,334),(1,336),(1,337),(1,338),(1,339),(1,341),(1,342),(1,343),(1,344),(1,345),(1,346),(1,347),(1,348),(1,349),(1,350),(1,352),(1,354),(1,355),(1,356),(1,358),(1,359),(1,360),(1,361),(1,362),(1,364),(1,365),(1,366),(1,367),(1,368),(1,369),(1,371),(1,372),(1,373),(1,374),(1,375),(1,376),(1,377),(1,378),(1,379),(1,381),(1,382),(1,383),(1,384),(1,385),(1,386),(1,387),(1,388),(1,389),(1,392),(1,394),(1,395),(1,396),(1,397),(1,398),(1,399),(1,400),(1,401),(1,403),(1,404),(1,405),(1,406),(1,407),(1,408),(1,409),(1,410),(1,411),(1,412),(1,413),(1,416),(1,418),(1,419),(1,420),(1,422),(1,423),(1,424),(1,425),(1,426),(1,427),(1,428),(1,429),(1,430),(1,432),(1,433),(1,435),(1,436),(1,437),(1,438),(1,439),(1,441),(1,443),(1,444),(1,445),(1,446),(1,447),(1,448),(1,449),(1,450),(1,454),(1,455),(1,456),(1,457),(1,458),(1,459),(1,460),(1,461),(1,462),(1,463),(1,464),(1,465),(1,466),(1,467),(1,468),(1,469),(1,471),(1,472),(1,473),(1,474),(1,475),(1,477),(2,244),(2,323),(2,330),(2,335),(2,340),(5,128),(5,130),(5,131),(5,204),(5,219),(5,228),(5,229),(5,237),(5,260),(5,284),(5,322),(5,353),(5,380),(5,402),(5,417),(5,421),(6,139),(6,154),(6,210),(6,214),(6,245),(6,280),(6,294),(6,427),(6,431);
/*!40000 ALTER TABLE `Cloud_nsfdirectorate___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_nsfdirectorate___pi`
--

DROP TABLE IF EXISTS `Cloud_nsfdirectorate___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_nsfdirectorate___pi` (
  `nsfdirectorate` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`nsfdirectorate`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_nsfdirectorate___pi`
--

LOCK TABLES `Cloud_nsfdirectorate___pi` WRITE;
/*!40000 ALTER TABLE `Cloud_nsfdirectorate___pi` DISABLE KEYS */;
INSERT INTO `Cloud_nsfdirectorate___pi` VALUES (1,-1),(2,79),(5,102),(6,15);
/*!40000 ALTER TABLE `Cloud_nsfdirectorate___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_nsfdirectorate___provider`
--

DROP TABLE IF EXISTS `Cloud_nsfdirectorate___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_nsfdirectorate___provider` (
  `nsfdirectorate` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`nsfdirectorate`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_nsfdirectorate___provider`
--

LOCK TABLES `Cloud_nsfdirectorate___provider` WRITE;
/*!40000 ALTER TABLE `Cloud_nsfdirectorate___provider` DISABLE KEYS */;
INSERT INTO `Cloud_nsfdirectorate___provider` VALUES (1,1),(2,1),(5,1),(6,1);
/*!40000 ALTER TABLE `Cloud_nsfdirectorate___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_parentscience`
--

DROP TABLE IF EXISTS `Cloud_parentscience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_parentscience` (
  `parentscience` int(11) NOT NULL,
  PRIMARY KEY (`parentscience`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_parentscience`
--

LOCK TABLES `Cloud_parentscience` WRITE;
/*!40000 ALTER TABLE `Cloud_parentscience` DISABLE KEYS */;
INSERT INTO `Cloud_parentscience` VALUES (1),(12),(25),(36);
/*!40000 ALTER TABLE `Cloud_parentscience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_parentscience___person`
--

DROP TABLE IF EXISTS `Cloud_parentscience___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_parentscience___person` (
  `parentscience` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`parentscience`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_parentscience___person`
--

LOCK TABLES `Cloud_parentscience___person` WRITE;
/*!40000 ALTER TABLE `Cloud_parentscience___person` DISABLE KEYS */;
INSERT INTO `Cloud_parentscience___person` VALUES (1,133),(1,134),(1,135),(1,136),(1,137),(1,138),(1,140),(1,141),(1,142),(1,143),(1,144),(1,145),(1,146),(1,148),(1,149),(1,150),(1,151),(1,152),(1,153),(1,155),(1,156),(1,157),(1,158),(1,159),(1,160),(1,161),(1,162),(1,163),(1,165),(1,166),(1,167),(1,168),(1,169),(1,170),(1,171),(1,172),(1,173),(1,174),(1,175),(1,176),(1,177),(1,178),(1,179),(1,180),(1,181),(1,182),(1,183),(1,185),(1,186),(1,187),(1,188),(1,189),(1,190),(1,191),(1,193),(1,194),(1,195),(1,196),(1,197),(1,199),(1,200),(1,201),(1,202),(1,203),(1,205),(1,206),(1,207),(1,208),(1,209),(1,211),(1,212),(1,215),(1,216),(1,217),(1,218),(1,220),(1,221),(1,222),(1,223),(1,225),(1,226),(1,227),(1,230),(1,231),(1,232),(1,233),(1,234),(1,235),(1,236),(1,238),(1,239),(1,240),(1,241),(1,242),(1,243),(1,246),(1,247),(1,248),(1,249),(1,250),(1,251),(1,252),(1,253),(1,254),(1,255),(1,256),(1,257),(1,258),(1,259),(1,261),(1,262),(1,263),(1,264),(1,265),(1,266),(1,267),(1,268),(1,269),(1,270),(1,271),(1,272),(1,273),(1,274),(1,275),(1,276),(1,277),(1,278),(1,279),(1,281),(1,282),(1,285),(1,286),(1,287),(1,288),(1,289),(1,290),(1,291),(1,292),(1,293),(1,295),(1,297),(1,298),(1,299),(1,300),(1,301),(1,302),(1,303),(1,304),(1,305),(1,307),(1,308),(1,309),(1,310),(1,311),(1,312),(1,313),(1,314),(1,315),(1,316),(1,317),(1,318),(1,319),(1,321),(1,324),(1,325),(1,326),(1,327),(1,328),(1,331),(1,332),(1,333),(1,334),(1,336),(1,337),(1,338),(1,339),(1,341),(1,342),(1,343),(1,344),(1,345),(1,346),(1,347),(1,348),(1,349),(1,350),(1,352),(1,354),(1,355),(1,356),(1,358),(1,359),(1,360),(1,361),(1,362),(1,364),(1,365),(1,366),(1,367),(1,368),(1,369),(1,371),(1,372),(1,373),(1,374),(1,375),(1,376),(1,377),(1,378),(1,379),(1,381),(1,382),(1,383),(1,384),(1,385),(1,386),(1,387),(1,388),(1,389),(1,392),(1,394),(1,395),(1,396),(1,397),(1,398),(1,399),(1,400),(1,401),(1,403),(1,404),(1,405),(1,406),(1,407),(1,408),(1,409),(1,410),(1,411),(1,412),(1,413),(1,416),(1,418),(1,419),(1,420),(1,422),(1,423),(1,424),(1,425),(1,426),(1,427),(1,428),(1,429),(1,430),(1,432),(1,433),(1,435),(1,436),(1,437),(1,438),(1,439),(1,441),(1,443),(1,444),(1,445),(1,446),(1,447),(1,448),(1,449),(1,450),(1,454),(1,455),(1,456),(1,457),(1,458),(1,459),(1,460),(1,461),(1,462),(1,463),(1,464),(1,465),(1,466),(1,467),(1,468),(1,469),(1,471),(1,472),(1,473),(1,474),(1,475),(1,477),(12,244),(12,323),(12,330),(12,335),(12,340),(25,139),(25,154),(25,210),(25,214),(25,245),(25,280),(25,294),(25,427),(25,431),(36,128),(36,130),(36,131),(36,204),(36,219),(36,228),(36,229),(36,237),(36,260),(36,284),(36,322),(36,353),(36,380),(36,402),(36,417),(36,421);
/*!40000 ALTER TABLE `Cloud_parentscience___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_parentscience___pi`
--

DROP TABLE IF EXISTS `Cloud_parentscience___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_parentscience___pi` (
  `parentscience` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`parentscience`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_parentscience___pi`
--

LOCK TABLES `Cloud_parentscience___pi` WRITE;
/*!40000 ALTER TABLE `Cloud_parentscience___pi` DISABLE KEYS */;
INSERT INTO `Cloud_parentscience___pi` VALUES (1,-1),(12,79),(25,15),(36,102);
/*!40000 ALTER TABLE `Cloud_parentscience___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_parentscience___provider`
--

DROP TABLE IF EXISTS `Cloud_parentscience___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_parentscience___provider` (
  `parentscience` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`parentscience`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_parentscience___provider`
--

LOCK TABLES `Cloud_parentscience___provider` WRITE;
/*!40000 ALTER TABLE `Cloud_parentscience___provider` DISABLE KEYS */;
INSERT INTO `Cloud_parentscience___provider` VALUES (1,1),(12,1),(25,1),(36,1);
/*!40000 ALTER TABLE `Cloud_parentscience___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_person`
--

DROP TABLE IF EXISTS `Cloud_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_person` (
  `person` int(11) NOT NULL,
  PRIMARY KEY (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_person`
--

LOCK TABLES `Cloud_person` WRITE;
/*!40000 ALTER TABLE `Cloud_person` DISABLE KEYS */;
INSERT INTO `Cloud_person` VALUES (128),(130),(131),(133),(134),(135),(136),(137),(138),(139),(140),(141),(142),(143),(144),(145),(146),(148),(149),(150),(151),(152),(153),(154),(155),(156),(157),(158),(159),(160),(161),(162),(163),(165),(166),(167),(168),(169),(170),(171),(172),(173),(174),(175),(176),(177),(178),(179),(180),(181),(182),(183),(185),(186),(187),(188),(189),(190),(191),(193),(194),(195),(196),(197),(199),(200),(201),(202),(203),(204),(205),(206),(207),(208),(209),(210),(211),(212),(214),(215),(216),(217),(218),(219),(220),(221),(222),(223),(225),(226),(227),(228),(229),(230),(231),(232),(233),(234),(235),(236),(237),(238),(239),(240),(241),(242),(243),(244),(245),(246),(247),(248),(249),(250),(251),(252),(253),(254),(255),(256),(257),(258),(259),(260),(261),(262),(263),(264),(265),(266),(267),(268),(269),(270),(271),(272),(273),(274),(275),(276),(277),(278),(279),(280),(281),(282),(284),(285),(286),(287),(288),(289),(290),(291),(292),(293),(294),(295),(297),(298),(299),(300),(301),(302),(303),(304),(305),(307),(308),(309),(310),(311),(312),(313),(314),(315),(316),(317),(318),(319),(321),(322),(323),(324),(325),(326),(327),(328),(330),(331),(332),(333),(334),(335),(336),(337),(338),(339),(340),(341),(342),(343),(344),(345),(346),(347),(348),(349),(350),(352),(353),(354),(355),(356),(358),(359),(360),(361),(362),(364),(365),(366),(367),(368),(369),(371),(372),(373),(374),(375),(376),(377),(378),(379),(380),(381),(382),(383),(384),(385),(386),(387),(388),(389),(392),(394),(395),(396),(397),(398),(399),(400),(401),(402),(403),(404),(405),(406),(407),(408),(409),(410),(411),(412),(413),(416),(417),(418),(419),(420),(421),(422),(423),(424),(425),(426),(427),(428),(429),(430),(431),(432),(433),(435),(436),(437),(438),(439),(441),(443),(444),(445),(446),(447),(448),(449),(450),(454),(455),(456),(457),(458),(459),(460),(461),(462),(463),(464),(465),(466),(467),(468),(469),(471),(472),(473),(474),(475),(477);
/*!40000 ALTER TABLE `Cloud_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_person___pi`
--

DROP TABLE IF EXISTS `Cloud_person___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_person___pi` (
  `person` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`person`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_person___pi`
--

LOCK TABLES `Cloud_person___pi` WRITE;
/*!40000 ALTER TABLE `Cloud_person___pi` DISABLE KEYS */;
INSERT INTO `Cloud_person___pi` VALUES (128,102),(130,102),(131,102),(133,-1),(134,-1),(135,-1),(136,-1),(137,-1),(138,-1),(139,15),(140,-1),(141,-1),(142,-1),(143,-1),(144,-1),(145,-1),(146,-1),(148,-1),(149,-1),(150,-1),(151,-1),(152,-1),(153,-1),(154,15),(155,-1),(156,-1),(157,-1),(158,-1),(159,-1),(160,-1),(161,-1),(162,-1),(163,-1),(165,-1),(166,-1),(167,-1),(168,-1),(169,-1),(170,-1),(171,-1),(172,-1),(173,-1),(174,-1),(175,-1),(176,-1),(177,-1),(178,-1),(179,-1),(180,-1),(181,-1),(182,-1),(183,-1),(185,-1),(186,-1),(187,-1),(188,-1),(189,-1),(190,-1),(191,-1),(193,-1),(194,-1),(195,-1),(196,-1),(197,-1),(199,-1),(200,-1),(201,-1),(202,-1),(203,-1),(204,102),(205,-1),(206,-1),(207,-1),(208,-1),(209,-1),(210,15),(211,-1),(212,-1),(214,15),(215,-1),(216,-1),(217,-1),(218,-1),(219,102),(220,-1),(221,-1),(222,-1),(223,-1),(225,-1),(226,-1),(227,-1),(228,102),(229,102),(230,-1),(231,-1),(232,-1),(233,-1),(234,-1),(235,-1),(236,-1),(237,102),(238,-1),(239,-1),(240,-1),(241,-1),(242,-1),(243,-1),(244,79),(245,15),(246,-1),(247,-1),(248,-1),(249,-1),(250,-1),(251,-1),(252,-1),(253,-1),(254,-1),(255,-1),(256,-1),(257,-1),(258,-1),(259,-1),(260,102),(261,-1),(262,-1),(263,-1),(264,-1),(265,-1),(266,-1),(267,-1),(268,-1),(269,-1),(270,-1),(271,-1),(272,-1),(273,-1),(274,-1),(275,-1),(276,-1),(277,-1),(278,-1),(279,-1),(280,15),(281,-1),(282,-1),(284,102),(285,-1),(286,-1),(287,-1),(288,-1),(289,-1),(290,-1),(291,-1),(292,-1),(293,-1),(294,15),(295,-1),(297,-1),(298,-1),(299,-1),(300,-1),(301,-1),(302,-1),(303,-1),(304,-1),(305,-1),(307,-1),(308,-1),(309,-1),(310,-1),(311,-1),(312,-1),(313,-1),(314,-1),(315,-1),(316,-1),(317,-1),(318,-1),(319,-1),(321,-1),(322,102),(323,79),(324,-1),(325,-1),(326,-1),(327,-1),(328,-1),(330,79),(331,-1),(332,-1),(333,-1),(334,-1),(335,79),(336,-1),(337,-1),(338,-1),(339,-1),(340,79),(341,-1),(342,-1),(343,-1),(344,-1),(345,-1),(346,-1),(347,-1),(348,-1),(349,-1),(350,-1),(352,-1),(353,102),(354,-1),(355,-1),(356,-1),(358,-1),(359,-1),(360,-1),(361,-1),(362,-1),(364,-1),(365,-1),(366,-1),(367,-1),(368,-1),(369,-1),(371,-1),(372,-1),(373,-1),(374,-1),(375,-1),(376,-1),(377,-1),(378,-1),(379,-1),(380,102),(381,-1),(382,-1),(383,-1),(384,-1),(385,-1),(386,-1),(387,-1),(388,-1),(389,-1),(392,-1),(394,-1),(395,-1),(396,-1),(397,-1),(398,-1),(399,-1),(400,-1),(401,-1),(402,102),(403,-1),(404,-1),(405,-1),(406,-1),(407,-1),(408,-1),(409,-1),(410,-1),(411,-1),(412,-1),(413,-1),(416,-1),(417,102),(418,-1),(419,-1),(420,-1),(421,102),(422,-1),(423,-1),(424,-1),(425,-1),(426,-1),(427,-1),(427,15),(428,-1),(429,-1),(430,-1),(431,15),(432,-1),(433,-1),(435,-1),(436,-1),(437,-1),(438,-1),(439,-1),(441,-1),(443,-1),(444,-1),(445,-1),(446,-1),(447,-1),(448,-1),(449,-1),(450,-1),(454,-1),(455,-1),(456,-1),(457,-1),(458,-1),(459,-1),(460,-1),(461,-1),(462,-1),(463,-1),(464,-1),(465,-1),(466,-1),(467,-1),(468,-1),(469,-1),(471,-1),(472,-1),(473,-1),(474,-1),(475,-1),(477,-1);
/*!40000 ALTER TABLE `Cloud_person___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_person___project`
--

DROP TABLE IF EXISTS `Cloud_person___project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_person___project` (
  `person` int(11) NOT NULL,
  `project` varchar(256) NOT NULL,
  PRIMARY KEY (`person`,`project`),
  KEY `idx_second_dimension` (`project`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_person___project`
--

LOCK TABLES `Cloud_person___project` WRITE;
/*!40000 ALTER TABLE `Cloud_person___project` DISABLE KEYS */;
INSERT INTO `Cloud_person___project` VALUES (128,'zealous'),(130,'zealous'),(131,'zealous'),(133,'TG-IRI180027'),(134,'TG-CDA170008'),(135,'TG-CCR190013'),(136,'julianp'),(137,'alanguye'),(138,'TG-DBS170009'),(139,'yvanpij'),(140,'senxu'),(141,'TG-CIE170007'),(141,'TG-IRI180027'),(142,'chastang'),(142,'TG-ATM160027'),(143,'cakers2'),(144,'ktyle'),(144,'TG-CIE160051'),(145,'TG-MCB140147'),(146,'jhallida'),(146,'TG-BIO160064'),(148,'mniesen'),(149,'jomlowe'),(150,'hps'),(151,'TG-CCR190013'),(152,'TG-CCR190013'),(153,'system'),(154,'vortex2'),(155,'ssalam'),(156,'TG-ASC160018'),(157,'cgrant'),(158,'TG-CCR140004'),(158,'TG-CCR180043'),(158,'TG-CCR180061'),(158,'TG-CHE080068N'),(158,'TG-EAR190021'),(158,'TG-ENG170037'),(158,'TG-IBN140002'),(158,'TG-IRI160006'),(158,'TG-IRI180028'),(158,'TG-MCB070039N'),(158,'TG-TRA160003'),(159,'cbjhnsn'),(160,'mjames'),(160,'TG-ATM160027'),(161,'jfischer'),(162,'redcar'),(163,'scigap'),(163,'TG-CCR140004'),(163,'TG-CIE160029'),(163,'TG-EAR180013'),(165,'tantrung'),(166,'TG-TRA160003'),(166,'TG-TRA160027'),(167,'maxmck7'),(168,'TG-ASC160018'),(168,'TG-IBN170017'),(169,'ssteady'),(170,'TG-ASC180056'),(170,'TG-BCS180023'),(170,'TG-CIE170055'),(170,'TG-IRI180017'),(171,'binod30'),(172,'heena'),(173,'metrics'),(174,'maite'),(175,'TG-CDA170011'),(176,'kz1954'),(177,'rwehrer'),(178,'TG-TRA150025'),(179,'TG-ATM160027'),(180,'kmadappa'),(181,'pswargam'),(182,'akamber2'),(183,'rkalyana'),(185,'TG-CCR190013'),(186,'TG-CCR190013'),(187,'TG-CCR190013'),(188,'TG-CCR190013'),(189,'TG-CCR190013'),(190,'TG-CCR190013'),(191,'TG-CCR190013'),(193,'jbaldo'),(194,'TG-CDA180007'),(195,'kagra'),(196,'jppeters'),(197,'mattremm'),(199,'TG-PHY140033'),(200,'tassie'),(201,'TG-CHE080068N'),(202,'eknox'),(203,'TG-CDA170013'),(203,'TG-TRA160003'),(204,'vwangia'),(205,'tshep'),(206,'atrevino'),(207,'madrina'),(208,'ataje'),(209,'fpsom'),(210,'wfisher'),(211,'jselvam'),(212,'rperigo'),(214,'willarno'),(215,'TG-CCR160022'),(216,'TG-CDA170013'),(217,'ramya1'),(218,'TG-CIE160047'),(219,'yhung'),(220,'amitj'),(221,'sp0090'),(222,'TG-CDA170003'),(223,'marelize'),(225,'dmm'),(226,'rfmeraz'),(227,'hugogao'),(228,'weisi'),(229,'wbt3'),(230,'jcali'),(231,'amco'),(232,'adstew97'),(233,'kausrini'),(234,'ssanders'),(235,'TG-CDA170008'),(236,'tswetnam'),(237,'wang208'),(238,'jdakka'),(239,'luzhixiu'),(240,'mscott'),(241,'tx160085'),(242,'TG-MCB070039N'),(243,'TG-ASC170002'),(244,'zking'),(245,'wzhy2000'),(246,'nardos'),(247,'TG-DEB180020'),(248,'mantholz'),(249,'TG-EAR190001'),(250,'kemelian'),(251,'nujwoo'),(252,'shzh9814'),(253,'mason25'),(254,'nfrazier'),(255,'dcooper3'),(256,'TG-DBS170008'),(257,'schae234'),(258,'jdv'),(259,'TG-STA160002'),(260,'xdmod'),(261,'astrobio'),(262,'plm02'),(263,'cdosborn'),(264,'jpummil'),(265,'ddvento'),(266,'samroy'),(267,'dagrawa2'),(268,'rmickol'),(269,'ppani'),(270,'TG-IRI180027'),(271,'hilaryk'),(272,'nathsnyd'),(273,'grcramer'),(274,'radmatt'),(275,'TG-TRA160027'),(276,'swalke28'),(277,'dhaynes'),(277,'TG-SES180024'),(278,'cmart'),(279,'bohendo'),(280,'wstuhr'),(281,'TG-TRA160003'),(282,'jchuah'),(284,'walling'),(285,'Galaxy_Persistant_Services'),(285,'TG-CCR160022'),(286,'rsajulga'),(287,'pcpeters'),(288,'TG-CCR180043'),(289,'TG-TRA160003'),(290,'TG-CIE170025'),(291,'TG-CIE170025'),(292,'TG-CIE170025'),(293,'TG-CIE170025'),(294,'yclu'),(295,'TG-EAR180028'),(297,'akmore'),(298,'shore'),(299,'TG-ATM170024'),(300,'lmundia'),(301,'rcampbel'),(302,'chanchal'),(303,'TG-CCR160022'),(304,'mhannonj'),(305,'akanna'),(307,'mfaraji'),(308,'schitta'),(309,'TG-CDA180007'),(310,'ssud2'),(311,'smccaula'),(312,'guow'),(313,'blakekas'),(314,'irberlui'),(315,'gspeyer'),(316,'shengs'),(317,'phillity'),(318,'scanchi'),(319,'nykim'),(321,'fils'),(321,'TG-EAR170012'),(321,'TG-EAR180009'),(322,'wscreen'),(323,'zc8304'),(324,'dpazruiz'),(325,'mkrenz'),(326,'bmsamuel'),(327,'cganote'),(327,'TG-MCB160163'),(328,'kelumdi'),(330,'zare'),(331,'amelung'),(332,'noorabom'),(333,'majdavis'),(334,'sidpath'),(335,'vlevkov'),(336,'jrmales'),(337,'TG-CCR160022'),(338,'gaojie22'),(339,'steckm'),(340,'vlflores'),(341,'rasc5939'),(342,'TG-BIO170103'),(343,'ianmacc'),(344,'TG-CCR180043'),(345,'aalmsaee'),(346,'shayyag'),(347,'akn752'),(348,'iparask'),(349,'jsdsmail'),(350,'dgilbert'),(352,'millera2'),(353,'wsang'),(354,'emre'),(355,'sean1906'),(356,'devon'),(358,'hjnance'),(359,'bhaakens'),(360,'pmoriano'),(361,'service'),(362,'bberlin'),(364,'ljosyula'),(365,'ljcohen'),(366,'TG-NCR160005'),(367,'andybeet'),(368,'jake1'),(369,'caninerv'),(371,'timkrock'),(372,'stephd'),(373,'nkern'),(374,'jeovany7'),(375,'TG-OCE170022'),(376,'hpfs'),(377,'beshel'),(378,'gjoshua'),(379,'TG-DBS160006'),(379,'TG-EAR170011'),(380,'vpenchv'),(381,'ishv99'),(382,'ntrip'),(383,'jreadey'),(384,'cmarnold'),(385,'lhin'),(386,'TG-CDA170011'),(387,'aralshi'),(388,'tenekod5'),(389,'cdparra'),(392,'jwzhao'),(394,'aashwani'),(395,'TG-CDA180009'),(396,'cboettig'),(397,'danidub'),(398,'jhaber'),(399,'sruthi12'),(400,'lbao235'),(401,'jhouse'),(402,'zehra'),(403,'agopu'),(404,'smm6'),(405,'sjmiller'),(406,'jbadalam'),(407,'jb557'),(408,'TG-DBS180009'),(409,'allopatr'),(410,'dtyoung'),(411,'TG-IRI180017'),(412,'brooksph'),(413,'saptpurk'),(416,'ssmallen'),(417,'ychatel'),(418,'egforan'),(419,'shanghai'),(420,'j1axs01'),(421,'zonca'),(422,'nsokol'),(423,'padbrown'),(424,'TG-GEO160010'),(425,'sclevey'),(426,'bake1349'),(427,'TG-BIO150062'),(427,'upendra'),(428,'ssg2394'),(429,'tasmia'),(430,'bret'),(431,'virtual'),(432,'josconno'),(433,'kloster'),(435,'TG-CCR180043'),(436,'rmallen'),(437,'tskluzac'),(438,'kangplee'),(439,'td160021'),(441,'schartlm'),(443,'nmebadi'),(444,'mhmurray'),(445,'abarber'),(446,'TG-IRI190007'),(447,'pmiksza'),(448,'mspinks'),(449,'sirace'),(450,'paxton'),(454,'slaterl'),(455,'aymen'),(456,'sharnly3'),(457,'mworinge'),(458,'henschel'),(459,'bsayre'),(460,'dikim'),(461,'lalakl'),(462,'gryanp'),(463,'adhage'),(464,'cldixon'),(465,'TG-BIO170096'),(466,'ccc010'),(467,'dyhancoc'),(468,'marcusc'),(469,'hudson89'),(471,'rauta'),(472,'quietjen'),(473,'uma'),(474,'kagross'),(475,'beckbw'),(477,'megm');
/*!40000 ALTER TABLE `Cloud_person___project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_person___provider`
--

DROP TABLE IF EXISTS `Cloud_person___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_person___provider` (
  `person` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`person`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_person___provider`
--

LOCK TABLES `Cloud_person___provider` WRITE;
/*!40000 ALTER TABLE `Cloud_person___provider` DISABLE KEYS */;
INSERT INTO `Cloud_person___provider` VALUES (128,1),(130,1),(131,1),(133,1),(134,1),(135,1),(136,1),(137,1),(138,1),(139,1),(140,1),(141,1),(142,1),(143,1),(144,1),(145,1),(146,1),(148,1),(149,1),(150,1),(151,1),(152,1),(153,1),(154,1),(155,1),(156,1),(157,1),(158,1),(159,1),(160,1),(161,1),(162,1),(163,1),(165,1),(166,1),(167,1),(168,1),(169,1),(170,1),(171,1),(172,1),(173,1),(174,1),(175,1),(176,1),(177,1),(178,1),(179,1),(180,1),(181,1),(182,1),(183,1),(185,1),(186,1),(187,1),(188,1),(189,1),(190,1),(191,1),(193,1),(194,1),(195,1),(196,1),(197,1),(199,1),(200,1),(201,1),(202,1),(203,1),(204,1),(205,1),(206,1),(207,1),(208,1),(209,1),(210,1),(211,1),(212,1),(214,1),(215,1),(216,1),(217,1),(218,1),(219,1),(220,1),(221,1),(222,1),(223,1),(225,1),(226,1),(227,1),(228,1),(229,1),(230,1),(231,1),(232,1),(233,1),(234,1),(235,1),(236,1),(237,1),(238,1),(239,1),(240,1),(241,1),(242,1),(243,1),(244,1),(245,1),(246,1),(247,1),(248,1),(249,1),(250,1),(251,1),(252,1),(253,1),(254,1),(255,1),(256,1),(257,1),(258,1),(259,1),(260,1),(261,1),(262,1),(263,1),(264,1),(265,1),(266,1),(267,1),(268,1),(269,1),(270,1),(271,1),(272,1),(273,1),(274,1),(275,1),(276,1),(277,1),(278,1),(279,1),(280,1),(281,1),(282,1),(284,1),(285,1),(286,1),(287,1),(288,1),(289,1),(290,1),(291,1),(292,1),(293,1),(294,1),(295,1),(297,1),(298,1),(299,1),(300,1),(301,1),(302,1),(303,1),(304,1),(305,1),(307,1),(308,1),(309,1),(310,1),(311,1),(312,1),(313,1),(314,1),(315,1),(316,1),(317,1),(318,1),(319,1),(321,1),(322,1),(323,1),(324,1),(325,1),(326,1),(327,1),(328,1),(330,1),(331,1),(332,1),(333,1),(334,1),(335,1),(336,1),(337,1),(338,1),(339,1),(340,1),(341,1),(342,1),(343,1),(344,1),(345,1),(346,1),(347,1),(348,1),(349,1),(350,1),(352,1),(353,1),(354,1),(355,1),(356,1),(358,1),(359,1),(360,1),(361,1),(362,1),(364,1),(365,1),(366,1),(367,1),(368,1),(369,1),(371,1),(372,1),(373,1),(374,1),(375,1),(376,1),(377,1),(378,1),(379,1),(380,1),(381,1),(382,1),(383,1),(384,1),(385,1),(386,1),(387,1),(388,1),(389,1),(392,1),(394,1),(395,1),(396,1),(397,1),(398,1),(399,1),(400,1),(401,1),(402,1),(403,1),(404,1),(405,1),(406,1),(407,1),(408,1),(409,1),(410,1),(411,1),(412,1),(413,1),(416,1),(417,1),(418,1),(419,1),(420,1),(421,1),(422,1),(423,1),(424,1),(425,1),(426,1),(427,1),(428,1),(429,1),(430,1),(431,1),(432,1),(433,1),(435,1),(436,1),(437,1),(438,1),(439,1),(441,1),(443,1),(444,1),(445,1),(446,1),(447,1),(448,1),(449,1),(450,1),(454,1),(455,1),(456,1),(457,1),(458,1),(459,1),(460,1),(461,1),(462,1),(463,1),(464,1),(465,1),(466,1),(467,1),(468,1),(469,1),(471,1),(472,1),(473,1),(474,1),(475,1),(477,1);
/*!40000 ALTER TABLE `Cloud_person___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_person___resource`
--

DROP TABLE IF EXISTS `Cloud_person___resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_person___resource` (
  `person` int(11) NOT NULL,
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`person`,`resource`),
  KEY `idx_second_dimension` (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_person___resource`
--

LOCK TABLES `Cloud_person___resource` WRITE;
/*!40000 ALTER TABLE `Cloud_person___resource` DISABLE KEYS */;
INSERT INTO `Cloud_person___resource` VALUES (128,8),(130,8),(131,8),(133,9),(134,9),(135,9),(136,9),(137,9),(138,9),(139,9),(140,9),(141,9),(142,9),(143,9),(144,9),(145,9),(146,9),(148,9),(149,9),(150,9),(151,9),(152,9),(153,9),(154,9),(155,9),(156,9),(157,9),(158,9),(159,9),(160,9),(161,9),(162,9),(163,9),(165,9),(166,9),(167,9),(168,9),(169,9),(170,9),(171,9),(172,9),(173,9),(174,9),(175,9),(176,9),(177,9),(178,9),(179,9),(180,9),(181,9),(182,9),(183,9),(185,9),(186,9),(187,9),(188,9),(189,9),(190,9),(191,9),(193,9),(194,9),(195,9),(196,9),(197,9),(199,9),(200,9),(201,9),(202,9),(203,9),(204,9),(205,9),(206,9),(207,9),(208,9),(209,9),(210,9),(211,9),(212,9),(214,9),(215,9),(216,9),(217,9),(218,9),(219,9),(220,9),(221,9),(222,9),(223,9),(225,9),(226,9),(227,9),(228,9),(229,9),(230,9),(231,9),(232,9),(233,9),(234,9),(235,9),(236,9),(237,9),(238,9),(239,9),(240,9),(241,9),(242,9),(243,9),(244,9),(245,9),(246,9),(247,9),(248,9),(249,9),(250,9),(251,9),(252,9),(253,9),(254,9),(255,9),(256,9),(257,9),(258,9),(259,9),(260,9),(261,9),(262,9),(263,9),(264,9),(265,9),(266,9),(267,9),(268,9),(269,9),(270,9),(271,9),(272,9),(273,9),(274,9),(275,9),(276,9),(277,9),(278,9),(279,9),(280,9),(281,9),(282,9),(284,9),(285,9),(286,9),(287,9),(288,9),(289,9),(290,9),(291,9),(292,9),(293,9),(294,9),(295,9),(297,9),(298,9),(299,9),(300,9),(301,9),(302,9),(303,9),(304,9),(305,9),(307,9),(308,9),(309,9),(310,9),(311,9),(312,9),(313,9),(314,9),(315,9),(316,9),(317,9),(318,9),(319,9),(321,9),(322,9),(323,9),(324,9),(325,9),(326,9),(327,9),(328,9),(330,9),(331,9),(332,9),(333,9),(334,9),(335,9),(336,9),(337,9),(338,9),(339,9),(340,9),(341,9),(342,9),(343,9),(344,9),(345,9),(346,9),(347,9),(348,9),(349,9),(350,9),(352,9),(353,9),(354,9),(355,9),(356,9),(358,9),(359,9),(360,9),(361,9),(362,9),(364,9),(365,9),(366,9),(367,9),(368,9),(369,9),(371,9),(372,9),(373,9),(374,9),(375,9),(376,9),(377,9),(378,9),(379,9),(380,9),(381,9),(382,9),(383,9),(384,9),(385,9),(386,9),(387,9),(388,9),(389,9),(392,9),(394,9),(395,9),(396,9),(397,9),(398,9),(399,9),(400,9),(401,9),(402,9),(403,9),(404,9),(405,9),(406,9),(407,9),(408,9),(409,9),(410,9),(411,9),(412,9),(413,9),(416,9),(417,9),(418,9),(419,9),(420,9),(421,9),(422,9),(423,9),(424,9),(425,9),(426,9),(427,9),(428,9),(429,9),(430,9),(431,9),(432,9),(433,9),(435,9),(436,9),(437,9),(438,9),(439,9),(441,9),(443,9),(444,9),(445,9),(446,9),(447,9),(448,9),(449,9),(450,9),(454,9),(455,9),(456,9),(457,9),(458,9),(459,9),(460,9),(461,9),(462,9),(463,9),(464,9),(465,9),(466,9),(467,9),(468,9),(469,9),(471,9),(472,9),(473,9),(474,9),(475,9),(477,9);
/*!40000 ALTER TABLE `Cloud_person___resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_person___submission_venue`
--

DROP TABLE IF EXISTS `Cloud_person___submission_venue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_person___submission_venue` (
  `person` int(11) NOT NULL,
  `submission_venue` int(11) NOT NULL,
  PRIMARY KEY (`person`,`submission_venue`),
  KEY `idx_second_dimension` (`submission_venue`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_person___submission_venue`
--

LOCK TABLES `Cloud_person___submission_venue` WRITE;
/*!40000 ALTER TABLE `Cloud_person___submission_venue` DISABLE KEYS */;
INSERT INTO `Cloud_person___submission_venue` VALUES (128,3),(130,3),(131,3),(133,3),(134,3),(135,3),(136,3),(137,3),(138,3),(139,3),(140,3),(141,3),(142,3),(143,3),(144,3),(145,3),(146,3),(148,3),(149,3),(150,3),(151,3),(152,3),(153,3),(154,3),(155,3),(156,3),(157,3),(158,3),(159,3),(160,3),(161,3),(162,3),(163,3),(165,3),(166,3),(167,3),(168,3),(169,3),(170,3),(171,3),(172,3),(173,3),(174,3),(175,3),(176,3),(177,3),(178,3),(179,3),(180,3),(181,3),(182,3),(183,3),(185,3),(186,3),(187,3),(188,3),(189,3),(190,3),(191,3),(193,3),(194,3),(195,3),(196,3),(197,3),(199,3),(200,3),(201,3),(202,3),(203,3),(204,3),(205,3),(206,3),(207,3),(208,3),(209,3),(210,3),(211,3),(212,3),(214,3),(215,3),(216,3),(217,3),(218,3),(219,3),(220,3),(221,3),(222,3),(223,3),(225,3),(226,3),(227,3),(228,3),(229,3),(230,3),(231,3),(232,3),(233,3),(234,3),(235,3),(236,3),(237,3),(238,3),(239,3),(240,3),(241,3),(242,3),(243,3),(244,3),(245,3),(246,3),(247,3),(248,3),(249,3),(250,3),(251,3),(252,3),(253,3),(254,3),(255,3),(256,3),(257,3),(258,3),(259,3),(260,3),(261,3),(262,3),(263,3),(264,3),(265,3),(266,3),(267,3),(268,3),(269,3),(270,3),(271,3),(272,3),(273,3),(274,3),(275,3),(276,3),(277,3),(278,3),(279,3),(280,3),(281,3),(282,3),(284,3),(285,3),(286,3),(287,3),(288,3),(289,3),(290,3),(291,3),(292,3),(293,3),(294,3),(295,3),(297,3),(298,3),(299,3),(300,3),(301,3),(302,3),(303,3),(304,3),(305,3),(307,3),(308,3),(309,3),(310,3),(311,3),(312,3),(313,3),(314,3),(315,3),(316,3),(317,3),(318,3),(319,3),(321,3),(322,3),(323,3),(324,3),(325,3),(326,3),(327,3),(328,3),(330,3),(331,3),(332,3),(333,3),(334,3),(335,3),(336,3),(337,3),(338,3),(339,3),(340,3),(341,3),(342,3),(343,3),(344,3),(345,3),(346,3),(347,3),(348,3),(349,3),(350,3),(352,3),(353,3),(354,3),(355,3),(356,3),(358,3),(359,3),(360,3),(361,3),(362,3),(364,3),(365,3),(366,3),(367,3),(368,3),(369,3),(371,3),(372,3),(373,3),(374,3),(375,3),(376,3),(377,3),(378,3),(379,3),(380,3),(381,3),(382,3),(383,3),(384,3),(385,3),(386,3),(387,3),(388,3),(389,3),(392,3),(394,3),(395,3),(396,3),(397,3),(398,3),(399,3),(400,3),(401,3),(402,3),(403,3),(404,3),(405,3),(406,3),(407,3),(408,3),(409,3),(410,3),(411,3),(412,3),(413,3),(416,3),(417,3),(418,3),(419,3),(420,3),(421,3),(422,3),(423,3),(424,3),(425,3),(426,3),(427,3),(428,3),(429,3),(430,3),(431,3),(432,3),(433,3),(435,3),(436,3),(437,3),(438,3),(439,3),(441,3),(443,3),(444,3),(445,3),(446,3),(447,3),(448,3),(449,3),(450,3),(454,3),(455,3),(456,3),(457,3),(458,3),(459,3),(460,3),(461,3),(462,3),(463,3),(464,3),(465,3),(466,3),(467,3),(468,3),(469,3),(471,3),(472,3),(473,3),(474,3),(475,3),(477,3);
/*!40000 ALTER TABLE `Cloud_person___submission_venue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_person___username`
--

DROP TABLE IF EXISTS `Cloud_person___username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_person___username` (
  `person` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`person`,`username`),
  KEY `idx_second_dimension` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_person___username`
--

LOCK TABLES `Cloud_person___username` WRITE;
/*!40000 ALTER TABLE `Cloud_person___username` DISABLE KEYS */;
INSERT INTO `Cloud_person___username` VALUES (128,'yerwa'),(130,'ylwwa'),(131,'setusca'),(133,'paulrad'),(134,'iarora'),(135,'tg857713'),(136,'julianp'),(137,'alanguye'),(138,'hayashis'),(139,'yvanpij'),(140,'senxu'),(141,'gonzalo'),(142,'chastang'),(143,'cakers2'),(144,'ktyle'),(145,'xcgalaxy'),(146,'jhallida'),(148,'mniesen'),(149,'jomlowe'),(150,'red'),(151,'mckandes'),(152,'tg857711'),(153,'geo'),(154,'vortex2'),(155,'ssalam'),(156,'apitest'),(157,'cgrant'),(158,'tg829096'),(159,'cbjhnsn'),(160,'mjames'),(161,'jfischer'),(162,'redcar'),(163,'scigap'),(165,'tantrung'),(166,'tg456058'),(167,'maxmck7'),(168,'vaughn'),(169,'ssteady'),(170,'willis8'),(171,'binod30'),(172,'heena'),(173,'metrics'),(174,'maite'),(175,'tg455671'),(176,'kz1954'),(177,'rwehrer'),(178,'aculich'),(179,'cwardgar'),(180,'kmadappa'),(181,'pswargam'),(182,'akamber2'),(183,'rkalyana'),(185,'tg857714'),(186,'tg856781'),(187,'tg857674'),(188,'tg857485'),(189,'mapodaca'),(190,'tg857377'),(191,'brhatton'),(193,'jbaldo'),(194,'UNKNOWN'),(195,'kagra'),(196,'jppeters'),(197,'mattremm'),(199,'ponyisi'),(200,'tassie'),(201,'tg457649'),(202,'eknox'),(203,'tg834267'),(204,'vwangia'),(205,'tshep'),(206,'atrevino'),(207,'madrina'),(208,'ataje'),(209,'fpsom'),(210,'wfisher'),(211,'jselvam'),(212,'rperigo'),(214,'willarno'),(215,'alexmah'),(216,'grogers'),(217,'ramya1'),(218,'jstubbs'),(219,'yhung'),(220,'amitj'),(221,'sp0090'),(222,'ccompute'),(223,'marelize'),(225,'dmm'),(226,'rfmeraz'),(227,'hugogao'),(228,'weisi'),(229,'wbt3'),(230,'jcali'),(231,'amco'),(232,'adstew97'),(233,'kausrini'),(234,'ssanders'),(235,'dhanuman'),(236,'tswetnam'),(237,'wang208'),(238,'jdakka'),(239,'luzhixiu'),(240,'mscott'),(241,'tx160085'),(242,'tg457210'),(243,'tg841578'),(244,'zking'),(245,'wzhy2000'),(246,'nardos'),(247,'rynge'),(248,'mantholz'),(249,'jscottsf'),(250,'kemelian'),(251,'nujwoo'),(252,'shzh9814'),(253,'mason25'),(254,'nfrazier'),(255,'dcooper3'),(256,'suderman'),(257,'schae234'),(258,'jdv'),(259,'xwj'),(260,'pcp'),(261,'astrobio'),(262,'plm02'),(263,'cdosborn'),(264,'jpummil'),(265,'ddvento'),(266,'samroy'),(267,'dagrawa2'),(268,'rmickol'),(269,'ppani'),(270,'tg839371'),(271,'hilaryk'),(272,'nathsnyd'),(273,'grcramer'),(274,'radmatt'),(275,'hannac'),(276,'swalke28'),(277,'dhaynes'),(278,'cmart'),(279,'bohendo'),(280,'wstuhr'),(281,'tg457349'),(282,'jchuah'),(284,'walling'),(285,'eafgan'),(286,'rsajulga'),(287,'pcpeters'),(288,'tg858644'),(289,'tg457074'),(290,'tg857970'),(291,'tg858245'),(292,'tg858209'),(293,'tg853683'),(294,'yclu'),(295,'sbaker01'),(297,'akmore'),(298,'shore'),(299,'tg842548'),(300,'lmundia'),(301,'rcampbel'),(302,'chanchal'),(303,'tg836876'),(304,'mhannonj'),(305,'akanna'),(307,'mfaraji'),(308,'schitta'),(309,'rdooley'),(310,'ssud2'),(311,'smccaula'),(312,'guow'),(313,'blakekas'),(314,'irberlui'),(315,'gspeyer'),(316,'shengs'),(317,'phillity'),(318,'scanchi'),(319,'nykim'),(321,'fils'),(322,'wscreen'),(323,'zc8304'),(324,'dpazruiz'),(325,'mkrenz'),(326,'bmsamuel'),(327,'cganote'),(328,'kelumdi'),(330,'zare'),(331,'amelung'),(332,'noorabom'),(333,'majdavis'),(334,'sidpath'),(335,'vlevkov'),(336,'jrmales'),(337,'tg839024'),(338,'gaojie22'),(339,'steckm'),(340,'vlflores'),(341,'rasc5939'),(342,'tg834860'),(343,'ianmacc'),(344,'tg858635'),(345,'aalmsaee'),(346,'shayyag'),(347,'akn752'),(348,'iparask'),(349,'jsdsmail'),(350,'dgilbert'),(352,'millera2'),(353,'wsang'),(354,'emre'),(355,'sean1906'),(356,'devon'),(358,'hjnance'),(359,'bhaakens'),(360,'pmoriano'),(361,'nova'),(362,'bberlin'),(364,'ljosyula'),(365,'ljcohen'),(366,'tg837611'),(367,'andybeet'),(368,'jake1'),(369,'caninerv'),(371,'timkrock'),(372,'stephd'),(373,'nkern'),(374,'jeovany7'),(375,'rsignell'),(376,'vast'),(377,'beshel'),(378,'gjoshua'),(379,'mpierce'),(380,'vpenchv'),(381,'ishv99'),(382,'ntrip'),(383,'jreadey'),(384,'cmarnold'),(385,'lhin'),(386,'ux445032'),(387,'aralshi'),(388,'tenekod5'),(389,'cdparra'),(392,'jwzhao'),(394,'aashwani'),(395,'gmanipon'),(396,'cboettig'),(397,'danidub'),(398,'jhaber'),(399,'sruthi12'),(400,'lbao235'),(401,'jhouse'),(402,'zehra'),(403,'agopu'),(404,'smm6'),(405,'sjmiller'),(406,'jbadalam'),(407,'jb557'),(408,'tg837136'),(409,'allopatr'),(410,'dtyoung'),(411,'lambert8'),(412,'brooksph'),(413,'saptpurk'),(416,'ssmallen'),(417,'ychatel'),(418,'egforan'),(419,'shanghai'),(420,'j1axs01'),(421,'zonca'),(422,'nsokol'),(423,'padbrown'),(424,'iwatson'),(425,'sclevey'),(426,'bake1349'),(427,'upendra'),(428,'ssg2394'),(429,'tasmia'),(430,'bret'),(431,'virtual'),(432,'josconno'),(433,'kloster'),(435,'tg858636'),(436,'rmallen'),(437,'tskluzac'),(438,'kangplee'),(439,'td160021'),(441,'schartlm'),(443,'nmebadi'),(444,'mhmurray'),(445,'abarber'),(446,'alwalsh'),(447,'pmiksza'),(448,'mspinks'),(449,'sirace'),(450,'paxton'),(454,'slaterl'),(455,'aymen'),(456,'sharnly3'),(457,'mworinge'),(458,'henschel'),(459,'bsayre'),(460,'dikim'),(461,'lalakl'),(462,'gryanp'),(463,'adhage'),(464,'cldixon'),(465,'mesler'),(466,'ccc010'),(467,'dyhancoc'),(468,'marcusc'),(469,'hudson89'),(471,'rauta'),(472,'quietjen'),(473,'uma'),(474,'kagross'),(475,'beckbw'),(477,'megm');
/*!40000 ALTER TABLE `Cloud_person___username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_person___vm_size`
--

DROP TABLE IF EXISTS `Cloud_person___vm_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_person___vm_size` (
  `person` int(11) NOT NULL,
  `vm_size` int(4) NOT NULL,
  PRIMARY KEY (`person`,`vm_size`),
  KEY `idx_second_dimension` (`vm_size`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_person___vm_size`
--

LOCK TABLES `Cloud_person___vm_size` WRITE;
/*!40000 ALTER TABLE `Cloud_person___vm_size` DISABLE KEYS */;
INSERT INTO `Cloud_person___vm_size` VALUES (128,1),(128,2),(128,3),(130,1),(130,2),(130,3),(131,1),(133,2),(134,1),(134,2),(134,3),(135,1),(136,2),(137,1),(138,3),(138,4),(138,6),(139,1),(139,4),(140,4),(140,7),(141,2),(141,3),(141,4),(142,2),(142,3),(142,4),(142,6),(142,7),(143,1),(143,6),(144,2),(144,3),(144,4),(145,3),(145,4),(146,2),(146,3),(148,7),(149,1),(149,2),(149,4),(150,1),(150,2),(151,1),(152,1),(153,1),(153,7),(154,7),(155,3),(155,4),(156,4),(157,4),(158,2),(158,3),(158,4),(158,6),(159,2),(159,3),(159,6),(160,4),(160,7),(161,1),(162,3),(162,4),(162,6),(163,1),(163,2),(163,3),(165,1),(166,2),(166,7),(167,2),(168,2),(168,3),(168,4),(169,3),(170,2),(170,3),(171,3),(172,3),(172,7),(173,1),(174,3),(175,2),(175,3),(176,4),(177,2),(178,2),(179,2),(179,3),(180,3),(181,3),(182,2),(183,3),(185,1),(186,1),(187,1),(188,1),(189,1),(190,1),(191,1),(193,2),(193,3),(193,6),(194,3),(195,4),(195,6),(196,2),(196,3),(197,1),(199,6),(200,3),(201,3),(202,7),(203,1),(203,2),(204,1),(205,7),(206,1),(206,2),(206,3),(207,3),(208,1),(208,2),(209,3),(210,6),(211,3),(212,4),(212,7),(214,4),(215,2),(216,2),(216,3),(217,1),(218,3),(219,4),(220,1),(220,2),(221,3),(222,1),(222,2),(222,3),(222,4),(223,2),(225,3),(226,3),(227,3),(228,7),(229,2),(230,4),(231,4),(232,2),(232,3),(233,1),(234,3),(235,2),(235,3),(236,1),(236,2),(237,2),(237,3),(238,1),(239,1),(239,2),(239,3),(240,3),(241,3),(242,2),(243,1),(243,2),(243,3),(244,6),(245,2),(246,3),(247,2),(247,3),(247,4),(248,2),(249,3),(250,6),(251,1),(252,2),(253,2),(254,2),(255,1),(256,2),(256,3),(256,4),(257,2),(258,2),(259,2),(260,2),(261,2),(262,4),(263,1),(264,4),(265,1),(265,4),(266,2),(267,3),(268,3),(269,3),(270,3),(271,3),(272,3),(273,3),(274,3),(275,2),(276,2),(277,3),(277,4),(278,1),(278,6),(279,1),(280,2),(281,2),(281,3),(282,1),(284,2),(285,2),(285,3),(286,4),(286,7),(287,1),(288,3),(289,2),(289,3),(289,4),(289,6),(290,3),(291,3),(292,3),(293,3),(294,6),(295,4),(295,6),(297,1),(297,3),(298,3),(299,7),(300,1),(301,3),(302,6),(303,3),(303,4),(304,4),(305,4),(307,2),(308,1),(309,3),(310,1),(311,3),(312,1),(312,2),(313,2),(314,3),(315,2),(316,1),(317,3),(318,3),(319,1),(321,3),(322,3),(323,2),(324,2),(325,1),(326,3),(327,1),(327,2),(328,4),(330,1),(331,1),(332,1),(333,1),(334,1),(335,1),(336,7),(337,6),(338,1),(339,4),(340,3),(341,2),(342,3),(343,6),(344,3),(345,1),(346,2),(347,2),(347,3),(348,3),(348,4),(349,3),(350,2),(352,2),(353,1),(354,2),(355,2),(356,2),(358,3),(359,3),(360,1),(361,2),(362,7),(364,3),(365,7),(366,6),(367,2),(368,2),(369,3),(371,3),(371,4),(372,3),(373,7),(374,1),(375,3),(376,2),(376,6),(377,6),(378,3),(379,2),(380,3),(381,6),(382,3),(383,6),(384,2),(385,2),(386,3),(387,1),(387,3),(388,1),(389,2),(389,3),(392,1),(394,4),(395,3),(396,3),(397,2),(398,6),(399,3),(400,2),(401,2),(401,3),(402,2),(403,1),(404,2),(405,3),(406,3),(407,1),(408,3),(409,2),(410,3),(411,3),(412,3),(413,3),(416,3),(417,3),(418,3),(419,3),(420,2),(421,2),(422,3),(423,3),(424,3),(425,2),(426,7),(427,3),(428,3),(429,3),(430,1),(431,2),(432,3),(433,6),(435,3),(436,6),(437,4),(438,1),(439,1),(441,4),(443,1),(444,3),(445,3),(446,1),(447,3),(448,2),(449,3),(450,6),(454,2),(455,3),(456,2),(457,1),(458,1),(459,4),(460,1),(461,1),(462,2),(463,1),(464,1),(465,3),(466,4),(467,1),(468,3),(469,6),(471,3),(472,6),(473,3),(474,4),(475,2),(477,4);
/*!40000 ALTER TABLE `Cloud_person___vm_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_person___vm_size_memory`
--

DROP TABLE IF EXISTS `Cloud_person___vm_size_memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_person___vm_size_memory` (
  `person` int(11) NOT NULL,
  `vm_size_memory` int(4) NOT NULL,
  PRIMARY KEY (`person`,`vm_size_memory`),
  KEY `idx_second_dimension` (`vm_size_memory`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_person___vm_size_memory`
--

LOCK TABLES `Cloud_person___vm_size_memory` WRITE;
/*!40000 ALTER TABLE `Cloud_person___vm_size_memory` DISABLE KEYS */;
INSERT INTO `Cloud_person___vm_size_memory` VALUES (128,1),(128,2),(128,3),(128,4),(128,6),(130,1),(130,2),(130,4),(131,1),(131,2),(133,2),(134,2),(134,4),(135,2),(136,2),(137,2),(138,4),(138,5),(138,6),(139,2),(139,5),(140,5),(140,7),(141,2),(141,4),(141,5),(142,2),(142,4),(142,5),(142,6),(142,7),(143,2),(143,6),(144,2),(144,4),(144,5),(145,4),(145,5),(146,2),(146,4),(148,7),(149,2),(149,5),(150,2),(151,2),(152,2),(153,2),(153,7),(154,7),(155,4),(155,5),(156,5),(157,5),(158,2),(158,4),(158,5),(158,6),(159,2),(159,4),(159,6),(160,5),(160,7),(161,2),(162,4),(162,5),(162,6),(163,2),(163,4),(165,2),(166,2),(166,7),(167,2),(168,2),(168,4),(168,5),(169,4),(170,2),(170,4),(171,4),(172,4),(172,7),(173,2),(174,4),(175,2),(175,3),(176,5),(177,2),(178,2),(179,2),(179,4),(180,4),(181,4),(182,2),(183,4),(185,2),(186,2),(187,2),(188,2),(189,2),(190,2),(191,2),(193,2),(193,4),(193,6),(194,4),(195,5),(195,6),(196,2),(196,4),(197,2),(199,6),(200,4),(201,4),(202,7),(203,2),(204,2),(205,7),(206,2),(206,4),(207,4),(208,2),(209,4),(210,6),(211,4),(212,5),(212,7),(214,5),(215,2),(216,2),(216,4),(217,2),(218,4),(219,5),(220,2),(221,4),(222,2),(222,4),(222,5),(223,2),(225,4),(226,4),(227,4),(228,7),(229,2),(230,5),(231,5),(232,2),(232,4),(233,2),(234,4),(235,2),(235,4),(236,2),(237,2),(237,4),(238,2),(239,2),(239,4),(240,4),(241,4),(242,2),(243,2),(243,4),(244,6),(245,2),(246,4),(247,2),(247,4),(247,5),(248,2),(249,4),(250,6),(251,2),(252,2),(253,2),(254,2),(255,2),(256,2),(256,4),(256,5),(257,2),(258,2),(259,2),(260,2),(261,2),(262,5),(263,2),(264,5),(265,2),(265,5),(266,2),(267,4),(268,4),(269,4),(270,4),(271,4),(272,4),(273,4),(274,4),(275,2),(276,2),(277,4),(277,5),(278,2),(278,6),(279,2),(280,2),(281,2),(281,4),(282,2),(284,2),(285,2),(285,4),(286,5),(286,7),(287,2),(288,4),(289,4),(289,5),(289,6),(290,5),(291,5),(292,5),(293,5),(294,6),(295,5),(295,6),(297,2),(297,4),(298,4),(299,7),(300,2),(301,4),(302,6),(303,4),(303,5),(304,5),(305,5),(307,2),(308,2),(309,4),(310,2),(311,4),(312,2),(313,2),(314,4),(315,2),(316,2),(317,4),(318,4),(319,2),(321,4),(322,4),(323,2),(324,2),(325,2),(326,4),(327,2),(328,5),(330,2),(331,2),(332,2),(333,2),(334,2),(335,2),(336,7),(337,6),(338,2),(339,5),(340,4),(341,2),(342,4),(343,6),(344,4),(345,2),(346,2),(347,2),(347,4),(348,4),(348,5),(349,4),(350,2),(352,2),(353,2),(354,2),(355,2),(356,2),(358,4),(359,4),(360,2),(361,2),(362,7),(364,4),(365,7),(366,6),(367,2),(368,2),(369,4),(371,4),(371,5),(372,4),(373,7),(374,2),(375,4),(376,2),(376,6),(377,6),(378,4),(379,2),(380,4),(381,6),(382,4),(383,6),(384,2),(385,2),(386,3),(387,2),(387,4),(388,2),(389,2),(389,4),(392,2),(394,5),(395,4),(396,4),(397,2),(398,6),(399,4),(400,2),(401,2),(401,4),(402,2),(403,2),(404,2),(405,4),(406,4),(407,2),(408,4),(409,2),(410,4),(411,4),(412,4),(413,4),(416,4),(417,4),(418,4),(419,4),(420,2),(421,2),(422,4),(423,4),(424,4),(425,2),(426,7),(427,4),(428,4),(429,4),(430,2),(431,2),(432,4),(433,6),(435,4),(436,6),(437,5),(438,2),(439,2),(441,5),(443,2),(444,4),(445,4),(446,2),(447,4),(448,2),(449,4),(450,6),(454,2),(455,4),(456,2),(457,2),(458,2),(459,5),(460,2),(461,2),(462,2),(463,2),(464,2),(465,4),(466,5),(467,2),(468,4),(469,6),(471,4),(472,6),(473,4),(474,5),(475,2),(477,5);
/*!40000 ALTER TABLE `Cloud_person___vm_size_memory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_pi`
--

DROP TABLE IF EXISTS `Cloud_pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_pi` (
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_pi`
--

LOCK TABLES `Cloud_pi` WRITE;
/*!40000 ALTER TABLE `Cloud_pi` DISABLE KEYS */;
INSERT INTO `Cloud_pi` VALUES (-1),(15),(79),(102);
/*!40000 ALTER TABLE `Cloud_pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_pi___project`
--

DROP TABLE IF EXISTS `Cloud_pi___project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_pi___project` (
  `pi` int(11) NOT NULL,
  `project` varchar(256) NOT NULL,
  PRIMARY KEY (`pi`,`project`),
  KEY `idx_second_dimension` (`project`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_pi___project`
--

LOCK TABLES `Cloud_pi___project` WRITE;
/*!40000 ALTER TABLE `Cloud_pi___project` DISABLE KEYS */;
INSERT INTO `Cloud_pi___project` VALUES (-1,'aalmsaee'),(-1,'aashwani'),(-1,'abarber'),(-1,'adhage'),(-1,'adstew97'),(-1,'agopu'),(-1,'akamber2'),(-1,'akanna'),(-1,'akmore'),(-1,'akn752'),(-1,'alanguye'),(-1,'allopatr'),(-1,'amco'),(-1,'amelung'),(-1,'amitj'),(-1,'andybeet'),(-1,'aralshi'),(-1,'astrobio'),(-1,'ataje'),(-1,'atrevino'),(-1,'aymen'),(-1,'bake1349'),(-1,'bberlin'),(-1,'beckbw'),(-1,'beshel'),(-1,'bhaakens'),(-1,'binod30'),(-1,'blakekas'),(-1,'bmsamuel'),(-1,'bohendo'),(-1,'bret'),(-1,'brooksph'),(-1,'bsayre'),(-1,'cakers2'),(-1,'caninerv'),(-1,'cbjhnsn'),(-1,'cboettig'),(-1,'ccc010'),(-1,'cdosborn'),(-1,'cdparra'),(-1,'cganote'),(-1,'cgrant'),(-1,'chanchal'),(-1,'chastang'),(-1,'cldixon'),(-1,'cmarnold'),(-1,'cmart'),(-1,'dagrawa2'),(-1,'danidub'),(-1,'dcooper3'),(-1,'ddvento'),(-1,'devon'),(-1,'dgilbert'),(-1,'dhaynes'),(-1,'dikim'),(-1,'dmm'),(-1,'dpazruiz'),(-1,'dtyoung'),(-1,'dyhancoc'),(-1,'egforan'),(-1,'eknox'),(-1,'emre'),(-1,'fils'),(-1,'fpsom'),(-1,'Galaxy_Persistant_Services'),(-1,'gaojie22'),(-1,'gjoshua'),(-1,'grcramer'),(-1,'gryanp'),(-1,'gspeyer'),(-1,'guow'),(-1,'heena'),(-1,'henschel'),(-1,'hilaryk'),(-1,'hjnance'),(-1,'hpfs'),(-1,'hps'),(-1,'hudson89'),(-1,'hugogao'),(-1,'ianmacc'),(-1,'iparask'),(-1,'irberlui'),(-1,'ishv99'),(-1,'j1axs01'),(-1,'jake1'),(-1,'jb557'),(-1,'jbadalam'),(-1,'jbaldo'),(-1,'jcali'),(-1,'jchuah'),(-1,'jdakka'),(-1,'jdv'),(-1,'jeovany7'),(-1,'jfischer'),(-1,'jhaber'),(-1,'jhallida'),(-1,'jhouse'),(-1,'jomlowe'),(-1,'josconno'),(-1,'jppeters'),(-1,'jpummil'),(-1,'jreadey'),(-1,'jrmales'),(-1,'jsdsmail'),(-1,'jselvam'),(-1,'julianp'),(-1,'jwzhao'),(-1,'kagra'),(-1,'kagross'),(-1,'kangplee'),(-1,'kausrini'),(-1,'kelumdi'),(-1,'kemelian'),(-1,'kloster'),(-1,'kmadappa'),(-1,'ktyle'),(-1,'kz1954'),(-1,'lalakl'),(-1,'lbao235'),(-1,'lhin'),(-1,'ljcohen'),(-1,'ljosyula'),(-1,'lmundia'),(-1,'luzhixiu'),(-1,'madrina'),(-1,'maite'),(-1,'majdavis'),(-1,'mantholz'),(-1,'marcusc'),(-1,'marelize'),(-1,'mason25'),(-1,'mattremm'),(-1,'maxmck7'),(-1,'megm'),(-1,'metrics'),(-1,'mfaraji'),(-1,'mhannonj'),(-1,'mhmurray'),(-1,'millera2'),(-1,'mjames'),(-1,'mkrenz'),(-1,'mniesen'),(-1,'mscott'),(-1,'mspinks'),(-1,'mworinge'),(-1,'nardos'),(-1,'nathsnyd'),(-1,'nfrazier'),(-1,'nkern'),(-1,'nmebadi'),(-1,'noorabom'),(-1,'nsokol'),(-1,'ntrip'),(-1,'nujwoo'),(-1,'nykim'),(-1,'padbrown'),(-1,'paxton'),(-1,'pcpeters'),(-1,'phillity'),(-1,'plm02'),(-1,'pmiksza'),(-1,'pmoriano'),(-1,'ppani'),(-1,'pswargam'),(-1,'quietjen'),(-1,'radmatt'),(-1,'ramya1'),(-1,'rasc5939'),(-1,'rauta'),(-1,'rcampbel'),(-1,'redcar'),(-1,'rfmeraz'),(-1,'rkalyana'),(-1,'rmallen'),(-1,'rmickol'),(-1,'rperigo'),(-1,'rsajulga'),(-1,'rwehrer'),(-1,'samroy'),(-1,'saptpurk'),(-1,'scanchi'),(-1,'schae234'),(-1,'schartlm'),(-1,'schitta'),(-1,'scigap'),(-1,'sclevey'),(-1,'sean1906'),(-1,'senxu'),(-1,'service'),(-1,'shanghai'),(-1,'sharnly3'),(-1,'shayyag'),(-1,'shengs'),(-1,'shore'),(-1,'shzh9814'),(-1,'sidpath'),(-1,'sirace'),(-1,'sjmiller'),(-1,'slaterl'),(-1,'smccaula'),(-1,'smm6'),(-1,'sp0090'),(-1,'sruthi12'),(-1,'ssalam'),(-1,'ssanders'),(-1,'ssg2394'),(-1,'ssmallen'),(-1,'ssteady'),(-1,'ssud2'),(-1,'steckm'),(-1,'stephd'),(-1,'swalke28'),(-1,'system'),(-1,'tantrung'),(-1,'tasmia'),(-1,'tassie'),(-1,'td160021'),(-1,'tenekod5'),(-1,'TG-ASC160018'),(-1,'TG-ASC170002'),(-1,'TG-ASC180056'),(-1,'TG-ATM160027'),(-1,'TG-ATM170024'),(-1,'TG-BCS180023'),(-1,'TG-BIO150062'),(-1,'TG-BIO160064'),(-1,'TG-BIO170096'),(-1,'TG-BIO170103'),(-1,'TG-CCR140004'),(-1,'TG-CCR160022'),(-1,'TG-CCR180043'),(-1,'TG-CCR180061'),(-1,'TG-CCR190013'),(-1,'TG-CDA170003'),(-1,'TG-CDA170008'),(-1,'TG-CDA170011'),(-1,'TG-CDA170013'),(-1,'TG-CDA180007'),(-1,'TG-CDA180009'),(-1,'TG-CHE080068N'),(-1,'TG-CIE160029'),(-1,'TG-CIE160047'),(-1,'TG-CIE160051'),(-1,'TG-CIE170007'),(-1,'TG-CIE170025'),(-1,'TG-CIE170055'),(-1,'TG-DBS160006'),(-1,'TG-DBS170008'),(-1,'TG-DBS170009'),(-1,'TG-DBS180009'),(-1,'TG-DEB180020'),(-1,'TG-EAR170011'),(-1,'TG-EAR170012'),(-1,'TG-EAR180009'),(-1,'TG-EAR180013'),(-1,'TG-EAR180028'),(-1,'TG-EAR190001'),(-1,'TG-EAR190021'),(-1,'TG-ENG170037'),(-1,'TG-GEO160010'),(-1,'TG-IBN140002'),(-1,'TG-IBN170017'),(-1,'TG-IRI160006'),(-1,'TG-IRI180017'),(-1,'TG-IRI180027'),(-1,'TG-IRI180028'),(-1,'TG-IRI190007'),(-1,'TG-MCB070039N'),(-1,'TG-MCB140147'),(-1,'TG-MCB160163'),(-1,'TG-NCR160005'),(-1,'TG-OCE170022'),(-1,'TG-PHY140033'),(-1,'TG-SES180024'),(-1,'TG-STA160002'),(-1,'TG-TRA150025'),(-1,'TG-TRA160003'),(-1,'TG-TRA160027'),(-1,'timkrock'),(-1,'tshep'),(-1,'tskluzac'),(-1,'tswetnam'),(-1,'tx160085'),(-1,'uma'),(15,'upendra'),(15,'virtual'),(15,'vortex2'),(15,'wfisher'),(15,'willarno'),(15,'wstuhr'),(15,'wzhy2000'),(15,'yclu'),(15,'yvanpij'),(79,'vlevkov'),(79,'vlflores'),(79,'zare'),(79,'zc8304'),(79,'zking'),(102,'vpenchv'),(102,'vwangia'),(102,'walling'),(102,'wang208'),(102,'wbt3'),(102,'weisi'),(102,'wsang'),(102,'wscreen'),(102,'xdmod'),(102,'ychatel'),(102,'yhung'),(102,'zealous'),(102,'zehra'),(102,'zonca');
/*!40000 ALTER TABLE `Cloud_pi___project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_pi___provider`
--

DROP TABLE IF EXISTS `Cloud_pi___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_pi___provider` (
  `pi` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`pi`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_pi___provider`
--

LOCK TABLES `Cloud_pi___provider` WRITE;
/*!40000 ALTER TABLE `Cloud_pi___provider` DISABLE KEYS */;
INSERT INTO `Cloud_pi___provider` VALUES (-1,1),(15,1),(79,1),(102,1);
/*!40000 ALTER TABLE `Cloud_pi___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_pi___resource`
--

DROP TABLE IF EXISTS `Cloud_pi___resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_pi___resource` (
  `pi` int(11) NOT NULL,
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`pi`,`resource`),
  KEY `idx_second_dimension` (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_pi___resource`
--

LOCK TABLES `Cloud_pi___resource` WRITE;
/*!40000 ALTER TABLE `Cloud_pi___resource` DISABLE KEYS */;
INSERT INTO `Cloud_pi___resource` VALUES (-1,9),(15,9),(79,9),(102,8),(102,9);
/*!40000 ALTER TABLE `Cloud_pi___resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_pi___submission_venue`
--

DROP TABLE IF EXISTS `Cloud_pi___submission_venue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_pi___submission_venue` (
  `pi` int(11) NOT NULL,
  `submission_venue` int(11) NOT NULL,
  PRIMARY KEY (`pi`,`submission_venue`),
  KEY `idx_second_dimension` (`submission_venue`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_pi___submission_venue`
--

LOCK TABLES `Cloud_pi___submission_venue` WRITE;
/*!40000 ALTER TABLE `Cloud_pi___submission_venue` DISABLE KEYS */;
INSERT INTO `Cloud_pi___submission_venue` VALUES (-1,3),(15,3),(79,3),(102,3);
/*!40000 ALTER TABLE `Cloud_pi___submission_venue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_pi___username`
--

DROP TABLE IF EXISTS `Cloud_pi___username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_pi___username` (
  `pi` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`pi`,`username`),
  KEY `idx_second_dimension` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_pi___username`
--

LOCK TABLES `Cloud_pi___username` WRITE;
/*!40000 ALTER TABLE `Cloud_pi___username` DISABLE KEYS */;
INSERT INTO `Cloud_pi___username` VALUES (-1,'aalmsaee'),(-1,'aashwani'),(-1,'abarber'),(-1,'aculich'),(-1,'adhage'),(-1,'adstew97'),(-1,'agopu'),(-1,'akamber2'),(-1,'akanna'),(-1,'akmore'),(-1,'akn752'),(-1,'alanguye'),(-1,'alexmah'),(-1,'allopatr'),(-1,'alwalsh'),(-1,'amco'),(-1,'amelung'),(-1,'amitj'),(-1,'andybeet'),(-1,'apitest'),(-1,'aralshi'),(-1,'astrobio'),(-1,'ataje'),(-1,'atrevino'),(-1,'aymen'),(-1,'bake1349'),(-1,'bberlin'),(-1,'beckbw'),(-1,'beshel'),(-1,'bhaakens'),(-1,'binod30'),(-1,'blakekas'),(-1,'bmsamuel'),(-1,'bohendo'),(-1,'bret'),(-1,'brhatton'),(-1,'brooksph'),(-1,'bsayre'),(-1,'cakers2'),(-1,'caninerv'),(-1,'cbjhnsn'),(-1,'cboettig'),(-1,'ccc010'),(-1,'ccompute'),(-1,'cdosborn'),(-1,'cdparra'),(-1,'cganote'),(-1,'cgrant'),(-1,'chanchal'),(-1,'chastang'),(-1,'cldixon'),(-1,'cmarnold'),(-1,'cmart'),(-1,'cwardgar'),(-1,'dagrawa2'),(-1,'danidub'),(-1,'dcooper3'),(-1,'ddvento'),(-1,'devon'),(-1,'dgilbert'),(-1,'dhanuman'),(-1,'dhaynes'),(-1,'dikim'),(-1,'dmm'),(-1,'dpazruiz'),(-1,'dtyoung'),(-1,'dyhancoc'),(-1,'eafgan'),(-1,'egforan'),(-1,'eknox'),(-1,'emre'),(-1,'fils'),(-1,'fpsom'),(-1,'gaojie22'),(-1,'geo'),(-1,'gjoshua'),(-1,'gmanipon'),(-1,'gonzalo'),(-1,'grcramer'),(-1,'grogers'),(-1,'gryanp'),(-1,'gspeyer'),(-1,'guow'),(-1,'hannac'),(-1,'hayashis'),(-1,'heena'),(-1,'henschel'),(-1,'hilaryk'),(-1,'hjnance'),(-1,'hudson89'),(-1,'hugogao'),(-1,'ianmacc'),(-1,'iarora'),(-1,'iparask'),(-1,'irberlui'),(-1,'ishv99'),(-1,'iwatson'),(-1,'j1axs01'),(-1,'jake1'),(-1,'jb557'),(-1,'jbadalam'),(-1,'jbaldo'),(-1,'jcali'),(-1,'jchuah'),(-1,'jdakka'),(-1,'jdv'),(-1,'jeovany7'),(-1,'jfischer'),(-1,'jhaber'),(-1,'jhallida'),(-1,'jhouse'),(-1,'jomlowe'),(-1,'josconno'),(-1,'jppeters'),(-1,'jpummil'),(-1,'jreadey'),(-1,'jrmales'),(-1,'jscottsf'),(-1,'jsdsmail'),(-1,'jselvam'),(-1,'jstubbs'),(-1,'julianp'),(-1,'jwzhao'),(-1,'kagra'),(-1,'kagross'),(-1,'kangplee'),(-1,'kausrini'),(-1,'kelumdi'),(-1,'kemelian'),(-1,'kloster'),(-1,'kmadappa'),(-1,'ktyle'),(-1,'kz1954'),(-1,'lalakl'),(-1,'lambert8'),(-1,'lbao235'),(-1,'lhin'),(-1,'ljcohen'),(-1,'ljosyula'),(-1,'lmundia'),(-1,'luzhixiu'),(-1,'madrina'),(-1,'maite'),(-1,'majdavis'),(-1,'mantholz'),(-1,'mapodaca'),(-1,'marcusc'),(-1,'marelize'),(-1,'mason25'),(-1,'mattremm'),(-1,'maxmck7'),(-1,'mckandes'),(-1,'megm'),(-1,'mesler'),(-1,'metrics'),(-1,'mfaraji'),(-1,'mhannonj'),(-1,'mhmurray'),(-1,'millera2'),(-1,'mjames'),(-1,'mkrenz'),(-1,'mniesen'),(-1,'mpierce'),(-1,'mscott'),(-1,'mspinks'),(-1,'mworinge'),(-1,'nardos'),(-1,'nathsnyd'),(-1,'nfrazier'),(-1,'nkern'),(-1,'nmebadi'),(-1,'noorabom'),(-1,'nova'),(-1,'nsokol'),(-1,'ntrip'),(-1,'nujwoo'),(-1,'nykim'),(-1,'padbrown'),(-1,'paulrad'),(-1,'paxton'),(-1,'pcpeters'),(-1,'phillity'),(-1,'plm02'),(-1,'pmiksza'),(-1,'pmoriano'),(-1,'ponyisi'),(-1,'ppani'),(-1,'pswargam'),(-1,'quietjen'),(-1,'radmatt'),(-1,'ramya1'),(-1,'rasc5939'),(-1,'rauta'),(-1,'rcampbel'),(-1,'rdooley'),(-1,'red'),(-1,'redcar'),(-1,'rfmeraz'),(-1,'rkalyana'),(-1,'rmallen'),(-1,'rmickol'),(-1,'rperigo'),(-1,'rsajulga'),(-1,'rsignell'),(-1,'rwehrer'),(-1,'rynge'),(-1,'samroy'),(-1,'saptpurk'),(-1,'sbaker01'),(-1,'scanchi'),(-1,'schae234'),(-1,'schartlm'),(-1,'schitta'),(-1,'scigap'),(-1,'sclevey'),(-1,'sean1906'),(-1,'senxu'),(-1,'shanghai'),(-1,'sharnly3'),(-1,'shayyag'),(-1,'shengs'),(-1,'shore'),(-1,'shzh9814'),(-1,'sidpath'),(-1,'sirace'),(-1,'sjmiller'),(-1,'slaterl'),(-1,'smccaula'),(-1,'smm6'),(-1,'sp0090'),(-1,'sruthi12'),(-1,'ssalam'),(-1,'ssanders'),(-1,'ssg2394'),(-1,'ssmallen'),(-1,'ssteady'),(-1,'ssud2'),(-1,'steckm'),(-1,'stephd'),(-1,'suderman'),(-1,'swalke28'),(-1,'tantrung'),(-1,'tasmia'),(-1,'tassie'),(-1,'td160021'),(-1,'tenekod5'),(-1,'tg455671'),(-1,'tg456058'),(-1,'tg457074'),(-1,'tg457210'),(-1,'tg457349'),(-1,'tg457649'),(-1,'tg829096'),(-1,'tg834267'),(-1,'tg834860'),(-1,'tg836876'),(-1,'tg837136'),(-1,'tg837611'),(-1,'tg839024'),(-1,'tg839371'),(-1,'tg841578'),(-1,'tg842548'),(-1,'tg853683'),(-1,'tg856781'),(-1,'tg857377'),(-1,'tg857485'),(-1,'tg857674'),(-1,'tg857711'),(-1,'tg857713'),(-1,'tg857714'),(-1,'tg857970'),(-1,'tg858209'),(-1,'tg858245'),(-1,'tg858635'),(-1,'tg858636'),(-1,'tg858644'),(-1,'timkrock'),(-1,'tshep'),(-1,'tskluzac'),(-1,'tswetnam'),(-1,'tx160085'),(-1,'uma'),(-1,'UNKNOWN'),(-1,'upendra'),(-1,'ux445032'),(-1,'vast'),(-1,'vaughn'),(-1,'willis8'),(-1,'xcgalaxy'),(-1,'xwj'),(15,'upendra'),(15,'virtual'),(15,'vortex2'),(15,'wfisher'),(15,'willarno'),(15,'wstuhr'),(15,'wzhy2000'),(15,'yclu'),(15,'yvanpij'),(79,'vlevkov'),(79,'vlflores'),(79,'zare'),(79,'zc8304'),(79,'zking'),(102,'pcp'),(102,'setusca'),(102,'vpenchv'),(102,'vwangia'),(102,'walling'),(102,'wang208'),(102,'wbt3'),(102,'weisi'),(102,'wsang'),(102,'wscreen'),(102,'ychatel'),(102,'yerwa'),(102,'yhung'),(102,'ylwwa'),(102,'zehra'),(102,'zonca');
/*!40000 ALTER TABLE `Cloud_pi___username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_pi___vm_size`
--

DROP TABLE IF EXISTS `Cloud_pi___vm_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_pi___vm_size` (
  `pi` int(11) NOT NULL,
  `vm_size` int(4) NOT NULL,
  PRIMARY KEY (`pi`,`vm_size`),
  KEY `idx_second_dimension` (`vm_size`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_pi___vm_size`
--

LOCK TABLES `Cloud_pi___vm_size` WRITE;
/*!40000 ALTER TABLE `Cloud_pi___vm_size` DISABLE KEYS */;
INSERT INTO `Cloud_pi___vm_size` VALUES (-1,1),(-1,2),(-1,3),(-1,4),(-1,6),(-1,7),(15,1),(15,2),(15,3),(15,4),(15,6),(15,7),(79,1),(79,2),(79,3),(79,6),(102,1),(102,2),(102,3),(102,4),(102,7);
/*!40000 ALTER TABLE `Cloud_pi___vm_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_pi___vm_size_memory`
--

DROP TABLE IF EXISTS `Cloud_pi___vm_size_memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_pi___vm_size_memory` (
  `pi` int(11) NOT NULL,
  `vm_size_memory` int(4) NOT NULL,
  PRIMARY KEY (`pi`,`vm_size_memory`),
  KEY `idx_second_dimension` (`vm_size_memory`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_pi___vm_size_memory`
--

LOCK TABLES `Cloud_pi___vm_size_memory` WRITE;
/*!40000 ALTER TABLE `Cloud_pi___vm_size_memory` DISABLE KEYS */;
INSERT INTO `Cloud_pi___vm_size_memory` VALUES (-1,2),(-1,3),(-1,4),(-1,5),(-1,6),(-1,7),(15,2),(15,4),(15,5),(15,6),(15,7),(79,2),(79,4),(79,6),(102,1),(102,2),(102,3),(102,4),(102,5),(102,6),(102,7);
/*!40000 ALTER TABLE `Cloud_pi___vm_size_memory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_project`
--

DROP TABLE IF EXISTS `Cloud_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_project` (
  `project` varchar(256) NOT NULL,
  PRIMARY KEY (`project`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_project`
--

LOCK TABLES `Cloud_project` WRITE;
/*!40000 ALTER TABLE `Cloud_project` DISABLE KEYS */;
INSERT INTO `Cloud_project` VALUES ('aalmsaee'),('aashwani'),('abarber'),('adhage'),('adstew97'),('agopu'),('akamber2'),('akanna'),('akmore'),('akn752'),('alanguye'),('allopatr'),('amco'),('amelung'),('amitj'),('andybeet'),('aralshi'),('astrobio'),('ataje'),('atrevino'),('aymen'),('bake1349'),('bberlin'),('beckbw'),('beshel'),('bhaakens'),('binod30'),('blakekas'),('bmsamuel'),('bohendo'),('bret'),('brooksph'),('bsayre'),('cakers2'),('caninerv'),('cbjhnsn'),('cboettig'),('ccc010'),('cdosborn'),('cdparra'),('cganote'),('cgrant'),('chanchal'),('chastang'),('cldixon'),('cmarnold'),('cmart'),('dagrawa2'),('danidub'),('dcooper3'),('ddvento'),('devon'),('dgilbert'),('dhaynes'),('dikim'),('dmm'),('dpazruiz'),('dtyoung'),('dyhancoc'),('egforan'),('eknox'),('emre'),('fils'),('fpsom'),('Galaxy_Persistant_Services'),('gaojie22'),('gjoshua'),('grcramer'),('gryanp'),('gspeyer'),('guow'),('heena'),('henschel'),('hilaryk'),('hjnance'),('hpfs'),('hps'),('hudson89'),('hugogao'),('ianmacc'),('iparask'),('irberlui'),('ishv99'),('j1axs01'),('jake1'),('jb557'),('jbadalam'),('jbaldo'),('jcali'),('jchuah'),('jdakka'),('jdv'),('jeovany7'),('jfischer'),('jhaber'),('jhallida'),('jhouse'),('jomlowe'),('josconno'),('jppeters'),('jpummil'),('jreadey'),('jrmales'),('jsdsmail'),('jselvam'),('julianp'),('jwzhao'),('kagra'),('kagross'),('kangplee'),('kausrini'),('kelumdi'),('kemelian'),('kloster'),('kmadappa'),('ktyle'),('kz1954'),('lalakl'),('lbao235'),('lhin'),('ljcohen'),('ljosyula'),('lmundia'),('luzhixiu'),('madrina'),('maite'),('majdavis'),('mantholz'),('marcusc'),('marelize'),('mason25'),('mattremm'),('maxmck7'),('megm'),('metrics'),('mfaraji'),('mhannonj'),('mhmurray'),('millera2'),('mjames'),('mkrenz'),('mniesen'),('mscott'),('mspinks'),('mworinge'),('nardos'),('nathsnyd'),('nfrazier'),('nkern'),('nmebadi'),('noorabom'),('nsokol'),('ntrip'),('nujwoo'),('nykim'),('padbrown'),('paxton'),('pcpeters'),('phillity'),('plm02'),('pmiksza'),('pmoriano'),('ppani'),('pswargam'),('quietjen'),('radmatt'),('ramya1'),('rasc5939'),('rauta'),('rcampbel'),('redcar'),('rfmeraz'),('rkalyana'),('rmallen'),('rmickol'),('rperigo'),('rsajulga'),('rwehrer'),('samroy'),('saptpurk'),('scanchi'),('schae234'),('schartlm'),('schitta'),('scigap'),('sclevey'),('sean1906'),('senxu'),('service'),('shanghai'),('sharnly3'),('shayyag'),('shengs'),('shore'),('shzh9814'),('sidpath'),('sirace'),('sjmiller'),('slaterl'),('smccaula'),('smm6'),('sp0090'),('sruthi12'),('ssalam'),('ssanders'),('ssg2394'),('ssmallen'),('ssteady'),('ssud2'),('steckm'),('stephd'),('swalke28'),('system'),('tantrung'),('tasmia'),('tassie'),('td160021'),('tenekod5'),('TG-ASC160018'),('TG-ASC170002'),('TG-ASC180056'),('TG-ATM160027'),('TG-ATM170024'),('TG-BCS180023'),('TG-BIO150062'),('TG-BIO160064'),('TG-BIO170096'),('TG-BIO170103'),('TG-CCR140004'),('TG-CCR160022'),('TG-CCR180043'),('TG-CCR180061'),('TG-CCR190013'),('TG-CDA170003'),('TG-CDA170008'),('TG-CDA170011'),('TG-CDA170013'),('TG-CDA180007'),('TG-CDA180009'),('TG-CHE080068N'),('TG-CIE160029'),('TG-CIE160047'),('TG-CIE160051'),('TG-CIE170007'),('TG-CIE170025'),('TG-CIE170055'),('TG-DBS160006'),('TG-DBS170008'),('TG-DBS170009'),('TG-DBS180009'),('TG-DEB180020'),('TG-EAR170011'),('TG-EAR170012'),('TG-EAR180009'),('TG-EAR180013'),('TG-EAR180028'),('TG-EAR190001'),('TG-EAR190021'),('TG-ENG170037'),('TG-GEO160010'),('TG-IBN140002'),('TG-IBN170017'),('TG-IRI160006'),('TG-IRI180017'),('TG-IRI180027'),('TG-IRI180028'),('TG-IRI190007'),('TG-MCB070039N'),('TG-MCB140147'),('TG-MCB160163'),('TG-NCR160005'),('TG-OCE170022'),('TG-PHY140033'),('TG-SES180024'),('TG-STA160002'),('TG-TRA150025'),('TG-TRA160003'),('TG-TRA160027'),('timkrock'),('tshep'),('tskluzac'),('tswetnam'),('tx160085'),('uma'),('upendra'),('virtual'),('vlevkov'),('vlflores'),('vortex2'),('vpenchv'),('vwangia'),('walling'),('wang208'),('wbt3'),('weisi'),('wfisher'),('willarno'),('wsang'),('wscreen'),('wstuhr'),('wzhy2000'),('xdmod'),('ychatel'),('yclu'),('yhung'),('yvanpij'),('zare'),('zc8304'),('zealous'),('zehra'),('zking'),('zonca');
/*!40000 ALTER TABLE `Cloud_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_project___provider`
--

DROP TABLE IF EXISTS `Cloud_project___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_project___provider` (
  `project` varchar(256) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`project`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_project___provider`
--

LOCK TABLES `Cloud_project___provider` WRITE;
/*!40000 ALTER TABLE `Cloud_project___provider` DISABLE KEYS */;
INSERT INTO `Cloud_project___provider` VALUES ('aalmsaee',1),('aashwani',1),('abarber',1),('adhage',1),('adstew97',1),('agopu',1),('akamber2',1),('akanna',1),('akmore',1),('akn752',1),('alanguye',1),('allopatr',1),('amco',1),('amelung',1),('amitj',1),('andybeet',1),('aralshi',1),('astrobio',1),('ataje',1),('atrevino',1),('aymen',1),('bake1349',1),('bberlin',1),('beckbw',1),('beshel',1),('bhaakens',1),('binod30',1),('blakekas',1),('bmsamuel',1),('bohendo',1),('bret',1),('brooksph',1),('bsayre',1),('cakers2',1),('caninerv',1),('cbjhnsn',1),('cboettig',1),('ccc010',1),('cdosborn',1),('cdparra',1),('cganote',1),('cgrant',1),('chanchal',1),('chastang',1),('cldixon',1),('cmarnold',1),('cmart',1),('dagrawa2',1),('danidub',1),('dcooper3',1),('ddvento',1),('devon',1),('dgilbert',1),('dhaynes',1),('dikim',1),('dmm',1),('dpazruiz',1),('dtyoung',1),('dyhancoc',1),('egforan',1),('eknox',1),('emre',1),('fils',1),('fpsom',1),('Galaxy_Persistant_Services',1),('gaojie22',1),('gjoshua',1),('grcramer',1),('gryanp',1),('gspeyer',1),('guow',1),('heena',1),('henschel',1),('hilaryk',1),('hjnance',1),('hpfs',1),('hps',1),('hudson89',1),('hugogao',1),('ianmacc',1),('iparask',1),('irberlui',1),('ishv99',1),('j1axs01',1),('jake1',1),('jb557',1),('jbadalam',1),('jbaldo',1),('jcali',1),('jchuah',1),('jdakka',1),('jdv',1),('jeovany7',1),('jfischer',1),('jhaber',1),('jhallida',1),('jhouse',1),('jomlowe',1),('josconno',1),('jppeters',1),('jpummil',1),('jreadey',1),('jrmales',1),('jsdsmail',1),('jselvam',1),('julianp',1),('jwzhao',1),('kagra',1),('kagross',1),('kangplee',1),('kausrini',1),('kelumdi',1),('kemelian',1),('kloster',1),('kmadappa',1),('ktyle',1),('kz1954',1),('lalakl',1),('lbao235',1),('lhin',1),('ljcohen',1),('ljosyula',1),('lmundia',1),('luzhixiu',1),('madrina',1),('maite',1),('majdavis',1),('mantholz',1),('marcusc',1),('marelize',1),('mason25',1),('mattremm',1),('maxmck7',1),('megm',1),('metrics',1),('mfaraji',1),('mhannonj',1),('mhmurray',1),('millera2',1),('mjames',1),('mkrenz',1),('mniesen',1),('mscott',1),('mspinks',1),('mworinge',1),('nardos',1),('nathsnyd',1),('nfrazier',1),('nkern',1),('nmebadi',1),('noorabom',1),('nsokol',1),('ntrip',1),('nujwoo',1),('nykim',1),('padbrown',1),('paxton',1),('pcpeters',1),('phillity',1),('plm02',1),('pmiksza',1),('pmoriano',1),('ppani',1),('pswargam',1),('quietjen',1),('radmatt',1),('ramya1',1),('rasc5939',1),('rauta',1),('rcampbel',1),('redcar',1),('rfmeraz',1),('rkalyana',1),('rmallen',1),('rmickol',1),('rperigo',1),('rsajulga',1),('rwehrer',1),('samroy',1),('saptpurk',1),('scanchi',1),('schae234',1),('schartlm',1),('schitta',1),('scigap',1),('sclevey',1),('sean1906',1),('senxu',1),('service',1),('shanghai',1),('sharnly3',1),('shayyag',1),('shengs',1),('shore',1),('shzh9814',1),('sidpath',1),('sirace',1),('sjmiller',1),('slaterl',1),('smccaula',1),('smm6',1),('sp0090',1),('sruthi12',1),('ssalam',1),('ssanders',1),('ssg2394',1),('ssmallen',1),('ssteady',1),('ssud2',1),('steckm',1),('stephd',1),('swalke28',1),('system',1),('tantrung',1),('tasmia',1),('tassie',1),('td160021',1),('tenekod5',1),('TG-ASC160018',1),('TG-ASC170002',1),('TG-ASC180056',1),('TG-ATM160027',1),('TG-ATM170024',1),('TG-BCS180023',1),('TG-BIO150062',1),('TG-BIO160064',1),('TG-BIO170096',1),('TG-BIO170103',1),('TG-CCR140004',1),('TG-CCR160022',1),('TG-CCR180043',1),('TG-CCR180061',1),('TG-CCR190013',1),('TG-CDA170003',1),('TG-CDA170008',1),('TG-CDA170011',1),('TG-CDA170013',1),('TG-CDA180007',1),('TG-CDA180009',1),('TG-CHE080068N',1),('TG-CIE160029',1),('TG-CIE160047',1),('TG-CIE160051',1),('TG-CIE170007',1),('TG-CIE170025',1),('TG-CIE170055',1),('TG-DBS160006',1),('TG-DBS170008',1),('TG-DBS170009',1),('TG-DBS180009',1),('TG-DEB180020',1),('TG-EAR170011',1),('TG-EAR170012',1),('TG-EAR180009',1),('TG-EAR180013',1),('TG-EAR180028',1),('TG-EAR190001',1),('TG-EAR190021',1),('TG-ENG170037',1),('TG-GEO160010',1),('TG-IBN140002',1),('TG-IBN170017',1),('TG-IRI160006',1),('TG-IRI180017',1),('TG-IRI180027',1),('TG-IRI180028',1),('TG-IRI190007',1),('TG-MCB070039N',1),('TG-MCB140147',1),('TG-MCB160163',1),('TG-NCR160005',1),('TG-OCE170022',1),('TG-PHY140033',1),('TG-SES180024',1),('TG-STA160002',1),('TG-TRA150025',1),('TG-TRA160003',1),('TG-TRA160027',1),('timkrock',1),('tshep',1),('tskluzac',1),('tswetnam',1),('tx160085',1),('uma',1),('upendra',1),('virtual',1),('vlevkov',1),('vlflores',1),('vortex2',1),('vpenchv',1),('vwangia',1),('walling',1),('wang208',1),('wbt3',1),('weisi',1),('wfisher',1),('willarno',1),('wsang',1),('wscreen',1),('wstuhr',1),('wzhy2000',1),('xdmod',1),('ychatel',1),('yclu',1),('yhung',1),('yvanpij',1),('zare',1),('zc8304',1),('zealous',1),('zehra',1),('zking',1),('zonca',1);
/*!40000 ALTER TABLE `Cloud_project___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_provider`
--

DROP TABLE IF EXISTS `Cloud_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_provider` (
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_provider`
--

LOCK TABLES `Cloud_provider` WRITE;
/*!40000 ALTER TABLE `Cloud_provider` DISABLE KEYS */;
INSERT INTO `Cloud_provider` VALUES (1);
/*!40000 ALTER TABLE `Cloud_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_provider___resource`
--

DROP TABLE IF EXISTS `Cloud_provider___resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_provider___resource` (
  `provider` int(11) NOT NULL,
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`provider`,`resource`),
  KEY `idx_second_dimension` (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_provider___resource`
--

LOCK TABLES `Cloud_provider___resource` WRITE;
/*!40000 ALTER TABLE `Cloud_provider___resource` DISABLE KEYS */;
INSERT INTO `Cloud_provider___resource` VALUES (1,8),(1,9);
/*!40000 ALTER TABLE `Cloud_provider___resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_provider___submission_venue`
--

DROP TABLE IF EXISTS `Cloud_provider___submission_venue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_provider___submission_venue` (
  `provider` int(11) NOT NULL,
  `submission_venue` int(11) NOT NULL,
  PRIMARY KEY (`provider`,`submission_venue`),
  KEY `idx_second_dimension` (`submission_venue`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_provider___submission_venue`
--

LOCK TABLES `Cloud_provider___submission_venue` WRITE;
/*!40000 ALTER TABLE `Cloud_provider___submission_venue` DISABLE KEYS */;
INSERT INTO `Cloud_provider___submission_venue` VALUES (1,3);
/*!40000 ALTER TABLE `Cloud_provider___submission_venue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_provider___username`
--

DROP TABLE IF EXISTS `Cloud_provider___username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_provider___username` (
  `provider` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`provider`,`username`),
  KEY `idx_second_dimension` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_provider___username`
--

LOCK TABLES `Cloud_provider___username` WRITE;
/*!40000 ALTER TABLE `Cloud_provider___username` DISABLE KEYS */;
INSERT INTO `Cloud_provider___username` VALUES (1,'aalmsaee'),(1,'aashwani'),(1,'abarber'),(1,'aculich'),(1,'adhage'),(1,'adstew97'),(1,'agopu'),(1,'akamber2'),(1,'akanna'),(1,'akmore'),(1,'akn752'),(1,'alanguye'),(1,'alexmah'),(1,'allopatr'),(1,'alwalsh'),(1,'amco'),(1,'amelung'),(1,'amitj'),(1,'andybeet'),(1,'apitest'),(1,'aralshi'),(1,'astrobio'),(1,'ataje'),(1,'atrevino'),(1,'aymen'),(1,'bake1349'),(1,'bberlin'),(1,'beckbw'),(1,'beshel'),(1,'bhaakens'),(1,'binod30'),(1,'blakekas'),(1,'bmsamuel'),(1,'bohendo'),(1,'bret'),(1,'brhatton'),(1,'brooksph'),(1,'bsayre'),(1,'cakers2'),(1,'caninerv'),(1,'cbjhnsn'),(1,'cboettig'),(1,'ccc010'),(1,'ccompute'),(1,'cdosborn'),(1,'cdparra'),(1,'cganote'),(1,'cgrant'),(1,'chanchal'),(1,'chastang'),(1,'cldixon'),(1,'cmarnold'),(1,'cmart'),(1,'cwardgar'),(1,'dagrawa2'),(1,'danidub'),(1,'dcooper3'),(1,'ddvento'),(1,'devon'),(1,'dgilbert'),(1,'dhanuman'),(1,'dhaynes'),(1,'dikim'),(1,'dmm'),(1,'dpazruiz'),(1,'dtyoung'),(1,'dyhancoc'),(1,'eafgan'),(1,'egforan'),(1,'eknox'),(1,'emre'),(1,'fils'),(1,'fpsom'),(1,'gaojie22'),(1,'geo'),(1,'gjoshua'),(1,'gmanipon'),(1,'gonzalo'),(1,'grcramer'),(1,'grogers'),(1,'gryanp'),(1,'gspeyer'),(1,'guow'),(1,'hannac'),(1,'hayashis'),(1,'heena'),(1,'henschel'),(1,'hilaryk'),(1,'hjnance'),(1,'hudson89'),(1,'hugogao'),(1,'ianmacc'),(1,'iarora'),(1,'iparask'),(1,'irberlui'),(1,'ishv99'),(1,'iwatson'),(1,'j1axs01'),(1,'jake1'),(1,'jb557'),(1,'jbadalam'),(1,'jbaldo'),(1,'jcali'),(1,'jchuah'),(1,'jdakka'),(1,'jdv'),(1,'jeovany7'),(1,'jfischer'),(1,'jhaber'),(1,'jhallida'),(1,'jhouse'),(1,'jomlowe'),(1,'josconno'),(1,'jppeters'),(1,'jpummil'),(1,'jreadey'),(1,'jrmales'),(1,'jscottsf'),(1,'jsdsmail'),(1,'jselvam'),(1,'jstubbs'),(1,'julianp'),(1,'jwzhao'),(1,'kagra'),(1,'kagross'),(1,'kangplee'),(1,'kausrini'),(1,'kelumdi'),(1,'kemelian'),(1,'kloster'),(1,'kmadappa'),(1,'ktyle'),(1,'kz1954'),(1,'lalakl'),(1,'lambert8'),(1,'lbao235'),(1,'lhin'),(1,'ljcohen'),(1,'ljosyula'),(1,'lmundia'),(1,'luzhixiu'),(1,'madrina'),(1,'maite'),(1,'majdavis'),(1,'mantholz'),(1,'mapodaca'),(1,'marcusc'),(1,'marelize'),(1,'mason25'),(1,'mattremm'),(1,'maxmck7'),(1,'mckandes'),(1,'megm'),(1,'mesler'),(1,'metrics'),(1,'mfaraji'),(1,'mhannonj'),(1,'mhmurray'),(1,'millera2'),(1,'mjames'),(1,'mkrenz'),(1,'mniesen'),(1,'mpierce'),(1,'mscott'),(1,'mspinks'),(1,'mworinge'),(1,'nardos'),(1,'nathsnyd'),(1,'nfrazier'),(1,'nkern'),(1,'nmebadi'),(1,'noorabom'),(1,'nova'),(1,'nsokol'),(1,'ntrip'),(1,'nujwoo'),(1,'nykim'),(1,'padbrown'),(1,'paulrad'),(1,'paxton'),(1,'pcp'),(1,'pcpeters'),(1,'phillity'),(1,'plm02'),(1,'pmiksza'),(1,'pmoriano'),(1,'ponyisi'),(1,'ppani'),(1,'pswargam'),(1,'quietjen'),(1,'radmatt'),(1,'ramya1'),(1,'rasc5939'),(1,'rauta'),(1,'rcampbel'),(1,'rdooley'),(1,'red'),(1,'redcar'),(1,'rfmeraz'),(1,'rkalyana'),(1,'rmallen'),(1,'rmickol'),(1,'rperigo'),(1,'rsajulga'),(1,'rsignell'),(1,'rwehrer'),(1,'rynge'),(1,'samroy'),(1,'saptpurk'),(1,'sbaker01'),(1,'scanchi'),(1,'schae234'),(1,'schartlm'),(1,'schitta'),(1,'scigap'),(1,'sclevey'),(1,'sean1906'),(1,'senxu'),(1,'setusca'),(1,'shanghai'),(1,'sharnly3'),(1,'shayyag'),(1,'shengs'),(1,'shore'),(1,'shzh9814'),(1,'sidpath'),(1,'sirace'),(1,'sjmiller'),(1,'slaterl'),(1,'smccaula'),(1,'smm6'),(1,'sp0090'),(1,'sruthi12'),(1,'ssalam'),(1,'ssanders'),(1,'ssg2394'),(1,'ssmallen'),(1,'ssteady'),(1,'ssud2'),(1,'steckm'),(1,'stephd'),(1,'suderman'),(1,'swalke28'),(1,'tantrung'),(1,'tasmia'),(1,'tassie'),(1,'td160021'),(1,'tenekod5'),(1,'tg455671'),(1,'tg456058'),(1,'tg457074'),(1,'tg457210'),(1,'tg457349'),(1,'tg457649'),(1,'tg829096'),(1,'tg834267'),(1,'tg834860'),(1,'tg836876'),(1,'tg837136'),(1,'tg837611'),(1,'tg839024'),(1,'tg839371'),(1,'tg841578'),(1,'tg842548'),(1,'tg853683'),(1,'tg856781'),(1,'tg857377'),(1,'tg857485'),(1,'tg857674'),(1,'tg857711'),(1,'tg857713'),(1,'tg857714'),(1,'tg857970'),(1,'tg858209'),(1,'tg858245'),(1,'tg858635'),(1,'tg858636'),(1,'tg858644'),(1,'timkrock'),(1,'tshep'),(1,'tskluzac'),(1,'tswetnam'),(1,'tx160085'),(1,'uma'),(1,'UNKNOWN'),(1,'upendra'),(1,'ux445032'),(1,'vast'),(1,'vaughn'),(1,'virtual'),(1,'vlevkov'),(1,'vlflores'),(1,'vortex2'),(1,'vpenchv'),(1,'vwangia'),(1,'walling'),(1,'wang208'),(1,'wbt3'),(1,'weisi'),(1,'wfisher'),(1,'willarno'),(1,'willis8'),(1,'wsang'),(1,'wscreen'),(1,'wstuhr'),(1,'wzhy2000'),(1,'xcgalaxy'),(1,'xwj'),(1,'ychatel'),(1,'yclu'),(1,'yerwa'),(1,'yhung'),(1,'ylwwa'),(1,'yvanpij'),(1,'zare'),(1,'zc8304'),(1,'zehra'),(1,'zking'),(1,'zonca');
/*!40000 ALTER TABLE `Cloud_provider___username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_provider___vm_size`
--

DROP TABLE IF EXISTS `Cloud_provider___vm_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_provider___vm_size` (
  `provider` int(11) NOT NULL,
  `vm_size` int(4) NOT NULL,
  PRIMARY KEY (`provider`,`vm_size`),
  KEY `idx_second_dimension` (`vm_size`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_provider___vm_size`
--

LOCK TABLES `Cloud_provider___vm_size` WRITE;
/*!40000 ALTER TABLE `Cloud_provider___vm_size` DISABLE KEYS */;
INSERT INTO `Cloud_provider___vm_size` VALUES (1,1),(1,2),(1,3),(1,4),(1,6),(1,7);
/*!40000 ALTER TABLE `Cloud_provider___vm_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_provider___vm_size_memory`
--

DROP TABLE IF EXISTS `Cloud_provider___vm_size_memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_provider___vm_size_memory` (
  `provider` int(11) NOT NULL,
  `vm_size_memory` int(4) NOT NULL,
  PRIMARY KEY (`provider`,`vm_size_memory`),
  KEY `idx_second_dimension` (`vm_size_memory`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_provider___vm_size_memory`
--

LOCK TABLES `Cloud_provider___vm_size_memory` WRITE;
/*!40000 ALTER TABLE `Cloud_provider___vm_size_memory` DISABLE KEYS */;
INSERT INTO `Cloud_provider___vm_size_memory` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7);
/*!40000 ALTER TABLE `Cloud_provider___vm_size_memory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_resource`
--

DROP TABLE IF EXISTS `Cloud_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_resource` (
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_resource`
--

LOCK TABLES `Cloud_resource` WRITE;
/*!40000 ALTER TABLE `Cloud_resource` DISABLE KEYS */;
INSERT INTO `Cloud_resource` VALUES (8),(9);
/*!40000 ALTER TABLE `Cloud_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_submission_venue`
--

DROP TABLE IF EXISTS `Cloud_submission_venue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_submission_venue` (
  `submission_venue` int(11) NOT NULL,
  PRIMARY KEY (`submission_venue`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_submission_venue`
--

LOCK TABLES `Cloud_submission_venue` WRITE;
/*!40000 ALTER TABLE `Cloud_submission_venue` DISABLE KEYS */;
INSERT INTO `Cloud_submission_venue` VALUES (3);
/*!40000 ALTER TABLE `Cloud_submission_venue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_username`
--

DROP TABLE IF EXISTS `Cloud_username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_username` (
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_username`
--

LOCK TABLES `Cloud_username` WRITE;
/*!40000 ALTER TABLE `Cloud_username` DISABLE KEYS */;
INSERT INTO `Cloud_username` VALUES ('aalmsaee'),('aashwani'),('abarber'),('aculich'),('adhage'),('adstew97'),('agopu'),('akamber2'),('akanna'),('akmore'),('akn752'),('alanguye'),('alexmah'),('allopatr'),('alwalsh'),('amco'),('amelung'),('amitj'),('andybeet'),('apitest'),('aralshi'),('astrobio'),('ataje'),('atrevino'),('aymen'),('bake1349'),('bberlin'),('beckbw'),('beshel'),('bhaakens'),('binod30'),('blakekas'),('bmsamuel'),('bohendo'),('bret'),('brhatton'),('brooksph'),('bsayre'),('cakers2'),('caninerv'),('cbjhnsn'),('cboettig'),('ccc010'),('ccompute'),('cdosborn'),('cdparra'),('cganote'),('cgrant'),('chanchal'),('chastang'),('cldixon'),('cmarnold'),('cmart'),('cwardgar'),('dagrawa2'),('danidub'),('dcooper3'),('ddvento'),('devon'),('dgilbert'),('dhanuman'),('dhaynes'),('dikim'),('dmm'),('dpazruiz'),('dtyoung'),('dyhancoc'),('eafgan'),('egforan'),('eknox'),('emre'),('fils'),('fpsom'),('gaojie22'),('geo'),('gjoshua'),('gmanipon'),('gonzalo'),('grcramer'),('grogers'),('gryanp'),('gspeyer'),('guow'),('hannac'),('hayashis'),('heena'),('henschel'),('hilaryk'),('hjnance'),('hudson89'),('hugogao'),('ianmacc'),('iarora'),('iparask'),('irberlui'),('ishv99'),('iwatson'),('j1axs01'),('jake1'),('jb557'),('jbadalam'),('jbaldo'),('jcali'),('jchuah'),('jdakka'),('jdv'),('jeovany7'),('jfischer'),('jhaber'),('jhallida'),('jhouse'),('jomlowe'),('josconno'),('jppeters'),('jpummil'),('jreadey'),('jrmales'),('jscottsf'),('jsdsmail'),('jselvam'),('jstubbs'),('julianp'),('jwzhao'),('kagra'),('kagross'),('kangplee'),('kausrini'),('kelumdi'),('kemelian'),('kloster'),('kmadappa'),('ktyle'),('kz1954'),('lalakl'),('lambert8'),('lbao235'),('lhin'),('ljcohen'),('ljosyula'),('lmundia'),('luzhixiu'),('madrina'),('maite'),('majdavis'),('mantholz'),('mapodaca'),('marcusc'),('marelize'),('mason25'),('mattremm'),('maxmck7'),('mckandes'),('megm'),('mesler'),('metrics'),('mfaraji'),('mhannonj'),('mhmurray'),('millera2'),('mjames'),('mkrenz'),('mniesen'),('mpierce'),('mscott'),('mspinks'),('mworinge'),('nardos'),('nathsnyd'),('nfrazier'),('nkern'),('nmebadi'),('noorabom'),('nova'),('nsokol'),('ntrip'),('nujwoo'),('nykim'),('padbrown'),('paulrad'),('paxton'),('pcp'),('pcpeters'),('phillity'),('plm02'),('pmiksza'),('pmoriano'),('ponyisi'),('ppani'),('pswargam'),('quietjen'),('radmatt'),('ramya1'),('rasc5939'),('rauta'),('rcampbel'),('rdooley'),('red'),('redcar'),('rfmeraz'),('rkalyana'),('rmallen'),('rmickol'),('rperigo'),('rsajulga'),('rsignell'),('rwehrer'),('rynge'),('samroy'),('saptpurk'),('sbaker01'),('scanchi'),('schae234'),('schartlm'),('schitta'),('scigap'),('sclevey'),('sean1906'),('senxu'),('setusca'),('shanghai'),('sharnly3'),('shayyag'),('shengs'),('shore'),('shzh9814'),('sidpath'),('sirace'),('sjmiller'),('slaterl'),('smccaula'),('smm6'),('sp0090'),('sruthi12'),('ssalam'),('ssanders'),('ssg2394'),('ssmallen'),('ssteady'),('ssud2'),('steckm'),('stephd'),('suderman'),('swalke28'),('tantrung'),('tasmia'),('tassie'),('td160021'),('tenekod5'),('tg455671'),('tg456058'),('tg457074'),('tg457210'),('tg457349'),('tg457649'),('tg829096'),('tg834267'),('tg834860'),('tg836876'),('tg837136'),('tg837611'),('tg839024'),('tg839371'),('tg841578'),('tg842548'),('tg853683'),('tg856781'),('tg857377'),('tg857485'),('tg857674'),('tg857711'),('tg857713'),('tg857714'),('tg857970'),('tg858209'),('tg858245'),('tg858635'),('tg858636'),('tg858644'),('timkrock'),('tshep'),('tskluzac'),('tswetnam'),('tx160085'),('uma'),('UNKNOWN'),('upendra'),('ux445032'),('vast'),('vaughn'),('virtual'),('vlevkov'),('vlflores'),('vortex2'),('vpenchv'),('vwangia'),('walling'),('wang208'),('wbt3'),('weisi'),('wfisher'),('willarno'),('willis8'),('wsang'),('wscreen'),('wstuhr'),('wzhy2000'),('xcgalaxy'),('xwj'),('ychatel'),('yclu'),('yerwa'),('yhung'),('ylwwa'),('yvanpij'),('zare'),('zc8304'),('zehra'),('zking'),('zonca');
/*!40000 ALTER TABLE `Cloud_username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_vm_size`
--

DROP TABLE IF EXISTS `Cloud_vm_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_vm_size` (
  `vm_size` int(4) NOT NULL,
  PRIMARY KEY (`vm_size`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_vm_size`
--

LOCK TABLES `Cloud_vm_size` WRITE;
/*!40000 ALTER TABLE `Cloud_vm_size` DISABLE KEYS */;
INSERT INTO `Cloud_vm_size` VALUES (1),(2),(3),(4),(6),(7);
/*!40000 ALTER TABLE `Cloud_vm_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cloud_vm_size_memory`
--

DROP TABLE IF EXISTS `Cloud_vm_size_memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cloud_vm_size_memory` (
  `vm_size_memory` int(4) NOT NULL,
  PRIMARY KEY (`vm_size_memory`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cloud_vm_size_memory`
--

LOCK TABLES `Cloud_vm_size_memory` WRITE;
/*!40000 ALTER TABLE `Cloud_vm_size_memory` DISABLE KEYS */;
INSERT INTO `Cloud_vm_size_memory` VALUES (1),(2),(3),(4),(5),(6),(7);
/*!40000 ALTER TABLE `Cloud_vm_size_memory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_fieldofscience`
--

DROP TABLE IF EXISTS `Jobs_fieldofscience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_fieldofscience` (
  `fieldofscience` int(11) NOT NULL,
  PRIMARY KEY (`fieldofscience`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_fieldofscience`
--

LOCK TABLES `Jobs_fieldofscience` WRITE;
/*!40000 ALTER TABLE `Jobs_fieldofscience` DISABLE KEYS */;
INSERT INTO `Jobs_fieldofscience` VALUES (10),(44),(45),(47),(49),(53),(55),(57),(59),(60),(61),(65),(68),(69),(70),(71),(72),(74),(81),(84),(88),(90),(91),(93),(94),(97),(98),(99),(112),(114),(115),(119),(122),(123),(124),(126),(127),(137),(138),(139);
/*!40000 ALTER TABLE `Jobs_fieldofscience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_fieldofscience___person`
--

DROP TABLE IF EXISTS `Jobs_fieldofscience___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_fieldofscience___person` (
  `fieldofscience` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`fieldofscience`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_fieldofscience___person`
--

LOCK TABLES `Jobs_fieldofscience___person` WRITE;
/*!40000 ALTER TABLE `Jobs_fieldofscience___person` DISABLE KEYS */;
INSERT INTO `Jobs_fieldofscience___person` VALUES (10,26),(10,86),(10,109),(44,67),(45,11),(45,92),(47,95),(47,106),(49,14),(53,91),(55,113),(57,82),(57,119),(59,68),(60,98),(61,76),(61,81),(65,120),(68,100),(69,78),(69,89),(70,85),(71,87),(72,72),(74,79),(81,118),(84,108),(88,74),(90,75),(91,69),(91,70),(91,96),(93,16),(93,83),(93,90),(93,99),(94,80),(97,73),(98,84),(99,116),(112,66),(114,77),(114,94),(114,107),(114,114),(115,88),(115,93),(115,102),(115,104),(115,110),(115,117),(119,115),(122,2),(122,65),(123,97),(123,103),(123,105),(123,111),(124,101),(124,112),(126,39),(127,22),(137,24),(137,71),(138,30),(139,64);
/*!40000 ALTER TABLE `Jobs_fieldofscience___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_fieldofscience___pi`
--

DROP TABLE IF EXISTS `Jobs_fieldofscience___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_fieldofscience___pi` (
  `fieldofscience` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`fieldofscience`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_fieldofscience___pi`
--

LOCK TABLES `Jobs_fieldofscience___pi` WRITE;
/*!40000 ALTER TABLE `Jobs_fieldofscience___pi` DISABLE KEYS */;
INSERT INTO `Jobs_fieldofscience___pi` VALUES (10,26),(44,33),(45,11),(47,17),(49,14),(53,27),(55,34),(57,40),(59,15),(60,12),(61,10),(65,41),(68,29),(69,20),(69,35),(70,28),(71,36),(72,5),(74,13),(81,37),(84,4),(88,23),(90,31),(91,38),(93,16),(94,25),(97,32),(98,7),(99,1),(112,19),(114,21),(115,9),(119,6),(122,2),(123,8),(124,3),(126,39),(127,22),(137,24),(138,30),(139,18);
/*!40000 ALTER TABLE `Jobs_fieldofscience___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_fieldofscience___provider`
--

DROP TABLE IF EXISTS `Jobs_fieldofscience___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_fieldofscience___provider` (
  `fieldofscience` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`fieldofscience`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_fieldofscience___provider`
--

LOCK TABLES `Jobs_fieldofscience___provider` WRITE;
/*!40000 ALTER TABLE `Jobs_fieldofscience___provider` DISABLE KEYS */;
INSERT INTO `Jobs_fieldofscience___provider` VALUES (10,1),(44,1),(45,1),(47,1),(49,1),(53,1),(55,1),(57,1),(59,1),(60,1),(61,1),(65,1),(68,1),(69,1),(70,1),(71,1),(72,1),(74,1),(81,1),(84,1),(88,1),(90,1),(91,1),(93,1),(94,1),(97,1),(98,1),(99,1),(112,1),(114,1),(115,1),(119,1),(122,1),(123,1),(124,1),(126,1),(127,1),(137,1),(138,1),(139,1);
/*!40000 ALTER TABLE `Jobs_fieldofscience___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_gpucount`
--

DROP TABLE IF EXISTS `Jobs_gpucount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_gpucount` (
  `gpucount` int(11) NOT NULL,
  PRIMARY KEY (`gpucount`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_gpucount`
--

LOCK TABLES `Jobs_gpucount` WRITE;
/*!40000 ALTER TABLE `Jobs_gpucount` DISABLE KEYS */;
INSERT INTO `Jobs_gpucount` VALUES (1),(3);
/*!40000 ALTER TABLE `Jobs_gpucount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_gpucount___person`
--

DROP TABLE IF EXISTS `Jobs_gpucount___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_gpucount___person` (
  `gpucount` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`gpucount`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_gpucount___person`
--

LOCK TABLES `Jobs_gpucount___person` WRITE;
/*!40000 ALTER TABLE `Jobs_gpucount___person` DISABLE KEYS */;
INSERT INTO `Jobs_gpucount___person` VALUES (1,2),(1,11),(1,14),(1,16),(1,22),(1,24),(1,26),(1,30),(1,39),(1,64),(1,65),(1,66),(1,67),(1,68),(1,69),(1,70),(1,71),(1,72),(1,73),(1,74),(1,75),(1,76),(1,77),(1,78),(1,79),(1,80),(1,81),(1,82),(1,83),(1,84),(1,85),(1,86),(1,87),(1,88),(1,89),(1,90),(1,91),(1,92),(1,93),(1,94),(1,95),(1,96),(1,97),(1,98),(1,99),(1,100),(1,101),(1,102),(1,103),(1,104),(1,105),(1,106),(1,107),(1,108),(1,109),(1,110),(1,111),(1,112),(1,113),(1,114),(1,115),(1,116),(1,117),(1,118),(1,119),(1,120),(3,92);
/*!40000 ALTER TABLE `Jobs_gpucount___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_gpucount___pi`
--

DROP TABLE IF EXISTS `Jobs_gpucount___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_gpucount___pi` (
  `gpucount` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`gpucount`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_gpucount___pi`
--

LOCK TABLES `Jobs_gpucount___pi` WRITE;
/*!40000 ALTER TABLE `Jobs_gpucount___pi` DISABLE KEYS */;
INSERT INTO `Jobs_gpucount___pi` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19),(1,20),(1,21),(1,22),(1,23),(1,24),(1,25),(1,26),(1,27),(1,28),(1,29),(1,30),(1,31),(1,32),(1,33),(1,34),(1,35),(1,36),(1,37),(1,38),(1,39),(1,40),(1,41),(3,11);
/*!40000 ALTER TABLE `Jobs_gpucount___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_gpucount___provider`
--

DROP TABLE IF EXISTS `Jobs_gpucount___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_gpucount___provider` (
  `gpucount` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`gpucount`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_gpucount___provider`
--

LOCK TABLES `Jobs_gpucount___provider` WRITE;
/*!40000 ALTER TABLE `Jobs_gpucount___provider` DISABLE KEYS */;
INSERT INTO `Jobs_gpucount___provider` VALUES (1,1),(3,1);
/*!40000 ALTER TABLE `Jobs_gpucount___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobsize`
--

DROP TABLE IF EXISTS `Jobs_jobsize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobsize` (
  `jobsize` int(4) NOT NULL,
  PRIMARY KEY (`jobsize`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobsize`
--

LOCK TABLES `Jobs_jobsize` WRITE;
/*!40000 ALTER TABLE `Jobs_jobsize` DISABLE KEYS */;
INSERT INTO `Jobs_jobsize` VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
/*!40000 ALTER TABLE `Jobs_jobsize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobsize___person`
--

DROP TABLE IF EXISTS `Jobs_jobsize___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobsize___person` (
  `jobsize` int(4) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`jobsize`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobsize___person`
--

LOCK TABLES `Jobs_jobsize___person` WRITE;
/*!40000 ALTER TABLE `Jobs_jobsize___person` DISABLE KEYS */;
INSERT INTO `Jobs_jobsize___person` VALUES (1,22),(1,26),(1,30),(1,66),(1,67),(1,69),(1,70),(1,78),(1,81),(1,82),(1,83),(1,84),(1,85),(1,89),(1,92),(1,95),(1,96),(1,99),(1,102),(1,104),(1,106),(1,108),(1,113),(2,80),(3,86),(3,110),(3,119),(4,14),(4,16),(4,24),(4,71),(4,78),(4,82),(4,87),(4,92),(4,97),(4,100),(4,106),(4,111),(4,117),(5,14),(5,24),(5,67),(5,68),(5,78),(5,80),(5,82),(5,87),(5,88),(5,91),(5,92),(5,93),(5,97),(5,98),(5,101),(5,103),(5,105),(5,109),(5,111),(5,113),(5,115),(5,116),(5,117),(5,118),(6,14),(6,65),(6,72),(6,79),(6,83),(6,92),(6,97),(6,101),(6,103),(6,105),(6,106),(6,113),(6,116),(7,11),(7,14),(7,65),(7,74),(7,76),(7,77),(7,94),(7,100),(7,103),(7,107),(7,110),(7,113),(7,114),(7,118),(8,2),(8,14),(8,39),(8,64),(8,73),(8,75),(8,90),(8,103),(8,107),(8,112),(8,114),(9,2),(9,14),(9,112),(9,120),(10,74);
/*!40000 ALTER TABLE `Jobs_jobsize___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobsize___pi`
--

DROP TABLE IF EXISTS `Jobs_jobsize___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobsize___pi` (
  `jobsize` int(4) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`jobsize`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobsize___pi`
--

LOCK TABLES `Jobs_jobsize___pi` WRITE;
/*!40000 ALTER TABLE `Jobs_jobsize___pi` DISABLE KEYS */;
INSERT INTO `Jobs_jobsize___pi` VALUES (1,4),(1,7),(1,9),(1,10),(1,11),(1,16),(1,17),(1,19),(1,20),(1,22),(1,26),(1,28),(1,30),(1,33),(1,34),(1,35),(1,38),(1,40),(2,25),(3,9),(3,26),(3,40),(4,8),(4,9),(4,11),(4,14),(4,16),(4,17),(4,24),(4,29),(4,35),(4,36),(4,40),(5,1),(5,3),(5,6),(5,8),(5,9),(5,11),(5,12),(5,14),(5,15),(5,24),(5,25),(5,26),(5,27),(5,33),(5,34),(5,35),(5,36),(5,37),(5,40),(6,1),(6,2),(6,3),(6,5),(6,8),(6,11),(6,13),(6,14),(6,16),(6,17),(6,34),(7,2),(7,8),(7,9),(7,10),(7,11),(7,14),(7,21),(7,23),(7,29),(7,34),(7,37),(8,2),(8,3),(8,8),(8,14),(8,16),(8,18),(8,21),(8,31),(8,32),(8,39),(9,2),(9,3),(9,14),(9,41),(10,23);
/*!40000 ALTER TABLE `Jobs_jobsize___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobsize___provider`
--

DROP TABLE IF EXISTS `Jobs_jobsize___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobsize___provider` (
  `jobsize` int(4) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`jobsize`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobsize___provider`
--

LOCK TABLES `Jobs_jobsize___provider` WRITE;
/*!40000 ALTER TABLE `Jobs_jobsize___provider` DISABLE KEYS */;
INSERT INTO `Jobs_jobsize___provider` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1);
/*!40000 ALTER TABLE `Jobs_jobsize___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobwaittime`
--

DROP TABLE IF EXISTS `Jobs_jobwaittime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobwaittime` (
  `jobwaittime` int(4) NOT NULL,
  PRIMARY KEY (`jobwaittime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobwaittime`
--

LOCK TABLES `Jobs_jobwaittime` WRITE;
/*!40000 ALTER TABLE `Jobs_jobwaittime` DISABLE KEYS */;
INSERT INTO `Jobs_jobwaittime` VALUES (0),(1),(2),(3),(4),(5),(6),(7);
/*!40000 ALTER TABLE `Jobs_jobwaittime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobwaittime___person`
--

DROP TABLE IF EXISTS `Jobs_jobwaittime___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobwaittime___person` (
  `jobwaittime` int(4) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`jobwaittime`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobwaittime___person`
--

LOCK TABLES `Jobs_jobwaittime___person` WRITE;
/*!40000 ALTER TABLE `Jobs_jobwaittime___person` DISABLE KEYS */;
INSERT INTO `Jobs_jobwaittime___person` VALUES (0,2),(0,11),(0,14),(0,16),(0,22),(0,26),(0,30),(0,65),(0,69),(0,70),(0,75),(0,82),(0,83),(0,84),(0,86),(0,87),(0,88),(0,89),(0,92),(0,95),(0,96),(0,97),(0,98),(0,100),(0,101),(0,103),(0,104),(0,108),(0,111),(0,113),(0,119),(1,2),(1,14),(1,16),(1,22),(1,30),(1,65),(1,66),(1,68),(1,69),(1,70),(1,71),(1,72),(1,75),(1,78),(1,79),(1,80),(1,81),(1,82),(1,83),(1,84),(1,85),(1,86),(1,87),(1,88),(1,92),(1,93),(1,95),(1,96),(1,97),(1,99),(1,100),(1,101),(1,103),(1,104),(1,105),(1,106),(1,108),(1,109),(1,111),(1,112),(1,113),(1,114),(1,117),(1,118),(1,119),(2,14),(2,22),(2,24),(2,30),(2,39),(2,64),(2,66),(2,68),(2,71),(2,73),(2,77),(2,78),(2,81),(2,82),(2,83),(2,84),(2,85),(2,87),(2,88),(2,91),(2,92),(2,95),(2,97),(2,100),(2,103),(2,104),(2,105),(2,108),(2,109),(2,111),(2,113),(2,114),(2,116),(2,117),(3,14),(3,24),(3,67),(3,68),(3,76),(3,81),(3,82),(3,84),(3,85),(3,88),(3,91),(3,103),(3,108),(3,109),(4,14),(4,22),(4,24),(4,30),(4,39),(4,67),(4,68),(4,73),(4,74),(4,76),(4,78),(4,81),(4,82),(4,84),(4,85),(4,91),(4,103),(4,105),(4,109),(4,113),(4,114),(4,115),(4,116),(4,117),(5,14),(5,30),(5,39),(5,67),(5,68),(5,73),(5,74),(5,78),(5,82),(5,85),(5,90),(5,91),(5,97),(5,101),(5,102),(5,103),(5,106),(5,109),(5,111),(5,113),(5,116),(5,117),(6,14),(6,68),(6,82),(6,94),(6,97),(6,101),(6,105),(6,109),(6,114),(6,119),(7,14),(7,67),(7,68),(7,80),(7,82),(7,90),(7,93),(7,97),(7,101),(7,102),(7,106),(7,107),(7,110),(7,112),(7,118),(7,119),(7,120);
/*!40000 ALTER TABLE `Jobs_jobwaittime___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobwaittime___pi`
--

DROP TABLE IF EXISTS `Jobs_jobwaittime___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobwaittime___pi` (
  `jobwaittime` int(4) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`jobwaittime`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobwaittime___pi`
--

LOCK TABLES `Jobs_jobwaittime___pi` WRITE;
/*!40000 ALTER TABLE `Jobs_jobwaittime___pi` DISABLE KEYS */;
INSERT INTO `Jobs_jobwaittime___pi` VALUES (0,2),(0,3),(0,4),(0,7),(0,8),(0,9),(0,11),(0,12),(0,14),(0,16),(0,17),(0,20),(0,22),(0,26),(0,29),(0,30),(0,31),(0,34),(0,36),(0,38),(0,40),(1,2),(1,3),(1,4),(1,5),(1,7),(1,8),(1,9),(1,10),(1,11),(1,13),(1,14),(1,15),(1,16),(1,17),(1,19),(1,21),(1,22),(1,24),(1,25),(1,26),(1,28),(1,29),(1,30),(1,31),(1,34),(1,35),(1,36),(1,37),(1,38),(1,40),(2,1),(2,4),(2,7),(2,8),(2,9),(2,10),(2,11),(2,14),(2,15),(2,16),(2,17),(2,18),(2,19),(2,21),(2,22),(2,24),(2,26),(2,27),(2,28),(2,29),(2,30),(2,32),(2,34),(2,35),(2,36),(2,39),(2,40),(3,4),(3,7),(3,8),(3,9),(3,10),(3,14),(3,15),(3,24),(3,26),(3,27),(3,28),(3,33),(3,40),(4,1),(4,6),(4,7),(4,8),(4,9),(4,10),(4,14),(4,15),(4,21),(4,22),(4,23),(4,24),(4,26),(4,27),(4,28),(4,30),(4,32),(4,33),(4,34),(4,35),(4,39),(4,40),(5,1),(5,3),(5,8),(5,9),(5,14),(5,15),(5,16),(5,17),(5,23),(5,26),(5,27),(5,28),(5,30),(5,32),(5,33),(5,34),(5,35),(5,39),(5,40),(6,3),(6,8),(6,14),(6,15),(6,21),(6,26),(6,40),(7,3),(7,8),(7,9),(7,14),(7,15),(7,16),(7,17),(7,21),(7,25),(7,33),(7,37),(7,40),(7,41);
/*!40000 ALTER TABLE `Jobs_jobwaittime___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobwaittime___provider`
--

DROP TABLE IF EXISTS `Jobs_jobwaittime___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobwaittime___provider` (
  `jobwaittime` int(4) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`jobwaittime`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobwaittime___provider`
--

LOCK TABLES `Jobs_jobwaittime___provider` WRITE;
/*!40000 ALTER TABLE `Jobs_jobwaittime___provider` DISABLE KEYS */;
INSERT INTO `Jobs_jobwaittime___provider` VALUES (0,1),(1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1);
/*!40000 ALTER TABLE `Jobs_jobwaittime___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobwalltime`
--

DROP TABLE IF EXISTS `Jobs_jobwalltime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobwalltime` (
  `jobwalltime` int(4) NOT NULL,
  PRIMARY KEY (`jobwalltime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobwalltime`
--

LOCK TABLES `Jobs_jobwalltime` WRITE;
/*!40000 ALTER TABLE `Jobs_jobwalltime` DISABLE KEYS */;
INSERT INTO `Jobs_jobwalltime` VALUES (0),(1),(2),(3),(4),(5),(6),(7);
/*!40000 ALTER TABLE `Jobs_jobwalltime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobwalltime___person`
--

DROP TABLE IF EXISTS `Jobs_jobwalltime___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobwalltime___person` (
  `jobwalltime` int(4) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`jobwalltime`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobwalltime___person`
--

LOCK TABLES `Jobs_jobwalltime___person` WRITE;
/*!40000 ALTER TABLE `Jobs_jobwalltime___person` DISABLE KEYS */;
INSERT INTO `Jobs_jobwalltime___person` VALUES (0,82),(1,14),(1,22),(1,30),(1,68),(1,72),(1,78),(1,81),(1,82),(1,83),(1,84),(1,87),(1,92),(1,97),(1,100),(1,103),(1,104),(1,108),(1,111),(1,113),(1,118),(2,14),(2,22),(2,30),(2,64),(2,65),(2,68),(2,71),(2,72),(2,73),(2,74),(2,76),(2,81),(2,82),(2,83),(2,84),(2,87),(2,88),(2,91),(2,92),(2,97),(2,98),(2,101),(2,103),(2,104),(2,105),(2,106),(2,108),(2,109),(2,110),(2,111),(2,113),(2,120),(3,14),(3,30),(3,65),(3,68),(3,69),(3,70),(3,82),(3,83),(3,84),(3,87),(3,88),(3,92),(3,96),(3,97),(3,101),(3,103),(3,108),(3,110),(3,111),(3,113),(4,14),(4,22),(4,24),(4,30),(4,65),(4,66),(4,68),(4,81),(4,82),(4,83),(4,84),(4,85),(4,87),(4,92),(4,97),(4,100),(4,101),(4,105),(4,108),(4,109),(4,110),(4,111),(4,112),(4,113),(4,114),(5,16),(5,30),(5,66),(5,67),(5,68),(5,74),(5,75),(5,80),(5,83),(5,84),(5,85),(5,90),(5,97),(5,100),(5,103),(5,105),(5,109),(5,111),(5,114),(5,119),(5,120),(6,16),(6,22),(6,30),(6,66),(6,67),(6,68),(6,71),(6,73),(6,75),(6,80),(6,84),(6,85),(6,86),(6,87),(6,94),(6,95),(6,97),(6,101),(6,102),(6,103),(6,109),(6,111),(6,113),(6,114),(6,117),(6,119),(7,2),(7,11),(7,16),(7,22),(7,24),(7,26),(7,30),(7,39),(7,67),(7,71),(7,74),(7,75),(7,76),(7,77),(7,78),(7,79),(7,80),(7,82),(7,83),(7,84),(7,86),(7,87),(7,89),(7,90),(7,91),(7,92),(7,93),(7,94),(7,97),(7,99),(7,101),(7,102),(7,103),(7,105),(7,106),(7,107),(7,109),(7,110),(7,111),(7,112),(7,115),(7,116),(7,117),(7,118),(7,119);
/*!40000 ALTER TABLE `Jobs_jobwalltime___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobwalltime___pi`
--

DROP TABLE IF EXISTS `Jobs_jobwalltime___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobwalltime___pi` (
  `jobwalltime` int(4) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`jobwalltime`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobwalltime___pi`
--

LOCK TABLES `Jobs_jobwalltime___pi` WRITE;
/*!40000 ALTER TABLE `Jobs_jobwalltime___pi` DISABLE KEYS */;
INSERT INTO `Jobs_jobwalltime___pi` VALUES (0,40),(1,4),(1,5),(1,7),(1,8),(1,9),(1,10),(1,11),(1,14),(1,15),(1,16),(1,22),(1,29),(1,30),(1,34),(1,35),(1,36),(1,37),(1,40),(2,2),(2,3),(2,4),(2,5),(2,7),(2,8),(2,9),(2,10),(2,11),(2,12),(2,14),(2,15),(2,16),(2,17),(2,18),(2,22),(2,23),(2,24),(2,26),(2,27),(2,30),(2,32),(2,34),(2,36),(2,40),(2,41),(3,2),(3,3),(3,4),(3,7),(3,8),(3,9),(3,11),(3,14),(3,15),(3,16),(3,30),(3,34),(3,36),(3,38),(3,40),(4,2),(4,3),(4,4),(4,7),(4,8),(4,9),(4,10),(4,11),(4,14),(4,15),(4,16),(4,19),(4,21),(4,22),(4,24),(4,26),(4,28),(4,29),(4,30),(4,34),(4,36),(4,40),(5,7),(5,8),(5,15),(5,16),(5,19),(5,21),(5,23),(5,25),(5,26),(5,28),(5,29),(5,30),(5,31),(5,33),(5,40),(5,41),(6,3),(6,7),(6,8),(6,9),(6,15),(6,16),(6,17),(6,19),(6,21),(6,22),(6,24),(6,25),(6,26),(6,28),(6,30),(6,31),(6,32),(6,33),(6,34),(6,36),(6,40),(7,1),(7,2),(7,3),(7,6),(7,7),(7,8),(7,9),(7,10),(7,11),(7,13),(7,16),(7,17),(7,20),(7,21),(7,22),(7,23),(7,24),(7,25),(7,26),(7,27),(7,30),(7,31),(7,33),(7,35),(7,36),(7,37),(7,39),(7,40);
/*!40000 ALTER TABLE `Jobs_jobwalltime___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_jobwalltime___provider`
--

DROP TABLE IF EXISTS `Jobs_jobwalltime___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_jobwalltime___provider` (
  `jobwalltime` int(4) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`jobwalltime`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_jobwalltime___provider`
--

LOCK TABLES `Jobs_jobwalltime___provider` WRITE;
/*!40000 ALTER TABLE `Jobs_jobwalltime___provider` DISABLE KEYS */;
INSERT INTO `Jobs_jobwalltime___provider` VALUES (0,1),(1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1);
/*!40000 ALTER TABLE `Jobs_jobwalltime___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_nodecount`
--

DROP TABLE IF EXISTS `Jobs_nodecount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_nodecount` (
  `nodecount` int(11) NOT NULL,
  PRIMARY KEY (`nodecount`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_nodecount`
--

LOCK TABLES `Jobs_nodecount` WRITE;
/*!40000 ALTER TABLE `Jobs_nodecount` DISABLE KEYS */;
INSERT INTO `Jobs_nodecount` VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(12),(14),(16),(20),(24),(28);
/*!40000 ALTER TABLE `Jobs_nodecount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_nodecount___person`
--

DROP TABLE IF EXISTS `Jobs_nodecount___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_nodecount___person` (
  `nodecount` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`nodecount`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_nodecount___person`
--

LOCK TABLES `Jobs_nodecount___person` WRITE;
/*!40000 ALTER TABLE `Jobs_nodecount___person` DISABLE KEYS */;
INSERT INTO `Jobs_nodecount___person` VALUES (1,14),(1,16),(1,22),(1,24),(1,26),(1,30),(1,66),(1,67),(1,68),(1,69),(1,70),(1,71),(1,72),(1,78),(1,79),(1,80),(1,81),(1,82),(1,83),(1,84),(1,85),(1,86),(1,87),(1,88),(1,89),(1,91),(1,92),(1,93),(1,95),(1,96),(1,97),(1,98),(1,99),(1,100),(1,101),(1,102),(1,103),(1,104),(1,105),(1,106),(1,108),(1,109),(1,110),(1,111),(1,113),(1,115),(1,117),(1,118),(1,119),(2,14),(2,101),(2,103),(2,106),(2,113),(2,116),(2,118),(3,114),(4,14),(4,65),(4,74),(4,92),(4,103),(4,110),(4,112),(4,113),(5,77),(5,94),(5,100),(6,39),(6,103),(6,107),(6,114),(7,2),(7,75),(8,11),(8,14),(8,65),(8,73),(8,90),(9,64),(12,2),(12,103),(12,112),(14,76),(16,14),(20,120),(24,74),(28,74);
/*!40000 ALTER TABLE `Jobs_nodecount___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_nodecount___pi`
--

DROP TABLE IF EXISTS `Jobs_nodecount___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_nodecount___pi` (
  `nodecount` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`nodecount`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_nodecount___pi`
--

LOCK TABLES `Jobs_nodecount___pi` WRITE;
/*!40000 ALTER TABLE `Jobs_nodecount___pi` DISABLE KEYS */;
INSERT INTO `Jobs_nodecount___pi` VALUES (1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,19),(1,20),(1,22),(1,24),(1,25),(1,26),(1,27),(1,28),(1,29),(1,30),(1,33),(1,34),(1,35),(1,36),(1,37),(1,38),(1,40),(2,1),(2,3),(2,8),(2,14),(2,17),(2,34),(2,37),(3,21),(4,2),(4,3),(4,8),(4,9),(4,11),(4,14),(4,23),(4,34),(5,21),(5,29),(6,8),(6,21),(6,39),(7,2),(7,31),(8,2),(8,11),(8,14),(8,16),(8,32),(9,18),(12,2),(12,3),(12,8),(14,10),(16,14),(20,41),(24,23),(28,23);
/*!40000 ALTER TABLE `Jobs_nodecount___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_nodecount___provider`
--

DROP TABLE IF EXISTS `Jobs_nodecount___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_nodecount___provider` (
  `nodecount` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`nodecount`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_nodecount___provider`
--

LOCK TABLES `Jobs_nodecount___provider` WRITE;
/*!40000 ALTER TABLE `Jobs_nodecount___provider` DISABLE KEYS */;
INSERT INTO `Jobs_nodecount___provider` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(12,1),(14,1),(16,1),(20,1),(24,1),(28,1);
/*!40000 ALTER TABLE `Jobs_nodecount___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_nsfdirectorate`
--

DROP TABLE IF EXISTS `Jobs_nsfdirectorate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_nsfdirectorate` (
  `nsfdirectorate` int(11) NOT NULL,
  PRIMARY KEY (`nsfdirectorate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_nsfdirectorate`
--

LOCK TABLES `Jobs_nsfdirectorate` WRITE;
/*!40000 ALTER TABLE `Jobs_nsfdirectorate` DISABLE KEYS */;
INSERT INTO `Jobs_nsfdirectorate` VALUES (2),(3),(4),(5),(6),(7),(9);
/*!40000 ALTER TABLE `Jobs_nsfdirectorate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_nsfdirectorate___person`
--

DROP TABLE IF EXISTS `Jobs_nsfdirectorate___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_nsfdirectorate___person` (
  `nsfdirectorate` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`nsfdirectorate`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_nsfdirectorate___person`
--

LOCK TABLES `Jobs_nsfdirectorate___person` WRITE;
/*!40000 ALTER TABLE `Jobs_nsfdirectorate___person` DISABLE KEYS */;
INSERT INTO `Jobs_nsfdirectorate___person` VALUES (2,2),(2,39),(2,65),(2,66),(2,77),(2,78),(2,88),(2,89),(2,91),(2,93),(2,94),(2,97),(2,101),(2,102),(2,103),(2,104),(2,105),(2,107),(2,110),(2,111),(2,112),(2,114),(2,115),(2,117),(3,11),(3,14),(3,67),(3,92),(3,95),(3,106),(4,22),(4,24),(4,30),(4,64),(4,71),(5,16),(5,69),(5,70),(5,73),(5,74),(5,75),(5,80),(5,83),(5,84),(5,90),(5,96),(5,99),(5,116),(6,68),(6,72),(6,79),(6,85),(6,87),(6,100),(6,108),(6,118),(6,120),(7,26),(7,86),(7,109),(9,76),(9,81),(9,82),(9,98),(9,113),(9,119);
/*!40000 ALTER TABLE `Jobs_nsfdirectorate___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_nsfdirectorate___pi`
--

DROP TABLE IF EXISTS `Jobs_nsfdirectorate___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_nsfdirectorate___pi` (
  `nsfdirectorate` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`nsfdirectorate`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_nsfdirectorate___pi`
--

LOCK TABLES `Jobs_nsfdirectorate___pi` WRITE;
/*!40000 ALTER TABLE `Jobs_nsfdirectorate___pi` DISABLE KEYS */;
INSERT INTO `Jobs_nsfdirectorate___pi` VALUES (2,2),(2,3),(2,6),(2,8),(2,9),(2,19),(2,20),(2,21),(2,27),(2,35),(2,39),(3,11),(3,14),(3,17),(3,33),(4,18),(4,22),(4,24),(4,30),(5,1),(5,7),(5,16),(5,23),(5,25),(5,31),(5,32),(5,38),(6,4),(6,5),(6,13),(6,15),(6,28),(6,29),(6,36),(6,37),(6,41),(7,26),(9,10),(9,12),(9,34),(9,40);
/*!40000 ALTER TABLE `Jobs_nsfdirectorate___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_nsfdirectorate___provider`
--

DROP TABLE IF EXISTS `Jobs_nsfdirectorate___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_nsfdirectorate___provider` (
  `nsfdirectorate` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`nsfdirectorate`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_nsfdirectorate___provider`
--

LOCK TABLES `Jobs_nsfdirectorate___provider` WRITE;
/*!40000 ALTER TABLE `Jobs_nsfdirectorate___provider` DISABLE KEYS */;
INSERT INTO `Jobs_nsfdirectorate___provider` VALUES (2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(9,1);
/*!40000 ALTER TABLE `Jobs_nsfdirectorate___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_parentscience`
--

DROP TABLE IF EXISTS `Jobs_parentscience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_parentscience` (
  `parentscience` int(11) NOT NULL,
  PRIMARY KEY (`parentscience`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_parentscience`
--

LOCK TABLES `Jobs_parentscience` WRITE;
/*!40000 ALTER TABLE `Jobs_parentscience` DISABLE KEYS */;
INSERT INTO `Jobs_parentscience` VALUES (10),(12),(13),(17),(19),(20),(21),(22),(23),(24),(25),(26),(28),(34),(35),(36),(39),(40);
/*!40000 ALTER TABLE `Jobs_parentscience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_parentscience___person`
--

DROP TABLE IF EXISTS `Jobs_parentscience___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_parentscience___person` (
  `parentscience` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`parentscience`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_parentscience___person`
--

LOCK TABLES `Jobs_parentscience___person` WRITE;
/*!40000 ALTER TABLE `Jobs_parentscience___person` DISABLE KEYS */;
INSERT INTO `Jobs_parentscience___person` VALUES (10,26),(10,86),(10,109),(12,66),(12,77),(12,88),(12,93),(12,94),(12,102),(12,104),(12,107),(12,110),(12,114),(12,117),(13,120),(17,22),(19,2),(19,65),(19,97),(19,103),(19,105),(19,111),(20,74),(21,84),(21,116),(22,14),(23,39),(23,101),(23,112),(24,78),(24,89),(24,91),(25,68),(25,108),(25,118),(26,72),(26,79),(26,85),(26,87),(26,100),(28,16),(28,73),(28,80),(28,83),(28,90),(28,99),(34,11),(34,67),(34,92),(34,95),(34,106),(35,24),(35,30),(35,64),(35,71),(36,69),(36,70),(36,75),(36,96),(39,115),(40,76),(40,81),(40,82),(40,98),(40,113),(40,119);
/*!40000 ALTER TABLE `Jobs_parentscience___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_parentscience___pi`
--

DROP TABLE IF EXISTS `Jobs_parentscience___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_parentscience___pi` (
  `parentscience` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`parentscience`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_parentscience___pi`
--

LOCK TABLES `Jobs_parentscience___pi` WRITE;
/*!40000 ALTER TABLE `Jobs_parentscience___pi` DISABLE KEYS */;
INSERT INTO `Jobs_parentscience___pi` VALUES (10,26),(12,9),(12,19),(12,21),(13,41),(17,22),(19,2),(19,8),(20,23),(21,1),(21,7),(22,14),(23,3),(23,39),(24,20),(24,27),(24,35),(25,4),(25,15),(25,37),(26,5),(26,13),(26,28),(26,29),(26,36),(28,16),(28,25),(28,32),(34,11),(34,17),(34,33),(35,18),(35,24),(35,30),(36,31),(36,38),(39,6),(40,10),(40,12),(40,34),(40,40);
/*!40000 ALTER TABLE `Jobs_parentscience___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_parentscience___provider`
--

DROP TABLE IF EXISTS `Jobs_parentscience___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_parentscience___provider` (
  `parentscience` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`parentscience`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_parentscience___provider`
--

LOCK TABLES `Jobs_parentscience___provider` WRITE;
/*!40000 ALTER TABLE `Jobs_parentscience___provider` DISABLE KEYS */;
INSERT INTO `Jobs_parentscience___provider` VALUES (10,1),(12,1),(13,1),(17,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(28,1),(34,1),(35,1),(36,1),(39,1),(40,1);
/*!40000 ALTER TABLE `Jobs_parentscience___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_person`
--

DROP TABLE IF EXISTS `Jobs_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_person` (
  `person` int(11) NOT NULL,
  PRIMARY KEY (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_person`
--

LOCK TABLES `Jobs_person` WRITE;
/*!40000 ALTER TABLE `Jobs_person` DISABLE KEYS */;
INSERT INTO `Jobs_person` VALUES (2),(11),(14),(16),(22),(24),(26),(30),(39),(64),(65),(66),(67),(68),(69),(70),(71),(72),(73),(74),(75),(76),(77),(78),(79),(80),(81),(82),(83),(84),(85),(86),(87),(88),(89),(90),(91),(92),(93),(94),(95),(96),(97),(98),(99),(100),(101),(102),(103),(104),(105),(106),(107),(108),(109),(110),(111),(112),(113),(114),(115),(116),(117),(118),(119),(120);
/*!40000 ALTER TABLE `Jobs_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_person___pi`
--

DROP TABLE IF EXISTS `Jobs_person___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_person___pi` (
  `person` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`person`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_person___pi`
--

LOCK TABLES `Jobs_person___pi` WRITE;
/*!40000 ALTER TABLE `Jobs_person___pi` DISABLE KEYS */;
INSERT INTO `Jobs_person___pi` VALUES (2,2),(11,11),(14,14),(16,16),(22,22),(24,24),(26,26),(30,30),(39,39),(64,18),(65,2),(66,19),(67,33),(68,15),(69,38),(70,38),(71,24),(72,5),(73,32),(74,23),(75,31),(76,10),(77,21),(78,35),(79,13),(80,25),(81,10),(82,40),(83,16),(84,7),(85,28),(86,26),(87,36),(88,9),(89,20),(90,16),(91,27),(92,11),(93,9),(94,21),(95,17),(96,38),(97,8),(98,12),(99,16),(100,29),(101,3),(102,9),(103,8),(104,9),(105,8),(106,17),(107,21),(108,4),(109,26),(110,9),(111,8),(112,3),(113,34),(114,21),(115,6),(116,1),(117,9),(118,37),(119,40),(120,41);
/*!40000 ALTER TABLE `Jobs_person___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_person___provider`
--

DROP TABLE IF EXISTS `Jobs_person___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_person___provider` (
  `person` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`person`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_person___provider`
--

LOCK TABLES `Jobs_person___provider` WRITE;
/*!40000 ALTER TABLE `Jobs_person___provider` DISABLE KEYS */;
INSERT INTO `Jobs_person___provider` VALUES (2,1),(11,1),(14,1),(16,1),(22,1),(24,1),(26,1),(30,1),(39,1),(64,1),(65,1),(66,1),(67,1),(68,1),(69,1),(70,1),(71,1),(72,1),(73,1),(74,1),(75,1),(76,1),(77,1),(78,1),(79,1),(80,1),(81,1),(82,1),(83,1),(84,1),(85,1),(86,1),(87,1),(88,1),(89,1),(90,1),(91,1),(92,1),(93,1),(94,1),(95,1),(96,1),(97,1),(98,1),(99,1),(100,1),(101,1),(102,1),(103,1),(104,1),(105,1),(106,1),(107,1),(108,1),(109,1),(110,1),(111,1),(112,1),(113,1),(114,1),(115,1),(116,1),(117,1),(118,1),(119,1),(120,1);
/*!40000 ALTER TABLE `Jobs_person___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_person___qos`
--

DROP TABLE IF EXISTS `Jobs_person___qos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_person___qos` (
  `person` int(11) NOT NULL,
  `qos` int(11) NOT NULL,
  PRIMARY KEY (`person`,`qos`),
  KEY `idx_second_dimension` (`qos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_person___qos`
--

LOCK TABLES `Jobs_person___qos` WRITE;
/*!40000 ALTER TABLE `Jobs_person___qos` DISABLE KEYS */;
INSERT INTO `Jobs_person___qos` VALUES (2,2),(11,14),(14,15),(16,2),(16,8),(22,15),(24,15),(26,12),(30,15),(39,15),(64,15),(65,14),(66,15),(67,16),(68,7),(68,15),(69,9),(70,9),(71,15),(72,11),(73,15),(74,15),(75,9),(76,15),(77,16),(78,10),(79,11),(80,6),(80,15),(81,15),(82,1),(82,2),(82,3),(82,4),(82,6),(82,7),(82,15),(83,2),(83,8),(83,15),(84,15),(85,15),(86,12),(87,15),(87,18),(87,19),(88,2),(88,3),(88,19),(89,17),(90,15),(91,15),(92,13),(92,14),(93,2),(93,3),(94,16),(95,16),(96,9),(97,1),(97,2),(97,7),(97,17),(97,19),(98,19),(99,15),(100,16),(100,18),(101,2),(101,16),(102,3),(103,1),(103,2),(103,16),(103,19),(104,2),(104,3),(105,1),(105,2),(105,5),(105,16),(106,15),(106,19),(107,16),(108,15),(108,19),(109,15),(110,3),(110,15),(111,1),(111,2),(112,8),(112,16),(113,15),(113,19),(114,16),(115,15),(116,15),(117,2),(117,3),(118,2),(118,15),(119,2),(119,4),(120,15);
/*!40000 ALTER TABLE `Jobs_person___qos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_person___queue`
--

DROP TABLE IF EXISTS `Jobs_person___queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_person___queue` (
  `person` int(11) NOT NULL,
  `queue` char(255) NOT NULL,
  PRIMARY KEY (`person`,`queue`),
  KEY `idx_second_dimension` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_person___queue`
--

LOCK TABLES `Jobs_person___queue` WRITE;
/*!40000 ALTER TABLE `Jobs_person___queue` DISABLE KEYS */;
INSERT INTO `Jobs_person___queue` VALUES (2,'black'),(11,'crumpet'),(14,'white'),(16,'bannock'),(22,'white'),(24,'white'),(26,'pita'),(30,'white'),(39,'white'),(64,'white'),(65,'crumpet'),(66,'white'),(67,'white'),(68,'nann'),(68,'white'),(69,'brown'),(70,'brown'),(71,'white'),(72,'panettone'),(73,'white'),(74,'white'),(75,'brown'),(76,'white'),(77,'white'),(78,'pikelet'),(79,'panettone'),(80,'barm'),(80,'white'),(81,'white'),(82,'black'),(82,'brioche'),(82,'white'),(83,'bannock'),(83,'white'),(84,'white'),(85,'white'),(86,'pita'),(87,'potbrood'),(87,'pumpernickel'),(87,'white'),(88,'cornbread'),(88,'potbrood'),(89,'roti'),(90,'white'),(91,'white'),(92,'crumpet'),(92,'focaccia'),(93,'cornbread'),(94,'white'),(95,'white'),(96,'brown'),(97,'black'),(97,'croutons'),(97,'potbrood'),(97,'roti'),(98,'potbrood'),(99,'white'),(100,'pumpernickel'),(100,'white'),(101,'black'),(101,'white'),(102,'cornbread'),(103,'croutons'),(103,'potbrood'),(103,'roti'),(103,'white'),(104,'cornbread'),(105,'chapti'),(105,'croutons'),(105,'roti'),(106,'potbrood'),(106,'white'),(107,'white'),(108,'potbrood'),(108,'white'),(109,'white'),(110,'cornbread'),(110,'white'),(111,'croutons'),(112,'bannock'),(112,'white'),(113,'potbrood'),(113,'white'),(114,'white'),(115,'white'),(116,'white'),(117,'black'),(117,'cornbread'),(118,'black'),(118,'white'),(119,'brioche'),(120,'white');
/*!40000 ALTER TABLE `Jobs_person___queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_person___resource`
--

DROP TABLE IF EXISTS `Jobs_person___resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_person___resource` (
  `person` int(11) NOT NULL,
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`person`,`resource`),
  KEY `idx_second_dimension` (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_person___resource`
--

LOCK TABLES `Jobs_person___resource` WRITE;
/*!40000 ALTER TABLE `Jobs_person___resource` DISABLE KEYS */;
INSERT INTO `Jobs_person___resource` VALUES (2,1),(11,3),(14,5),(16,4),(22,5),(24,5),(26,2),(30,5),(39,5),(64,5),(65,3),(66,5),(67,5),(68,2),(68,5),(69,1),(70,1),(71,5),(72,2),(73,5),(74,5),(75,1),(76,5),(77,5),(78,2),(79,2),(80,4),(80,5),(81,5),(82,1),(82,2),(82,3),(82,4),(82,5),(83,4),(83,5),(84,5),(85,5),(86,2),(87,5),(88,4),(88,5),(89,5),(90,5),(91,5),(92,3),(93,4),(94,5),(95,5),(96,1),(97,1),(97,4),(97,5),(98,5),(99,5),(100,5),(101,1),(101,4),(101,5),(102,4),(103,4),(103,5),(104,4),(105,4),(105,5),(106,5),(107,5),(108,5),(109,5),(110,4),(110,5),(111,4),(112,4),(112,5),(113,5),(114,5),(115,5),(116,5),(117,1),(117,4),(118,4),(118,5),(119,4),(120,5);
/*!40000 ALTER TABLE `Jobs_person___resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_person___resource_type`
--

DROP TABLE IF EXISTS `Jobs_person___resource_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_person___resource_type` (
  `person` int(11) NOT NULL,
  `resource_type` int(11) NOT NULL,
  PRIMARY KEY (`person`,`resource_type`),
  KEY `idx_second_dimension` (`resource_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_person___resource_type`
--

LOCK TABLES `Jobs_person___resource_type` WRITE;
/*!40000 ALTER TABLE `Jobs_person___resource_type` DISABLE KEYS */;
INSERT INTO `Jobs_person___resource_type` VALUES (2,1),(11,1),(14,1),(16,1),(22,1),(24,1),(26,1),(30,1),(39,1),(64,1),(65,1),(66,1),(67,1),(68,1),(69,1),(70,1),(71,1),(72,1),(73,1),(74,1),(75,1),(76,1),(77,1),(78,1),(79,1),(80,1),(81,1),(82,1),(83,1),(84,1),(85,1),(86,1),(87,1),(88,1),(89,1),(90,1),(91,1),(92,1),(93,1),(94,1),(95,1),(96,1),(97,1),(98,1),(99,1),(100,1),(101,1),(102,1),(103,1),(104,1),(105,1),(106,1),(107,1),(108,1),(109,1),(110,1),(111,1),(112,1),(113,1),(114,1),(115,1),(116,1),(117,1),(118,1),(119,1),(120,1);
/*!40000 ALTER TABLE `Jobs_person___resource_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_person___username`
--

DROP TABLE IF EXISTS `Jobs_person___username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_person___username` (
  `person` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`person`,`username`),
  KEY `idx_second_dimension` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_person___username`
--

LOCK TABLES `Jobs_person___username` WRITE;
/*!40000 ALTER TABLE `Jobs_person___username` DISABLE KEYS */;
INSERT INTO `Jobs_person___username` VALUES (2,'aytinis'),(11,'chaff'),(14,'dunli'),(16,'field'),(22,'henha'),(24,'hoowa'),(26,'jackd'),(30,'moorh'),(39,'smew1'),(64,'allga'),(65,'alpsw'),(66,'blhbu'),(67,'boowa'),(68,'caspl'),(69,'categ'),(70,'coot1'),(71,'corsh'),(72,'crama'),(73,'crane'),(74,'duswa'),(75,'egygo'),(76,'evegr'),(77,'ferdu'),(78,'garwa'),(79,'gloib'),(80,'grath'),(81,'grgsh'),(82,'honbu'),(83,'lanhach'),(84,'lapwi'),(85,'legsh'),(86,'lesre'),(87,'litau'),(88,'litst'),(89,'mamwa'),(90,'meapi'),(91,'misth'),(92,'noror'),(93,'ovenb'),(94,'pereg'),(95,'pibgr'),(96,'proubis'),(97,'reebu'),(98,'relpa'),(99,'ribgu'),(100,'rolle'),(101,'sancr'),(102,'sante'),(103,'sarwa'),(104,'savsp'),(105,'shag1'),(106,'shttr'),(107,'siski'),(108,'sogsh'),(109,'sposa'),(110,'swath'),(111,'turdo'),(112,'velsc'),(113,'vertera'),(114,'whimb'),(115,'whtpl'),(116,'whtsp'),(117,'ybsbu'),(118,'yebbu'),(119,'yebsa'),(120,'yebwa');
/*!40000 ALTER TABLE `Jobs_person___username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_pi`
--

DROP TABLE IF EXISTS `Jobs_pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_pi` (
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_pi`
--

LOCK TABLES `Jobs_pi` WRITE;
/*!40000 ALTER TABLE `Jobs_pi` DISABLE KEYS */;
INSERT INTO `Jobs_pi` VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13),(14),(15),(16),(17),(18),(19),(20),(21),(22),(23),(24),(25),(26),(27),(28),(29),(30),(31),(32),(33),(34),(35),(36),(37),(38),(39),(40),(41);
/*!40000 ALTER TABLE `Jobs_pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_pi___provider`
--

DROP TABLE IF EXISTS `Jobs_pi___provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_pi___provider` (
  `pi` int(11) NOT NULL,
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`pi`,`provider`),
  KEY `idx_second_dimension` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_pi___provider`
--

LOCK TABLES `Jobs_pi___provider` WRITE;
/*!40000 ALTER TABLE `Jobs_pi___provider` DISABLE KEYS */;
INSERT INTO `Jobs_pi___provider` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1);
/*!40000 ALTER TABLE `Jobs_pi___provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_pi___qos`
--

DROP TABLE IF EXISTS `Jobs_pi___qos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_pi___qos` (
  `pi` int(11) NOT NULL,
  `qos` int(11) NOT NULL,
  PRIMARY KEY (`pi`,`qos`),
  KEY `idx_second_dimension` (`qos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_pi___qos`
--

LOCK TABLES `Jobs_pi___qos` WRITE;
/*!40000 ALTER TABLE `Jobs_pi___qos` DISABLE KEYS */;
INSERT INTO `Jobs_pi___qos` VALUES (1,15),(2,2),(2,14),(3,2),(3,8),(3,16),(4,15),(4,19),(5,11),(6,15),(7,15),(8,1),(8,2),(8,5),(8,7),(8,16),(8,17),(8,19),(9,2),(9,3),(9,15),(9,19),(10,15),(11,13),(11,14),(12,19),(13,11),(14,15),(15,7),(15,15),(16,2),(16,8),(16,15),(17,15),(17,16),(17,19),(18,15),(19,15),(20,17),(21,16),(22,15),(23,15),(24,15),(25,6),(25,15),(26,12),(26,15),(27,15),(28,15),(29,16),(29,18),(30,15),(31,9),(32,15),(33,16),(34,15),(34,19),(35,10),(36,15),(36,18),(36,19),(37,2),(37,15),(38,9),(39,15),(40,1),(40,2),(40,3),(40,4),(40,6),(40,7),(40,15),(41,15);
/*!40000 ALTER TABLE `Jobs_pi___qos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_pi___queue`
--

DROP TABLE IF EXISTS `Jobs_pi___queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_pi___queue` (
  `pi` int(11) NOT NULL,
  `queue` char(255) NOT NULL,
  PRIMARY KEY (`pi`,`queue`),
  KEY `idx_second_dimension` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_pi___queue`
--

LOCK TABLES `Jobs_pi___queue` WRITE;
/*!40000 ALTER TABLE `Jobs_pi___queue` DISABLE KEYS */;
INSERT INTO `Jobs_pi___queue` VALUES (1,'white'),(2,'black'),(2,'crumpet'),(3,'bannock'),(3,'black'),(3,'white'),(4,'potbrood'),(4,'white'),(5,'panettone'),(6,'white'),(7,'white'),(8,'black'),(8,'chapti'),(8,'croutons'),(8,'potbrood'),(8,'roti'),(8,'white'),(9,'black'),(9,'cornbread'),(9,'potbrood'),(9,'white'),(10,'white'),(11,'crumpet'),(11,'focaccia'),(12,'potbrood'),(13,'panettone'),(14,'white'),(15,'nann'),(15,'white'),(16,'bannock'),(16,'white'),(17,'potbrood'),(17,'white'),(18,'white'),(19,'white'),(20,'roti'),(21,'white'),(22,'white'),(23,'white'),(24,'white'),(25,'barm'),(25,'white'),(26,'pita'),(26,'white'),(27,'white'),(28,'white'),(29,'pumpernickel'),(29,'white'),(30,'white'),(31,'brown'),(32,'white'),(33,'white'),(34,'potbrood'),(34,'white'),(35,'pikelet'),(36,'potbrood'),(36,'pumpernickel'),(36,'white'),(37,'black'),(37,'white'),(38,'brown'),(39,'white'),(40,'black'),(40,'brioche'),(40,'white'),(41,'white');
/*!40000 ALTER TABLE `Jobs_pi___queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_pi___resource`
--

DROP TABLE IF EXISTS `Jobs_pi___resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_pi___resource` (
  `pi` int(11) NOT NULL,
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`pi`,`resource`),
  KEY `idx_second_dimension` (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_pi___resource`
--

LOCK TABLES `Jobs_pi___resource` WRITE;
/*!40000 ALTER TABLE `Jobs_pi___resource` DISABLE KEYS */;
INSERT INTO `Jobs_pi___resource` VALUES (1,5),(2,1),(2,3),(3,1),(3,4),(3,5),(4,5),(5,2),(6,5),(7,5),(8,1),(8,4),(8,5),(9,1),(9,4),(9,5),(10,5),(11,3),(12,5),(13,2),(14,5),(15,2),(15,5),(16,4),(16,5),(17,5),(18,5),(19,5),(20,5),(21,5),(22,5),(23,5),(24,5),(25,4),(25,5),(26,2),(26,5),(27,5),(28,5),(29,5),(30,5),(31,1),(32,5),(33,5),(34,5),(35,2),(36,5),(37,4),(37,5),(38,1),(39,5),(40,1),(40,2),(40,3),(40,4),(40,5),(41,5);
/*!40000 ALTER TABLE `Jobs_pi___resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_pi___resource_type`
--

DROP TABLE IF EXISTS `Jobs_pi___resource_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_pi___resource_type` (
  `pi` int(11) NOT NULL,
  `resource_type` int(11) NOT NULL,
  PRIMARY KEY (`pi`,`resource_type`),
  KEY `idx_second_dimension` (`resource_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_pi___resource_type`
--

LOCK TABLES `Jobs_pi___resource_type` WRITE;
/*!40000 ALTER TABLE `Jobs_pi___resource_type` DISABLE KEYS */;
INSERT INTO `Jobs_pi___resource_type` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1);
/*!40000 ALTER TABLE `Jobs_pi___resource_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_pi___username`
--

DROP TABLE IF EXISTS `Jobs_pi___username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_pi___username` (
  `pi` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`pi`,`username`),
  KEY `idx_second_dimension` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_pi___username`
--

LOCK TABLES `Jobs_pi___username` WRITE;
/*!40000 ALTER TABLE `Jobs_pi___username` DISABLE KEYS */;
INSERT INTO `Jobs_pi___username` VALUES (1,'whtsp'),(2,'alpsw'),(2,'aytinis'),(3,'sancr'),(3,'velsc'),(4,'sogsh'),(5,'crama'),(6,'whtpl'),(7,'lapwi'),(8,'reebu'),(8,'sarwa'),(8,'shag1'),(8,'turdo'),(9,'litst'),(9,'ovenb'),(9,'sante'),(9,'savsp'),(9,'swath'),(9,'ybsbu'),(10,'evegr'),(10,'grgsh'),(11,'chaff'),(11,'noror'),(12,'relpa'),(13,'gloib'),(14,'dunli'),(15,'caspl'),(16,'field'),(16,'lanhach'),(16,'meapi'),(16,'ribgu'),(17,'pibgr'),(17,'shttr'),(18,'allga'),(19,'blhbu'),(20,'mamwa'),(21,'ferdu'),(21,'pereg'),(21,'siski'),(21,'whimb'),(22,'henha'),(23,'duswa'),(24,'corsh'),(24,'hoowa'),(25,'grath'),(26,'jackd'),(26,'lesre'),(26,'sposa'),(27,'misth'),(28,'legsh'),(29,'rolle'),(30,'moorh'),(31,'egygo'),(32,'crane'),(33,'boowa'),(34,'vertera'),(35,'garwa'),(36,'litau'),(37,'yebbu'),(38,'categ'),(38,'coot1'),(38,'proubis'),(39,'smew1'),(40,'honbu'),(40,'yebsa'),(41,'yebwa');
/*!40000 ALTER TABLE `Jobs_pi___username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_provider`
--

DROP TABLE IF EXISTS `Jobs_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_provider` (
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_provider`
--

LOCK TABLES `Jobs_provider` WRITE;
/*!40000 ALTER TABLE `Jobs_provider` DISABLE KEYS */;
INSERT INTO `Jobs_provider` VALUES (1);
/*!40000 ALTER TABLE `Jobs_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_provider___qos`
--

DROP TABLE IF EXISTS `Jobs_provider___qos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_provider___qos` (
  `provider` int(11) NOT NULL,
  `qos` int(11) NOT NULL,
  PRIMARY KEY (`provider`,`qos`),
  KEY `idx_second_dimension` (`qos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_provider___qos`
--

LOCK TABLES `Jobs_provider___qos` WRITE;
/*!40000 ALTER TABLE `Jobs_provider___qos` DISABLE KEYS */;
INSERT INTO `Jobs_provider___qos` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19);
/*!40000 ALTER TABLE `Jobs_provider___qos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_provider___queue`
--

DROP TABLE IF EXISTS `Jobs_provider___queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_provider___queue` (
  `provider` int(11) NOT NULL,
  `queue` char(255) NOT NULL,
  PRIMARY KEY (`provider`,`queue`),
  KEY `idx_second_dimension` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_provider___queue`
--

LOCK TABLES `Jobs_provider___queue` WRITE;
/*!40000 ALTER TABLE `Jobs_provider___queue` DISABLE KEYS */;
INSERT INTO `Jobs_provider___queue` VALUES (1,'bannock'),(1,'barm'),(1,'black'),(1,'brioche'),(1,'brown'),(1,'chapti'),(1,'cornbread'),(1,'croutons'),(1,'crumpet'),(1,'focaccia'),(1,'nann'),(1,'panettone'),(1,'pikelet'),(1,'pita'),(1,'potbrood'),(1,'pumpernickel'),(1,'roti'),(1,'white');
/*!40000 ALTER TABLE `Jobs_provider___queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_provider___resource`
--

DROP TABLE IF EXISTS `Jobs_provider___resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_provider___resource` (
  `provider` int(11) NOT NULL,
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`provider`,`resource`),
  KEY `idx_second_dimension` (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_provider___resource`
--

LOCK TABLES `Jobs_provider___resource` WRITE;
/*!40000 ALTER TABLE `Jobs_provider___resource` DISABLE KEYS */;
INSERT INTO `Jobs_provider___resource` VALUES (1,1),(1,2),(1,3),(1,4),(1,5);
/*!40000 ALTER TABLE `Jobs_provider___resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_provider___resource_type`
--

DROP TABLE IF EXISTS `Jobs_provider___resource_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_provider___resource_type` (
  `provider` int(11) NOT NULL,
  `resource_type` int(11) NOT NULL,
  PRIMARY KEY (`provider`,`resource_type`),
  KEY `idx_second_dimension` (`resource_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_provider___resource_type`
--

LOCK TABLES `Jobs_provider___resource_type` WRITE;
/*!40000 ALTER TABLE `Jobs_provider___resource_type` DISABLE KEYS */;
INSERT INTO `Jobs_provider___resource_type` VALUES (1,1);
/*!40000 ALTER TABLE `Jobs_provider___resource_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_provider___username`
--

DROP TABLE IF EXISTS `Jobs_provider___username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_provider___username` (
  `provider` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`provider`,`username`),
  KEY `idx_second_dimension` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_provider___username`
--

LOCK TABLES `Jobs_provider___username` WRITE;
/*!40000 ALTER TABLE `Jobs_provider___username` DISABLE KEYS */;
INSERT INTO `Jobs_provider___username` VALUES (1,'allga'),(1,'alpsw'),(1,'aytinis'),(1,'blhbu'),(1,'boowa'),(1,'caspl'),(1,'categ'),(1,'chaff'),(1,'coot1'),(1,'corsh'),(1,'crama'),(1,'crane'),(1,'dunli'),(1,'duswa'),(1,'egygo'),(1,'evegr'),(1,'ferdu'),(1,'field'),(1,'garwa'),(1,'gloib'),(1,'grath'),(1,'grgsh'),(1,'henha'),(1,'honbu'),(1,'hoowa'),(1,'jackd'),(1,'lanhach'),(1,'lapwi'),(1,'legsh'),(1,'lesre'),(1,'litau'),(1,'litst'),(1,'mamwa'),(1,'meapi'),(1,'misth'),(1,'moorh'),(1,'noror'),(1,'ovenb'),(1,'pereg'),(1,'pibgr'),(1,'proubis'),(1,'reebu'),(1,'relpa'),(1,'ribgu'),(1,'rolle'),(1,'sancr'),(1,'sante'),(1,'sarwa'),(1,'savsp'),(1,'shag1'),(1,'shttr'),(1,'siski'),(1,'smew1'),(1,'sogsh'),(1,'sposa'),(1,'swath'),(1,'turdo'),(1,'velsc'),(1,'vertera'),(1,'whimb'),(1,'whtpl'),(1,'whtsp'),(1,'ybsbu'),(1,'yebbu'),(1,'yebsa'),(1,'yebwa');
/*!40000 ALTER TABLE `Jobs_provider___username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_qos`
--

DROP TABLE IF EXISTS `Jobs_qos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_qos` (
  `qos` int(11) NOT NULL,
  PRIMARY KEY (`qos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_qos`
--

LOCK TABLES `Jobs_qos` WRITE;
/*!40000 ALTER TABLE `Jobs_qos` DISABLE KEYS */;
INSERT INTO `Jobs_qos` VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13),(14),(15),(16),(17),(18),(19);
/*!40000 ALTER TABLE `Jobs_qos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_queue`
--

DROP TABLE IF EXISTS `Jobs_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_queue` (
  `queue` char(255) NOT NULL,
  PRIMARY KEY (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_queue`
--

LOCK TABLES `Jobs_queue` WRITE;
/*!40000 ALTER TABLE `Jobs_queue` DISABLE KEYS */;
INSERT INTO `Jobs_queue` VALUES ('bannock'),('barm'),('black'),('brioche'),('brown'),('chapti'),('cornbread'),('croutons'),('crumpet'),('focaccia'),('nann'),('panettone'),('pikelet'),('pita'),('potbrood'),('pumpernickel'),('roti'),('white');
/*!40000 ALTER TABLE `Jobs_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_resource`
--

DROP TABLE IF EXISTS `Jobs_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_resource` (
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_resource`
--

LOCK TABLES `Jobs_resource` WRITE;
/*!40000 ALTER TABLE `Jobs_resource` DISABLE KEYS */;
INSERT INTO `Jobs_resource` VALUES (1),(2),(3),(4),(5);
/*!40000 ALTER TABLE `Jobs_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_resource_type`
--

DROP TABLE IF EXISTS `Jobs_resource_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_resource_type` (
  `resource_type` int(11) NOT NULL,
  PRIMARY KEY (`resource_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_resource_type`
--

LOCK TABLES `Jobs_resource_type` WRITE;
/*!40000 ALTER TABLE `Jobs_resource_type` DISABLE KEYS */;
INSERT INTO `Jobs_resource_type` VALUES (1);
/*!40000 ALTER TABLE `Jobs_resource_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Jobs_username`
--

DROP TABLE IF EXISTS `Jobs_username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Jobs_username` (
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Jobs_username`
--

LOCK TABLES `Jobs_username` WRITE;
/*!40000 ALTER TABLE `Jobs_username` DISABLE KEYS */;
INSERT INTO `Jobs_username` VALUES ('allga'),('alpsw'),('aytinis'),('blhbu'),('boowa'),('caspl'),('categ'),('chaff'),('coot1'),('corsh'),('crama'),('crane'),('dunli'),('duswa'),('egygo'),('evegr'),('ferdu'),('field'),('garwa'),('gloib'),('grath'),('grgsh'),('henha'),('honbu'),('hoowa'),('jackd'),('lanhach'),('lapwi'),('legsh'),('lesre'),('litau'),('litst'),('mamwa'),('meapi'),('misth'),('moorh'),('noror'),('ovenb'),('pereg'),('pibgr'),('proubis'),('reebu'),('relpa'),('ribgu'),('rolle'),('sancr'),('sante'),('sarwa'),('savsp'),('shag1'),('shttr'),('siski'),('smew1'),('sogsh'),('sposa'),('swath'),('turdo'),('velsc'),('vertera'),('whimb'),('whtpl'),('whtsp'),('ybsbu'),('yebbu'),('yebsa'),('yebwa');
/*!40000 ALTER TABLE `Jobs_username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceSpecifications_provider`
--

DROP TABLE IF EXISTS `ResourceSpecifications_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceSpecifications_provider` (
  `provider` int(11) NOT NULL,
  PRIMARY KEY (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceSpecifications_provider`
--

LOCK TABLES `ResourceSpecifications_provider` WRITE;
/*!40000 ALTER TABLE `ResourceSpecifications_provider` DISABLE KEYS */;
INSERT INTO `ResourceSpecifications_provider` VALUES (1);
/*!40000 ALTER TABLE `ResourceSpecifications_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceSpecifications_provider___resource`
--

DROP TABLE IF EXISTS `ResourceSpecifications_provider___resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceSpecifications_provider___resource` (
  `provider` int(11) NOT NULL,
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`provider`,`resource`),
  KEY `idx_second_dimension` (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceSpecifications_provider___resource`
--

LOCK TABLES `ResourceSpecifications_provider___resource` WRITE;
/*!40000 ALTER TABLE `ResourceSpecifications_provider___resource` DISABLE KEYS */;
INSERT INTO `ResourceSpecifications_provider___resource` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,8),(1,9);
/*!40000 ALTER TABLE `ResourceSpecifications_provider___resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceSpecifications_provider___resource_allocation_type`
--

DROP TABLE IF EXISTS `ResourceSpecifications_provider___resource_allocation_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceSpecifications_provider___resource_allocation_type` (
  `provider` int(11) NOT NULL,
  `resource_allocation_type` int(11) NOT NULL,
  PRIMARY KEY (`provider`,`resource_allocation_type`),
  KEY `idx_second_dimension` (`resource_allocation_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceSpecifications_provider___resource_allocation_type`
--

LOCK TABLES `ResourceSpecifications_provider___resource_allocation_type` WRITE;
/*!40000 ALTER TABLE `ResourceSpecifications_provider___resource_allocation_type` DISABLE KEYS */;
INSERT INTO `ResourceSpecifications_provider___resource_allocation_type` VALUES (1,1),(1,2),(1,3),(1,4);
/*!40000 ALTER TABLE `ResourceSpecifications_provider___resource_allocation_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceSpecifications_provider___resource_type`
--

DROP TABLE IF EXISTS `ResourceSpecifications_provider___resource_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceSpecifications_provider___resource_type` (
  `provider` int(11) NOT NULL,
  `resource_type` int(11) NOT NULL,
  PRIMARY KEY (`provider`,`resource_type`),
  KEY `idx_second_dimension` (`resource_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceSpecifications_provider___resource_type`
--

LOCK TABLES `ResourceSpecifications_provider___resource_type` WRITE;
/*!40000 ALTER TABLE `ResourceSpecifications_provider___resource_type` DISABLE KEYS */;
INSERT INTO `ResourceSpecifications_provider___resource_type` VALUES (1,1),(1,5);
/*!40000 ALTER TABLE `ResourceSpecifications_provider___resource_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceSpecifications_resource`
--

DROP TABLE IF EXISTS `ResourceSpecifications_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceSpecifications_resource` (
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceSpecifications_resource`
--

LOCK TABLES `ResourceSpecifications_resource` WRITE;
/*!40000 ALTER TABLE `ResourceSpecifications_resource` DISABLE KEYS */;
INSERT INTO `ResourceSpecifications_resource` VALUES (1),(2),(3),(4),(5),(8),(9);
/*!40000 ALTER TABLE `ResourceSpecifications_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceSpecifications_resource_allocation_type`
--

DROP TABLE IF EXISTS `ResourceSpecifications_resource_allocation_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceSpecifications_resource_allocation_type` (
  `resource_allocation_type` int(11) NOT NULL,
  PRIMARY KEY (`resource_allocation_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceSpecifications_resource_allocation_type`
--

LOCK TABLES `ResourceSpecifications_resource_allocation_type` WRITE;
/*!40000 ALTER TABLE `ResourceSpecifications_resource_allocation_type` DISABLE KEYS */;
INSERT INTO `ResourceSpecifications_resource_allocation_type` VALUES (1),(2),(3),(4);
/*!40000 ALTER TABLE `ResourceSpecifications_resource_allocation_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResourceSpecifications_resource_type`
--

DROP TABLE IF EXISTS `ResourceSpecifications_resource_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ResourceSpecifications_resource_type` (
  `resource_type` int(11) NOT NULL,
  PRIMARY KEY (`resource_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResourceSpecifications_resource_type`
--

LOCK TABLES `ResourceSpecifications_resource_type` WRITE;
/*!40000 ALTER TABLE `ResourceSpecifications_resource_type` DISABLE KEYS */;
INSERT INTO `ResourceSpecifications_resource_type` VALUES (1),(5);
/*!40000 ALTER TABLE `ResourceSpecifications_resource_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_fieldofscience`
--

DROP TABLE IF EXISTS `Storage_fieldofscience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_fieldofscience` (
  `fieldofscience` int(11) NOT NULL,
  PRIMARY KEY (`fieldofscience`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_fieldofscience`
--

LOCK TABLES `Storage_fieldofscience` WRITE;
/*!40000 ALTER TABLE `Storage_fieldofscience` DISABLE KEYS */;
INSERT INTO `Storage_fieldofscience` VALUES (1),(10),(44),(45),(47),(49),(53),(55),(57),(60),(61),(65),(68),(69),(70),(71),(72),(74),(81),(84),(88),(90),(91),(93),(94),(115),(119),(122),(123),(124),(126),(137);
/*!40000 ALTER TABLE `Storage_fieldofscience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_fieldofscience___person`
--

DROP TABLE IF EXISTS `Storage_fieldofscience___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_fieldofscience___person` (
  `fieldofscience` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`fieldofscience`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_fieldofscience___person`
--

LOCK TABLES `Storage_fieldofscience___person` WRITE;
/*!40000 ALTER TABLE `Storage_fieldofscience___person` DISABLE KEYS */;
INSERT INTO `Storage_fieldofscience___person` VALUES (1,75),(1,639),(1,640),(1,645),(1,646),(1,649),(1,651),(1,653),(1,655),(1,657),(1,659),(1,660),(1,661),(1,663),(1,665),(1,666),(1,667),(1,668),(1,669),(1,670),(1,671),(1,672),(1,676),(1,678),(1,680),(1,682),(1,683),(1,684),(1,685),(1,686),(1,690),(1,691),(1,692),(1,694),(1,696),(1,697),(1,698),(1,699),(1,701),(1,703),(1,704),(1,707),(1,708),(1,709),(1,710),(1,711),(1,712),(1,714),(1,717),(1,718),(1,720),(1,722),(1,723),(1,724),(1,725),(1,728),(1,730),(1,733),(1,735),(1,736),(1,737),(1,738),(1,739),(1,740),(1,741),(1,743),(1,745),(1,746),(1,747),(1,748),(1,750),(1,751),(1,752),(1,754),(1,755),(1,756),(1,759),(1,761),(1,763),(1,764),(1,765),(1,772),(1,773),(1,777),(1,779),(1,784),(1,786),(1,788),(1,790),(1,792),(1,793),(1,795),(1,796),(1,799),(1,800),(1,801),(1,803),(1,805),(1,806),(1,808),(1,809),(1,810),(1,812),(1,817),(1,819),(1,820),(1,823),(1,824),(1,825),(1,828),(1,829),(1,832),(1,833),(1,836),(1,838),(1,840),(1,841),(1,842),(1,843),(1,847),(1,850),(1,852),(1,855),(1,856),(1,857),(1,858),(1,862),(1,863),(1,867),(1,868),(1,871),(1,873),(1,875),(1,876),(1,877),(1,879),(1,881),(1,882),(1,883),(1,885),(1,886),(1,888),(1,890),(1,891),(1,893),(1,894),(1,899),(1,900),(1,901),(1,902),(1,905),(1,912),(1,919),(1,920),(1,921),(1,923),(1,927),(1,930),(1,931),(1,933),(1,934),(1,935),(1,939),(1,941),(1,942),(1,947),(1,949),(1,951),(1,953),(1,957),(1,958),(1,959),(1,960),(1,963),(1,964),(1,967),(1,968),(1,970),(1,971),(1,972),(1,973),(1,975),(1,976),(1,977),(1,979),(1,980),(1,981),(1,983),(10,109),(10,911),(44,774),(44,776),(44,813),(44,956),(44,974),(45,11),(45,92),(45,853),(45,869),(47,95),(47,106),(47,128),(47,130),(47,131),(47,642),(47,732),(47,782),(47,797),(47,845),(47,846),(47,872),(47,929),(47,936),(47,945),(49,14),(53,27),(53,849),(55,113),(55,804),(57,82),(57,775),(57,837),(57,914),(57,926),(57,928),(57,948),(57,954),(57,965),(60,827),(61,10),(61,76),(61,910),(65,120),(68,100),(68,794),(68,818),(68,831),(68,866),(68,874),(68,915),(68,944),(68,950),(68,961),(69,35),(69,78),(69,865),(70,859),(70,904),(71,36),(71,87),(72,5),(72,72),(72,785),(72,815),(72,864),(72,943),(74,946),(81,118),(81,851),(84,4),(84,108),(84,848),(88,74),(88,906),(90,908),(90,938),(91,69),(91,70),(91,96),(91,781),(91,783),(91,787),(91,791),(91,798),(91,802),(91,814),(91,861),(91,884),(91,895),(91,897),(91,925),(91,932),(91,937),(91,966),(91,969),(91,982),(93,83),(93,112),(93,887),(94,25),(94,80),(94,778),(94,830),(94,835),(94,844),(94,898),(94,907),(94,916),(94,922),(94,924),(94,955),(115,93),(115,102),(115,104),(115,110),(115,780),(115,811),(115,821),(115,826),(115,834),(115,860),(115,889),(115,892),(115,896),(115,903),(115,918),(119,115),(119,878),(119,952),(122,2),(122,65),(122,807),(122,816),(122,822),(122,839),(122,940),(122,978),(123,8),(123,97),(123,103),(123,105),(123,111),(123,870),(123,909),(123,913),(123,917),(123,962),(124,3),(124,101),(126,880),(137,24),(137,71),(137,789),(137,854);
/*!40000 ALTER TABLE `Storage_fieldofscience___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_fieldofscience___pi`
--

DROP TABLE IF EXISTS `Storage_fieldofscience___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_fieldofscience___pi` (
  `fieldofscience` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`fieldofscience`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_fieldofscience___pi`
--

LOCK TABLES `Storage_fieldofscience___pi` WRITE;
/*!40000 ALTER TABLE `Storage_fieldofscience___pi` DISABLE KEYS */;
INSERT INTO `Storage_fieldofscience___pi` VALUES (1,75),(1,131),(1,639),(1,640),(1,645),(1,646),(1,647),(1,648),(1,649),(1,650),(1,651),(1,652),(1,653),(1,654),(1,655),(1,656),(1,657),(1,658),(1,659),(1,660),(1,661),(1,662),(1,663),(1,664),(1,665),(1,666),(1,667),(1,668),(1,669),(1,670),(1,671),(1,672),(1,673),(1,674),(1,675),(1,676),(1,677),(1,678),(1,679),(1,680),(1,681),(1,682),(1,683),(1,684),(1,685),(1,686),(1,687),(1,688),(1,689),(1,690),(1,691),(1,692),(1,693),(1,694),(1,695),(1,696),(1,697),(1,698),(1,699),(1,700),(1,701),(1,702),(1,703),(1,704),(1,705),(1,706),(1,707),(1,708),(1,709),(1,710),(1,711),(1,712),(1,713),(1,714),(1,715),(1,716),(1,717),(1,718),(1,719),(1,720),(1,721),(1,722),(1,723),(1,724),(1,725),(1,726),(1,727),(1,728),(1,729),(1,730),(1,731),(1,732),(1,733),(1,734),(1,735),(1,736),(1,737),(1,738),(1,739),(1,740),(1,741),(1,742),(1,743),(1,744),(1,745),(1,746),(1,747),(1,748),(1,749),(1,750),(1,751),(1,752),(1,753),(1,754),(1,755),(1,756),(1,757),(1,758),(1,759),(1,760),(1,761),(1,762),(1,763),(1,764),(1,765),(10,26),(44,33),(45,11),(47,17),(49,14),(53,27),(55,34),(57,40),(60,12),(61,10),(65,41),(68,29),(69,35),(70,28),(71,36),(72,5),(74,13),(81,37),(84,4),(88,23),(90,31),(91,38),(93,16),(94,25),(115,9),(119,6),(122,2),(123,8),(124,3),(126,39),(137,24);
/*!40000 ALTER TABLE `Storage_fieldofscience___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_mountpoint`
--

DROP TABLE IF EXISTS `Storage_mountpoint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_mountpoint` (
  `mountpoint` int(11) NOT NULL,
  PRIMARY KEY (`mountpoint`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_mountpoint`
--

LOCK TABLES `Storage_mountpoint` WRITE;
/*!40000 ALTER TABLE `Storage_mountpoint` DISABLE KEYS */;
INSERT INTO `Storage_mountpoint` VALUES (1),(2),(3);
/*!40000 ALTER TABLE `Storage_mountpoint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_mountpoint___person`
--

DROP TABLE IF EXISTS `Storage_mountpoint___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_mountpoint___person` (
  `mountpoint` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`mountpoint`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_mountpoint___person`
--

LOCK TABLES `Storage_mountpoint___person` WRITE;
/*!40000 ALTER TABLE `Storage_mountpoint___person` DISABLE KEYS */;
INSERT INTO `Storage_mountpoint___person` VALUES (1,2),(1,11),(1,25),(1,27),(1,36),(1,106),(1,131),(1,639),(1,640),(1,642),(2,130),(2,131),(2,645),(2,651),(2,657),(2,668),(2,707),(2,711),(2,722),(2,751),(3,2),(3,3),(3,4),(3,5),(3,8),(3,10),(3,11),(3,14),(3,24),(3,25),(3,35),(3,65),(3,69),(3,70),(3,71),(3,72),(3,74),(3,75),(3,76),(3,78),(3,80),(3,82),(3,83),(3,87),(3,92),(3,93),(3,95),(3,96),(3,97),(3,100),(3,101),(3,102),(3,103),(3,104),(3,105),(3,106),(3,108),(3,109),(3,110),(3,111),(3,112),(3,113),(3,115),(3,118),(3,120),(3,128),(3,130),(3,131),(3,639),(3,642),(3,646),(3,649),(3,651),(3,653),(3,655),(3,659),(3,660),(3,661),(3,663),(3,665),(3,666),(3,667),(3,669),(3,670),(3,671),(3,672),(3,676),(3,678),(3,680),(3,682),(3,683),(3,684),(3,685),(3,686),(3,690),(3,691),(3,692),(3,694),(3,696),(3,697),(3,698),(3,699),(3,701),(3,703),(3,704),(3,708),(3,709),(3,710),(3,712),(3,714),(3,717),(3,718),(3,720),(3,723),(3,724),(3,725),(3,728),(3,730),(3,732),(3,733),(3,735),(3,736),(3,737),(3,738),(3,739),(3,740),(3,741),(3,743),(3,745),(3,746),(3,747),(3,748),(3,750),(3,752),(3,754),(3,755),(3,756),(3,759),(3,761),(3,763),(3,764),(3,765),(3,772),(3,773),(3,774),(3,775),(3,776),(3,777),(3,778),(3,779),(3,780),(3,781),(3,782),(3,783),(3,784),(3,785),(3,786),(3,787),(3,788),(3,789),(3,790),(3,791),(3,792),(3,793),(3,794),(3,795),(3,796),(3,797),(3,798),(3,799),(3,800),(3,801),(3,802),(3,803),(3,804),(3,805),(3,806),(3,807),(3,808),(3,809),(3,810),(3,811),(3,812),(3,813),(3,814),(3,815),(3,816),(3,817),(3,818),(3,819),(3,820),(3,821),(3,822),(3,823),(3,824),(3,825),(3,826),(3,827),(3,828),(3,829),(3,830),(3,831),(3,832),(3,833),(3,834),(3,835),(3,836),(3,837),(3,838),(3,839),(3,840),(3,841),(3,842),(3,843),(3,844),(3,845),(3,846),(3,847),(3,848),(3,849),(3,850),(3,851),(3,852),(3,853),(3,854),(3,855),(3,856),(3,857),(3,858),(3,859),(3,860),(3,861),(3,862),(3,863),(3,864),(3,865),(3,866),(3,867),(3,868),(3,869),(3,870),(3,871),(3,872),(3,873),(3,874),(3,875),(3,876),(3,877),(3,878),(3,879),(3,880),(3,881),(3,882),(3,883),(3,884),(3,885),(3,886),(3,887),(3,888),(3,889),(3,890),(3,891),(3,892),(3,893),(3,894),(3,895),(3,896),(3,897),(3,898),(3,899),(3,900),(3,901),(3,902),(3,903),(3,904),(3,905),(3,906),(3,907),(3,908),(3,909),(3,910),(3,911),(3,912),(3,913),(3,914),(3,915),(3,916),(3,917),(3,918),(3,919),(3,920),(3,921),(3,922),(3,923),(3,924),(3,925),(3,926),(3,927),(3,928),(3,929),(3,930),(3,931),(3,932),(3,933),(3,934),(3,935),(3,936),(3,937),(3,938),(3,939),(3,940),(3,941),(3,942),(3,943),(3,944),(3,945),(3,946),(3,947),(3,948),(3,949),(3,950),(3,951),(3,952),(3,953),(3,954),(3,955),(3,956),(3,957),(3,958),(3,959),(3,960),(3,961),(3,962),(3,963),(3,964),(3,965),(3,966),(3,967),(3,968),(3,969),(3,970),(3,971),(3,972),(3,973),(3,974),(3,975),(3,976),(3,977),(3,978),(3,979),(3,980),(3,981),(3,982),(3,983);
/*!40000 ALTER TABLE `Storage_mountpoint___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_mountpoint___pi`
--

DROP TABLE IF EXISTS `Storage_mountpoint___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_mountpoint___pi` (
  `mountpoint` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`mountpoint`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_mountpoint___pi`
--

LOCK TABLES `Storage_mountpoint___pi` WRITE;
/*!40000 ALTER TABLE `Storage_mountpoint___pi` DISABLE KEYS */;
INSERT INTO `Storage_mountpoint___pi` VALUES (1,2),(1,11),(1,17),(1,25),(1,27),(1,36),(1,639),(1,640),(2,17),(2,645),(2,651),(2,657),(2,668),(2,707),(2,711),(2,722),(2,751),(3,2),(3,3),(3,4),(3,5),(3,6),(3,8),(3,9),(3,10),(3,11),(3,12),(3,13),(3,14),(3,16),(3,17),(3,23),(3,24),(3,25),(3,26),(3,27),(3,28),(3,29),(3,31),(3,33),(3,34),(3,35),(3,36),(3,37),(3,38),(3,39),(3,40),(3,41),(3,75),(3,131),(3,639),(3,640),(3,646),(3,647),(3,648),(3,649),(3,650),(3,651),(3,652),(3,653),(3,654),(3,655),(3,656),(3,658),(3,659),(3,660),(3,661),(3,662),(3,663),(3,664),(3,665),(3,666),(3,667),(3,669),(3,670),(3,671),(3,672),(3,673),(3,674),(3,675),(3,676),(3,677),(3,678),(3,679),(3,680),(3,681),(3,682),(3,683),(3,684),(3,685),(3,686),(3,687),(3,688),(3,689),(3,690),(3,691),(3,692),(3,693),(3,694),(3,695),(3,696),(3,697),(3,698),(3,699),(3,700),(3,701),(3,702),(3,703),(3,704),(3,705),(3,706),(3,708),(3,709),(3,710),(3,712),(3,713),(3,714),(3,715),(3,716),(3,717),(3,718),(3,719),(3,720),(3,721),(3,723),(3,724),(3,725),(3,726),(3,727),(3,728),(3,729),(3,730),(3,731),(3,732),(3,733),(3,734),(3,735),(3,736),(3,737),(3,738),(3,739),(3,740),(3,741),(3,742),(3,743),(3,744),(3,745),(3,746),(3,747),(3,748),(3,749),(3,750),(3,752),(3,753),(3,754),(3,755),(3,756),(3,757),(3,758),(3,759),(3,760),(3,761),(3,762),(3,763),(3,764),(3,765);
/*!40000 ALTER TABLE `Storage_mountpoint___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_nsfdirectorate`
--

DROP TABLE IF EXISTS `Storage_nsfdirectorate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_nsfdirectorate` (
  `nsfdirectorate` int(11) NOT NULL,
  PRIMARY KEY (`nsfdirectorate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_nsfdirectorate`
--

LOCK TABLES `Storage_nsfdirectorate` WRITE;
/*!40000 ALTER TABLE `Storage_nsfdirectorate` DISABLE KEYS */;
INSERT INTO `Storage_nsfdirectorate` VALUES (1),(2),(3),(4),(5),(6),(7),(9);
/*!40000 ALTER TABLE `Storage_nsfdirectorate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_nsfdirectorate___person`
--

DROP TABLE IF EXISTS `Storage_nsfdirectorate___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_nsfdirectorate___person` (
  `nsfdirectorate` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`nsfdirectorate`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_nsfdirectorate___person`
--

LOCK TABLES `Storage_nsfdirectorate___person` WRITE;
/*!40000 ALTER TABLE `Storage_nsfdirectorate___person` DISABLE KEYS */;
INSERT INTO `Storage_nsfdirectorate___person` VALUES (1,75),(1,639),(1,640),(1,645),(1,646),(1,649),(1,651),(1,653),(1,655),(1,657),(1,659),(1,660),(1,661),(1,663),(1,665),(1,666),(1,667),(1,668),(1,669),(1,670),(1,671),(1,672),(1,676),(1,678),(1,680),(1,682),(1,683),(1,684),(1,685),(1,686),(1,690),(1,691),(1,692),(1,694),(1,696),(1,697),(1,698),(1,699),(1,701),(1,703),(1,704),(1,707),(1,708),(1,709),(1,710),(1,711),(1,712),(1,714),(1,717),(1,718),(1,720),(1,722),(1,723),(1,724),(1,725),(1,728),(1,730),(1,733),(1,735),(1,736),(1,737),(1,738),(1,739),(1,740),(1,741),(1,743),(1,745),(1,746),(1,747),(1,748),(1,750),(1,751),(1,752),(1,754),(1,755),(1,756),(1,759),(1,761),(1,763),(1,764),(1,765),(1,772),(1,773),(1,777),(1,779),(1,784),(1,786),(1,788),(1,790),(1,792),(1,793),(1,795),(1,796),(1,799),(1,800),(1,801),(1,803),(1,805),(1,806),(1,808),(1,809),(1,810),(1,812),(1,817),(1,819),(1,820),(1,823),(1,824),(1,825),(1,828),(1,829),(1,832),(1,833),(1,836),(1,838),(1,840),(1,841),(1,842),(1,843),(1,847),(1,850),(1,852),(1,855),(1,856),(1,857),(1,858),(1,862),(1,863),(1,867),(1,868),(1,871),(1,873),(1,875),(1,876),(1,877),(1,879),(1,881),(1,882),(1,883),(1,885),(1,886),(1,888),(1,890),(1,891),(1,893),(1,894),(1,899),(1,900),(1,901),(1,902),(1,905),(1,912),(1,919),(1,920),(1,921),(1,923),(1,927),(1,930),(1,931),(1,933),(1,934),(1,935),(1,939),(1,941),(1,942),(1,947),(1,949),(1,951),(1,953),(1,957),(1,958),(1,959),(1,960),(1,963),(1,964),(1,967),(1,968),(1,970),(1,971),(1,972),(1,973),(1,975),(1,976),(1,977),(1,979),(1,980),(1,981),(1,983),(2,2),(2,3),(2,8),(2,27),(2,35),(2,65),(2,78),(2,93),(2,97),(2,101),(2,102),(2,103),(2,104),(2,105),(2,110),(2,111),(2,115),(2,780),(2,807),(2,811),(2,816),(2,821),(2,822),(2,826),(2,834),(2,839),(2,849),(2,860),(2,865),(2,870),(2,878),(2,880),(2,889),(2,892),(2,896),(2,903),(2,909),(2,913),(2,917),(2,918),(2,940),(2,952),(2,962),(2,978),(3,11),(3,14),(3,92),(3,95),(3,106),(3,128),(3,130),(3,131),(3,642),(3,732),(3,774),(3,776),(3,782),(3,797),(3,813),(3,845),(3,846),(3,853),(3,869),(3,872),(3,929),(3,936),(3,945),(3,956),(3,974),(4,24),(4,71),(4,789),(4,854),(5,25),(5,69),(5,70),(5,74),(5,80),(5,83),(5,96),(5,112),(5,778),(5,781),(5,783),(5,787),(5,791),(5,798),(5,802),(5,814),(5,830),(5,835),(5,844),(5,861),(5,884),(5,887),(5,895),(5,897),(5,898),(5,906),(5,907),(5,908),(5,916),(5,922),(5,924),(5,925),(5,932),(5,937),(5,938),(5,955),(5,966),(5,969),(5,982),(6,4),(6,5),(6,36),(6,72),(6,87),(6,100),(6,108),(6,118),(6,120),(6,785),(6,794),(6,815),(6,818),(6,831),(6,848),(6,851),(6,859),(6,864),(6,866),(6,874),(6,904),(6,915),(6,943),(6,944),(6,946),(6,950),(6,961),(7,109),(7,911),(9,10),(9,76),(9,82),(9,113),(9,775),(9,804),(9,827),(9,837),(9,910),(9,914),(9,926),(9,928),(9,948),(9,954),(9,965);
/*!40000 ALTER TABLE `Storage_nsfdirectorate___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_nsfdirectorate___pi`
--

DROP TABLE IF EXISTS `Storage_nsfdirectorate___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_nsfdirectorate___pi` (
  `nsfdirectorate` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`nsfdirectorate`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_nsfdirectorate___pi`
--

LOCK TABLES `Storage_nsfdirectorate___pi` WRITE;
/*!40000 ALTER TABLE `Storage_nsfdirectorate___pi` DISABLE KEYS */;
INSERT INTO `Storage_nsfdirectorate___pi` VALUES (1,75),(1,131),(1,639),(1,640),(1,645),(1,646),(1,647),(1,648),(1,649),(1,650),(1,651),(1,652),(1,653),(1,654),(1,655),(1,656),(1,657),(1,658),(1,659),(1,660),(1,661),(1,662),(1,663),(1,664),(1,665),(1,666),(1,667),(1,668),(1,669),(1,670),(1,671),(1,672),(1,673),(1,674),(1,675),(1,676),(1,677),(1,678),(1,679),(1,680),(1,681),(1,682),(1,683),(1,684),(1,685),(1,686),(1,687),(1,688),(1,689),(1,690),(1,691),(1,692),(1,693),(1,694),(1,695),(1,696),(1,697),(1,698),(1,699),(1,700),(1,701),(1,702),(1,703),(1,704),(1,705),(1,706),(1,707),(1,708),(1,709),(1,710),(1,711),(1,712),(1,713),(1,714),(1,715),(1,716),(1,717),(1,718),(1,719),(1,720),(1,721),(1,722),(1,723),(1,724),(1,725),(1,726),(1,727),(1,728),(1,729),(1,730),(1,731),(1,732),(1,733),(1,734),(1,735),(1,736),(1,737),(1,738),(1,739),(1,740),(1,741),(1,742),(1,743),(1,744),(1,745),(1,746),(1,747),(1,748),(1,749),(1,750),(1,751),(1,752),(1,753),(1,754),(1,755),(1,756),(1,757),(1,758),(1,759),(1,760),(1,761),(1,762),(1,763),(1,764),(1,765),(2,2),(2,3),(2,6),(2,8),(2,9),(2,27),(2,35),(2,39),(3,11),(3,14),(3,17),(3,33),(4,24),(5,16),(5,23),(5,25),(5,31),(5,38),(6,4),(6,5),(6,13),(6,28),(6,29),(6,36),(6,37),(6,41),(7,26),(9,10),(9,12),(9,34),(9,40);
/*!40000 ALTER TABLE `Storage_nsfdirectorate___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_parentscience`
--

DROP TABLE IF EXISTS `Storage_parentscience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_parentscience` (
  `parentscience` int(11) NOT NULL,
  PRIMARY KEY (`parentscience`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_parentscience`
--

LOCK TABLES `Storage_parentscience` WRITE;
/*!40000 ALTER TABLE `Storage_parentscience` DISABLE KEYS */;
INSERT INTO `Storage_parentscience` VALUES (1),(10),(12),(13),(19),(20),(22),(23),(24),(25),(26),(28),(34),(35),(36),(39),(40);
/*!40000 ALTER TABLE `Storage_parentscience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_parentscience___person`
--

DROP TABLE IF EXISTS `Storage_parentscience___person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_parentscience___person` (
  `parentscience` int(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`parentscience`,`person`),
  KEY `idx_second_dimension` (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_parentscience___person`
--

LOCK TABLES `Storage_parentscience___person` WRITE;
/*!40000 ALTER TABLE `Storage_parentscience___person` DISABLE KEYS */;
INSERT INTO `Storage_parentscience___person` VALUES (1,75),(1,639),(1,640),(1,645),(1,646),(1,649),(1,651),(1,653),(1,655),(1,657),(1,659),(1,660),(1,661),(1,663),(1,665),(1,666),(1,667),(1,668),(1,669),(1,670),(1,671),(1,672),(1,676),(1,678),(1,680),(1,682),(1,683),(1,684),(1,685),(1,686),(1,690),(1,691),(1,692),(1,694),(1,696),(1,697),(1,698),(1,699),(1,701),(1,703),(1,704),(1,707),(1,708),(1,709),(1,710),(1,711),(1,712),(1,714),(1,717),(1,718),(1,720),(1,722),(1,723),(1,724),(1,725),(1,728),(1,730),(1,733),(1,735),(1,736),(1,737),(1,738),(1,739),(1,740),(1,741),(1,743),(1,745),(1,746),(1,747),(1,748),(1,750),(1,751),(1,752),(1,754),(1,755),(1,756),(1,759),(1,761),(1,763),(1,764),(1,765),(1,772),(1,773),(1,777),(1,779),(1,784),(1,786),(1,788),(1,790),(1,792),(1,793),(1,795),(1,796),(1,799),(1,800),(1,801),(1,803),(1,805),(1,806),(1,808),(1,809),(1,810),(1,812),(1,817),(1,819),(1,820),(1,823),(1,824),(1,825),(1,828),(1,829),(1,832),(1,833),(1,836),(1,838),(1,840),(1,841),(1,842),(1,843),(1,847),(1,850),(1,852),(1,855),(1,856),(1,857),(1,858),(1,862),(1,863),(1,867),(1,868),(1,871),(1,873),(1,875),(1,876),(1,877),(1,879),(1,881),(1,882),(1,883),(1,885),(1,886),(1,888),(1,890),(1,891),(1,893),(1,894),(1,899),(1,900),(1,901),(1,902),(1,905),(1,912),(1,919),(1,920),(1,921),(1,923),(1,927),(1,930),(1,931),(1,933),(1,934),(1,935),(1,939),(1,941),(1,942),(1,947),(1,949),(1,951),(1,953),(1,957),(1,958),(1,959),(1,960),(1,963),(1,964),(1,967),(1,968),(1,970),(1,971),(1,972),(1,973),(1,975),(1,976),(1,977),(1,979),(1,980),(1,981),(1,983),(10,109),(10,911),(12,93),(12,102),(12,104),(12,110),(12,780),(12,811),(12,821),(12,826),(12,834),(12,860),(12,889),(12,892),(12,896),(12,903),(12,918),(13,120),(19,2),(19,8),(19,65),(19,97),(19,103),(19,105),(19,111),(19,807),(19,816),(19,822),(19,839),(19,870),(19,909),(19,913),(19,917),(19,940),(19,962),(19,978),(20,74),(20,906),(22,14),(23,3),(23,101),(23,880),(24,27),(24,35),(24,78),(24,849),(24,865),(25,4),(25,108),(25,118),(25,848),(25,851),(26,5),(26,36),(26,72),(26,87),(26,100),(26,785),(26,794),(26,815),(26,818),(26,831),(26,859),(26,864),(26,866),(26,874),(26,904),(26,915),(26,943),(26,944),(26,946),(26,950),(26,961),(28,25),(28,80),(28,83),(28,112),(28,778),(28,830),(28,835),(28,844),(28,887),(28,898),(28,907),(28,916),(28,922),(28,924),(28,955),(34,11),(34,92),(34,95),(34,106),(34,128),(34,130),(34,131),(34,642),(34,732),(34,774),(34,776),(34,782),(34,797),(34,813),(34,845),(34,846),(34,853),(34,869),(34,872),(34,929),(34,936),(34,945),(34,956),(34,974),(35,24),(35,71),(35,789),(35,854),(36,69),(36,70),(36,96),(36,781),(36,783),(36,787),(36,791),(36,798),(36,802),(36,814),(36,861),(36,884),(36,895),(36,897),(36,908),(36,925),(36,932),(36,937),(36,938),(36,966),(36,969),(36,982),(39,115),(39,878),(39,952),(40,10),(40,76),(40,82),(40,113),(40,775),(40,804),(40,827),(40,837),(40,910),(40,914),(40,926),(40,928),(40,948),(40,954),(40,965);
/*!40000 ALTER TABLE `Storage_parentscience___person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_parentscience___pi`
--

DROP TABLE IF EXISTS `Storage_parentscience___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_parentscience___pi` (
  `parentscience` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`parentscience`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_parentscience___pi`
--

LOCK TABLES `Storage_parentscience___pi` WRITE;
/*!40000 ALTER TABLE `Storage_parentscience___pi` DISABLE KEYS */;
INSERT INTO `Storage_parentscience___pi` VALUES (1,75),(1,131),(1,639),(1,640),(1,645),(1,646),(1,647),(1,648),(1,649),(1,650),(1,651),(1,652),(1,653),(1,654),(1,655),(1,656),(1,657),(1,658),(1,659),(1,660),(1,661),(1,662),(1,663),(1,664),(1,665),(1,666),(1,667),(1,668),(1,669),(1,670),(1,671),(1,672),(1,673),(1,674),(1,675),(1,676),(1,677),(1,678),(1,679),(1,680),(1,681),(1,682),(1,683),(1,684),(1,685),(1,686),(1,687),(1,688),(1,689),(1,690),(1,691),(1,692),(1,693),(1,694),(1,695),(1,696),(1,697),(1,698),(1,699),(1,700),(1,701),(1,702),(1,703),(1,704),(1,705),(1,706),(1,707),(1,708),(1,709),(1,710),(1,711),(1,712),(1,713),(1,714),(1,715),(1,716),(1,717),(1,718),(1,719),(1,720),(1,721),(1,722),(1,723),(1,724),(1,725),(1,726),(1,727),(1,728),(1,729),(1,730),(1,731),(1,732),(1,733),(1,734),(1,735),(1,736),(1,737),(1,738),(1,739),(1,740),(1,741),(1,742),(1,743),(1,744),(1,745),(1,746),(1,747),(1,748),(1,749),(1,750),(1,751),(1,752),(1,753),(1,754),(1,755),(1,756),(1,757),(1,758),(1,759),(1,760),(1,761),(1,762),(1,763),(1,764),(1,765),(10,26),(12,9),(13,41),(19,2),(19,8),(20,23),(22,14),(23,3),(23,39),(24,27),(24,35),(25,4),(25,37),(26,5),(26,13),(26,28),(26,29),(26,36),(28,16),(28,25),(34,11),(34,17),(34,33),(35,24),(36,31),(36,38),(39,6),(40,10),(40,12),(40,34),(40,40);
/*!40000 ALTER TABLE `Storage_parentscience___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_person`
--

DROP TABLE IF EXISTS `Storage_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_person` (
  `person` int(11) NOT NULL,
  PRIMARY KEY (`person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_person`
--

LOCK TABLES `Storage_person` WRITE;
/*!40000 ALTER TABLE `Storage_person` DISABLE KEYS */;
INSERT INTO `Storage_person` VALUES (2),(3),(4),(5),(8),(10),(11),(14),(24),(25),(27),(35),(36),(65),(69),(70),(71),(72),(74),(75),(76),(78),(80),(82),(83),(87),(92),(93),(95),(96),(97),(100),(101),(102),(103),(104),(105),(106),(108),(109),(110),(111),(112),(113),(115),(118),(120),(128),(130),(131),(639),(640),(642),(645),(646),(649),(651),(653),(655),(657),(659),(660),(661),(663),(665),(666),(667),(668),(669),(670),(671),(672),(676),(678),(680),(682),(683),(684),(685),(686),(690),(691),(692),(694),(696),(697),(698),(699),(701),(703),(704),(707),(708),(709),(710),(711),(712),(714),(717),(718),(720),(722),(723),(724),(725),(728),(730),(732),(733),(735),(736),(737),(738),(739),(740),(741),(743),(745),(746),(747),(748),(750),(751),(752),(754),(755),(756),(759),(761),(763),(764),(765),(772),(773),(774),(775),(776),(777),(778),(779),(780),(781),(782),(783),(784),(785),(786),(787),(788),(789),(790),(791),(792),(793),(794),(795),(796),(797),(798),(799),(800),(801),(802),(803),(804),(805),(806),(807),(808),(809),(810),(811),(812),(813),(814),(815),(816),(817),(818),(819),(820),(821),(822),(823),(824),(825),(826),(827),(828),(829),(830),(831),(832),(833),(834),(835),(836),(837),(838),(839),(840),(841),(842),(843),(844),(845),(846),(847),(848),(849),(850),(851),(852),(853),(854),(855),(856),(857),(858),(859),(860),(861),(862),(863),(864),(865),(866),(867),(868),(869),(870),(871),(872),(873),(874),(875),(876),(877),(878),(879),(880),(881),(882),(883),(884),(885),(886),(887),(888),(889),(890),(891),(892),(893),(894),(895),(896),(897),(898),(899),(900),(901),(902),(903),(904),(905),(906),(907),(908),(909),(910),(911),(912),(913),(914),(915),(916),(917),(918),(919),(920),(921),(922),(923),(924),(925),(926),(927),(928),(929),(930),(931),(932),(933),(934),(935),(936),(937),(938),(939),(940),(941),(942),(943),(944),(945),(946),(947),(948),(949),(950),(951),(952),(953),(954),(955),(956),(957),(958),(959),(960),(961),(962),(963),(964),(965),(966),(967),(968),(969),(970),(971),(972),(973),(974),(975),(976),(977),(978),(979),(980),(981),(982),(983);
/*!40000 ALTER TABLE `Storage_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_person___pi`
--

DROP TABLE IF EXISTS `Storage_person___pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_person___pi` (
  `person` int(11) NOT NULL,
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`person`,`pi`),
  KEY `idx_second_dimension` (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_person___pi`
--

LOCK TABLES `Storage_person___pi` WRITE;
/*!40000 ALTER TABLE `Storage_person___pi` DISABLE KEYS */;
INSERT INTO `Storage_person___pi` VALUES (2,2),(3,3),(4,4),(5,5),(8,8),(10,10),(11,11),(14,14),(24,24),(25,25),(27,27),(35,35),(36,36),(65,2),(69,38),(70,38),(71,24),(72,5),(74,23),(75,75),(76,10),(78,35),(80,25),(82,40),(83,16),(87,36),(92,11),(93,9),(95,17),(96,38),(97,8),(100,29),(101,3),(102,9),(103,8),(104,9),(105,8),(106,17),(108,4),(109,26),(110,9),(111,8),(112,16),(113,34),(115,6),(118,37),(120,41),(128,17),(130,17),(131,17),(639,639),(640,640),(642,17),(645,645),(646,646),(649,649),(651,651),(653,653),(655,655),(657,657),(659,659),(660,660),(661,661),(663,663),(665,665),(666,666),(667,667),(668,668),(669,669),(670,670),(671,671),(672,672),(676,676),(678,678),(680,680),(682,682),(683,683),(684,684),(685,685),(686,686),(690,690),(691,691),(692,692),(694,694),(696,696),(697,697),(698,698),(699,699),(701,701),(703,703),(704,704),(707,707),(708,708),(709,709),(710,710),(711,711),(712,712),(714,714),(717,717),(718,718),(720,720),(722,722),(723,723),(724,724),(725,725),(728,728),(730,730),(732,17),(733,733),(735,735),(736,736),(737,737),(738,738),(739,739),(740,740),(741,741),(743,743),(745,745),(746,746),(747,747),(748,748),(750,750),(751,751),(752,752),(754,754),(755,755),(756,756),(759,759),(761,761),(763,763),(764,764),(765,765),(772,729),(773,648),(774,33),(775,40),(776,33),(777,726),(778,25),(779,652),(780,9),(781,38),(782,17),(783,38),(784,658),(785,5),(786,715),(787,38),(788,131),(789,24),(790,729),(791,38),(792,677),(793,721),(794,29),(795,719),(796,752),(797,17),(798,38),(799,688),(800,731),(801,650),(802,38),(803,765),(804,34),(805,735),(806,640),(807,2),(808,662),(809,679),(810,744),(811,9),(812,639),(813,33),(814,38),(815,5),(816,2),(817,705),(818,29),(819,729),(820,749),(821,9),(822,2),(823,677),(824,681),(825,729),(826,9),(827,12),(828,729),(829,662),(830,25),(831,29),(832,727),(833,744),(834,9),(835,25),(836,729),(837,40),(838,744),(839,2),(840,726),(841,749),(842,687),(843,675),(844,25),(845,17),(846,17),(847,706),(848,4),(849,27),(850,716),(851,37),(852,695),(853,11),(854,24),(855,758),(856,650),(857,717),(858,700),(859,28),(860,9),(861,38),(862,717),(863,729),(864,5),(865,35),(866,29),(867,650),(868,732),(869,11),(870,8),(871,662),(872,17),(873,647),(874,29),(875,746),(876,675),(877,762),(878,6),(879,752),(880,39),(881,650),(882,692),(883,727),(884,38),(885,663),(886,726),(887,16),(888,713),(889,9),(890,648),(891,639),(892,9),(893,752),(894,729),(895,38),(896,9),(897,38),(898,25),(899,752),(900,735),(901,700),(902,689),(903,9),(904,28),(905,729),(906,23),(907,25),(908,31),(909,8),(910,10),(911,26),(912,716),(913,8),(914,40),(915,29),(916,25),(917,8),(918,9),(919,726),(920,753),(921,677),(922,25),(923,729),(924,25),(925,38),(926,40),(927,693),(928,40),(929,17),(930,747),(931,664),(932,38),(933,757),(934,664),(935,742),(936,17),(937,38),(938,31),(939,729),(940,2),(941,744),(942,727),(943,5),(944,29),(945,17),(946,13),(947,734),(948,40),(949,648),(950,29),(951,654),(952,6),(953,702),(954,40),(955,25),(956,33),(957,760),(958,735),(959,744),(960,673),(961,29),(962,8),(963,727),(964,731),(965,40),(966,38),(967,742),(968,753),(969,38),(970,746),(971,687),(972,735),(973,662),(974,33),(975,687),(976,742),(977,674),(978,2),(979,717),(980,677),(981,656),(982,38),(983,716);
/*!40000 ALTER TABLE `Storage_person___pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_person___resource`
--

DROP TABLE IF EXISTS `Storage_person___resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_person___resource` (
  `person` int(11) NOT NULL,
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`person`,`resource`),
  KEY `idx_second_dimension` (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_person___resource`
--

LOCK TABLES `Storage_person___resource` WRITE;
/*!40000 ALTER TABLE `Storage_person___resource` DISABLE KEYS */;
INSERT INTO `Storage_person___resource` VALUES (2,6),(2,7),(3,7),(4,7),(5,7),(8,7),(10,7),(11,6),(11,7),(14,7),(24,7),(25,6),(25,7),(27,6),(35,7),(36,6),(65,7),(69,7),(70,7),(71,7),(72,7),(74,7),(75,7),(76,7),(78,7),(80,7),(82,7),(83,7),(87,7),(92,7),(93,7),(95,7),(96,7),(97,7),(100,7),(101,7),(102,7),(103,7),(104,7),(105,7),(106,6),(106,7),(108,7),(109,7),(110,7),(111,7),(112,7),(113,7),(115,7),(118,7),(120,7),(128,7),(130,7),(131,6),(131,7),(639,6),(639,7),(640,6),(642,6),(642,7),(645,7),(646,7),(649,7),(651,7),(653,7),(655,7),(657,7),(659,7),(660,7),(661,7),(663,7),(665,7),(666,7),(667,7),(668,7),(669,7),(670,7),(671,7),(672,7),(676,7),(678,7),(680,7),(682,7),(683,7),(684,7),(685,7),(686,7),(690,7),(691,7),(692,7),(694,7),(696,7),(697,7),(698,7),(699,7),(701,7),(703,7),(704,7),(707,7),(708,7),(709,7),(710,7),(711,7),(712,7),(714,7),(717,7),(718,7),(720,7),(722,7),(723,7),(724,7),(725,7),(728,7),(730,7),(732,7),(733,7),(735,7),(736,7),(737,7),(738,7),(739,7),(740,7),(741,7),(743,7),(745,7),(746,7),(747,7),(748,7),(750,7),(751,7),(752,7),(754,7),(755,7),(756,7),(759,7),(761,7),(763,7),(764,7),(765,7),(772,7),(773,7),(774,7),(775,7),(776,7),(777,7),(778,7),(779,7),(780,7),(781,7),(782,7),(783,7),(784,7),(785,7),(786,7),(787,7),(788,7),(789,7),(790,7),(791,7),(792,7),(793,7),(794,7),(795,7),(796,7),(797,7),(798,7),(799,7),(800,7),(801,7),(802,7),(803,7),(804,7),(805,7),(806,7),(807,7),(808,7),(809,7),(810,7),(811,7),(812,7),(813,7),(814,7),(815,7),(816,7),(817,7),(818,7),(819,7),(820,7),(821,7),(822,7),(823,7),(824,7),(825,7),(826,7),(827,7),(828,7),(829,7),(830,7),(831,7),(832,7),(833,7),(834,7),(835,7),(836,7),(837,7),(838,7),(839,7),(840,7),(841,7),(842,7),(843,7),(844,7),(845,7),(846,7),(847,7),(848,7),(849,7),(850,7),(851,7),(852,7),(853,7),(854,7),(855,7),(856,7),(857,7),(858,7),(859,7),(860,7),(861,7),(862,7),(863,7),(864,7),(865,7),(866,7),(867,7),(868,7),(869,7),(870,7),(871,7),(872,7),(873,7),(874,7),(875,7),(876,7),(877,7),(878,7),(879,7),(880,7),(881,7),(882,7),(883,7),(884,7),(885,7),(886,7),(887,7),(888,7),(889,7),(890,7),(891,7),(892,7),(893,7),(894,7),(895,7),(896,7),(897,7),(898,7),(899,7),(900,7),(901,7),(902,7),(903,7),(904,7),(905,7),(906,7),(907,7),(908,7),(909,7),(910,7),(911,7),(912,7),(913,7),(914,7),(915,7),(916,7),(917,7),(918,7),(919,7),(920,7),(921,7),(922,7),(923,7),(924,7),(925,7),(926,7),(927,7),(928,7),(929,7),(930,7),(931,7),(932,7),(933,7),(934,7),(935,7),(936,7),(937,7),(938,7),(939,7),(940,7),(941,7),(942,7),(943,7),(944,7),(945,7),(946,7),(947,7),(948,7),(949,7),(950,7),(951,7),(952,7),(953,7),(954,7),(955,7),(956,7),(957,7),(958,7),(959,7),(960,7),(961,7),(962,7),(963,7),(964,7),(965,7),(966,7),(967,7),(968,7),(969,7),(970,7),(971,7),(972,7),(973,7),(974,7),(975,7),(976,7),(977,7),(978,7),(979,7),(980,7),(981,7),(982,7),(983,7);
/*!40000 ALTER TABLE `Storage_person___resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_person___resource_type`
--

DROP TABLE IF EXISTS `Storage_person___resource_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_person___resource_type` (
  `person` int(11) NOT NULL,
  `resource_type` int(11) NOT NULL,
  PRIMARY KEY (`person`,`resource_type`),
  KEY `idx_second_dimension` (`resource_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_person___resource_type`
--

LOCK TABLES `Storage_person___resource_type` WRITE;
/*!40000 ALTER TABLE `Storage_person___resource_type` DISABLE KEYS */;
INSERT INTO `Storage_person___resource_type` VALUES (2,8),(2,10),(3,10),(4,10),(5,10),(8,10),(10,10),(11,8),(11,10),(14,10),(24,10),(25,8),(25,10),(27,8),(35,10),(36,8),(65,10),(69,10),(70,10),(71,10),(72,10),(74,10),(75,10),(76,10),(78,10),(80,10),(82,10),(83,10),(87,10),(92,10),(93,10),(95,10),(96,10),(97,10),(100,10),(101,10),(102,10),(103,10),(104,10),(105,10),(106,8),(106,10),(108,10),(109,10),(110,10),(111,10),(112,10),(113,10),(115,10),(118,10),(120,10),(128,10),(130,10),(131,8),(131,10),(639,8),(639,10),(640,8),(642,8),(642,10),(645,10),(646,10),(649,10),(651,10),(653,10),(655,10),(657,10),(659,10),(660,10),(661,10),(663,10),(665,10),(666,10),(667,10),(668,10),(669,10),(670,10),(671,10),(672,10),(676,10),(678,10),(680,10),(682,10),(683,10),(684,10),(685,10),(686,10),(690,10),(691,10),(692,10),(694,10),(696,10),(697,10),(698,10),(699,10),(701,10),(703,10),(704,10),(707,10),(708,10),(709,10),(710,10),(711,10),(712,10),(714,10),(717,10),(718,10),(720,10),(722,10),(723,10),(724,10),(725,10),(728,10),(730,10),(732,10),(733,10),(735,10),(736,10),(737,10),(738,10),(739,10),(740,10),(741,10),(743,10),(745,10),(746,10),(747,10),(748,10),(750,10),(751,10),(752,10),(754,10),(755,10),(756,10),(759,10),(761,10),(763,10),(764,10),(765,10),(772,10),(773,10),(774,10),(775,10),(776,10),(777,10),(778,10),(779,10),(780,10),(781,10),(782,10),(783,10),(784,10),(785,10),(786,10),(787,10),(788,10),(789,10),(790,10),(791,10),(792,10),(793,10),(794,10),(795,10),(796,10),(797,10),(798,10),(799,10),(800,10),(801,10),(802,10),(803,10),(804,10),(805,10),(806,10),(807,10),(808,10),(809,10),(810,10),(811,10),(812,10),(813,10),(814,10),(815,10),(816,10),(817,10),(818,10),(819,10),(820,10),(821,10),(822,10),(823,10),(824,10),(825,10),(826,10),(827,10),(828,10),(829,10),(830,10),(831,10),(832,10),(833,10),(834,10),(835,10),(836,10),(837,10),(838,10),(839,10),(840,10),(841,10),(842,10),(843,10),(844,10),(845,10),(846,10),(847,10),(848,10),(849,10),(850,10),(851,10),(852,10),(853,10),(854,10),(855,10),(856,10),(857,10),(858,10),(859,10),(860,10),(861,10),(862,10),(863,10),(864,10),(865,10),(866,10),(867,10),(868,10),(869,10),(870,10),(871,10),(872,10),(873,10),(874,10),(875,10),(876,10),(877,10),(878,10),(879,10),(880,10),(881,10),(882,10),(883,10),(884,10),(885,10),(886,10),(887,10),(888,10),(889,10),(890,10),(891,10),(892,10),(893,10),(894,10),(895,10),(896,10),(897,10),(898,10),(899,10),(900,10),(901,10),(902,10),(903,10),(904,10),(905,10),(906,10),(907,10),(908,10),(909,10),(910,10),(911,10),(912,10),(913,10),(914,10),(915,10),(916,10),(917,10),(918,10),(919,10),(920,10),(921,10),(922,10),(923,10),(924,10),(925,10),(926,10),(927,10),(928,10),(929,10),(930,10),(931,10),(932,10),(933,10),(934,10),(935,10),(936,10),(937,10),(938,10),(939,10),(940,10),(941,10),(942,10),(943,10),(944,10),(945,10),(946,10),(947,10),(948,10),(949,10),(950,10),(951,10),(952,10),(953,10),(954,10),(955,10),(956,10),(957,10),(958,10),(959,10),(960,10),(961,10),(962,10),(963,10),(964,10),(965,10),(966,10),(967,10),(968,10),(969,10),(970,10),(971,10),(972,10),(973,10),(974,10),(975,10),(976,10),(977,10),(978,10),(979,10),(980,10),(981,10),(982,10),(983,10);
/*!40000 ALTER TABLE `Storage_person___resource_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_person___username`
--

DROP TABLE IF EXISTS `Storage_person___username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_person___username` (
  `person` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`person`,`username`),
  KEY `idx_second_dimension` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_person___username`
--

LOCK TABLES `Storage_person___username` WRITE;
/*!40000 ALTER TABLE `Storage_person___username` DISABLE KEYS */;
INSERT INTO `Storage_person___username` VALUES (2,'aytinis'),(3,'balsh'),(4,'bitte'),(5,'blabi'),(8,'calla'),(10,'cetwa'),(11,'chaff'),(14,'dunli'),(24,'hoowa'),(25,'ibech'),(27,'leske'),(35,'refbl'),(36,'sanma'),(65,'alpsw'),(69,'categ'),(70,'coot1'),(71,'corsh'),(72,'crama'),(74,'duswa'),(75,'egygo'),(76,'evegr'),(78,'garwa'),(80,'grath'),(82,'honbu'),(83,'lanhach'),(87,'litau'),(92,'noror'),(93,'ovenb'),(95,'pibgr'),(96,'proubis'),(97,'reebu'),(100,'rolle'),(101,'sancr'),(102,'sante'),(103,'sarwa'),(104,'savsp'),(105,'shag1'),(106,'shttr'),(108,'sogsh'),(109,'sposa'),(110,'swath'),(111,'turdo'),(112,'velsc'),(113,'vertera'),(115,'whtpl'),(118,'yebbu'),(120,'yebwa'),(128,'yerwa'),(130,'ylwwa'),(131,'setusca'),(639,'magwa'),(640,'norpa'),(642,'camwa'),(645,'amere'),(646,'arcre'),(649,'baisa'),(651,'bawwa'),(653,'belki'),(655,'blate'),(657,'bobol'),(659,'brugu'),(660,'bubsa'),(661,'bullf'),(663,'chisw'),(665,'comni'),(666,'comre'),(667,'comte'),(668,'corbu'),(669,'cucko'),(670,'deswa'),(671,'dumnsis'),(672,'dunno'),(676,'eybth'),(678,'fragu'),(680,'glagu'),(682,'goldf'),(683,'grefi'),(684,'gresn'),(685,'grewo'),(686,'grnwa'),(690,'houma'),(691,'hyllina'),(692,'ictwa'),(694,'kingf'),(696,'lapbu'),(697,'laragus'),(698,'larinii'),(699,'larsp'),(701,'linne'),(703,'lobdo'),(704,'lotti'),(707,'molater'),(708,'musrica'),(709,'nigal'),(710,'nijar'),(711,'norwa'),(712,'olbpi'),(714,'pacsw'),(717,'pinbu'),(718,'pomsk'),(720,'pursa'),(722,'redgr'),(723,'reewa'),(724,'reffa'),(725,'renph'),(728,'rocbu'),(730,'rocth'),(732,'rutro'),(733,'sabgu'),(735,'scaro'),(736,'scoow'),(737,'sheow'),(738,'sitnsis'),(739,'skyla'),(740,'snipe'),(741,'snoow'),(743,'spofl'),(745,'stevida'),(746,'subwa'),(747,'sumta'),(748,'swift'),(750,'tawpi'),(751,'tenwa'),(752,'trepi'),(754,'trufi'),(755,'twite'),(756,'veery'),(759,'whrsa'),(761,'wilph'),(763,'woodc'),(764,'woodp'),(765,'yelwa'),(772,'alete'),(773,'ameke'),(774,'amero'),(775,'aquwa'),(776,'arcte'),(777,'barow'),(778,'beeea'),(779,'bimla'),(780,'blaca'),(781,'blare'),(782,'blcbe'),(783,'blewh'),(784,'blhgu'),(785,'blrth'),(786,'blrwa'),(787,'bltth'),(788,'bluth'),(789,'bluti'),(790,'blwpr'),(791,'blypi'),(792,'bomorum'),(793,'bonwa'),(794,'bramb'),(795,'brardix'),(796,'brite'),(797,'broth'),(798,'carcr'),(799,'casgu'),(800,'chabu'),(801,'choug'),(802,'cirbu'),(803,'citwa'),(804,'clisw'),(805,'coati'),(806,'coldo'),(807,'colfl'),(808,'colpr'),(809,'comgu'),(810,'comsa'),(811,'crcco'),(812,'crebu'),(813,'crela'),(814,'creti'),(815,'cross'),(816,'daeju'),(817,'darwa'),(818,'deswh'),(819,'dippe'),(820,'eaowa'),(821,'egyni'),(822,'embhala'),(823,'falnsis'),(824,'firec'),(825,'forte'),(826,'frahata'),(827,'galcata'),(828,'gbbgu'),(829,'glaarum'),(830,'golor'),(831,'grawa'),(832,'greph'),(833,'gresa'),(834,'gresh'),(835,'gresk'),(836,'greti'),(837,'grewa'),(838,'greye'),(839,'grrwa'),(840,'grscu'),(841,'gshwa'),(842,'guill'),(843,'gyrfa'),(844,'hawfi'),(845,'hawow'),(846,'hiporum'),(847,'hobby'),(848,'hoopo'),(849,'housp'),(850,'hulwa'),(851,'icegu'),(852,'isash'),(853,'isawh'),(854,'ivogu'),(855,'ixovius'),(856,'jacsn'),(857,'jay11'),(858,'kestr'),(859,'kitti'),(860,'lanwa'),(861,'laranus'),(862,'laryane'),(863,'laugu'),(864,'lbbgu'),(865,'leasa'),(866,'lecte'),(867,'leswh'),(868,'lesye'),(869,'litbu'),(870,'litgu'),(871,'litte'),(872,'loeow'),(873,'lotsk'),(874,'lstla'),(875,'magpi'),(876,'marsa'),(877,'marti'),(878,'marwa'),(879,'massh'),(880,'medgu'),(881,'melnsis'),(882,'melwa'),(883,'mimttos'),(884,'moure'),(885,'netsw'),(886,'nutcr'),(887,'pagwa'),(888,'palsa'),(889,'palsw'),(890,'palwa'),(891,'parbu'),(892,'parcr'),(893,'pecpi'),(894,'pecsa'),(895,'penti'),(896,'phivi'),(897,'phyatus'),(898,'piefl'),(899,'piewh'),(900,'pingr'),(901,'pinnnis'),(902,'raven'),(903,'razor'),(904,'rebfl'),(905,'rebsh'),(906,'redsh'),(907,'redst'),(908,'redwi'),(909,'reevi'),(910,'renni'),(911,'rersw'),(912,'ricpi'),(913,'rinou'),(914,'rinpa'),(915,'rivwa'),(916,'robgr'),(917,'robin'),(918,'rocdo'),(919,'rocpi'),(920,'rocsp'),(921,'rook1'),(922,'rosgu'),(923,'roste'),(924,'royte'),(925,'rubro'),(926,'rupwa'),(927,'rusto'),(928,'rutdo'),(929,'sayoebe'),(930,'scata'),(931,'scocr'),(932,'sedwa'),(933,'semsa'),(934,'serin'),(935,'shola'),(936,'shtla'),(937,'sibru'),(938,'sibth'),(939,'slegu'),(940,'snobu'),(941,'solsa'),(942,'sonth'),(943,'soote'),(944,'spasp'),(945,'spewa'),(946,'starl'),(947,'stoch'),(948,'stodo'),(949,'swall'),(950,'sylnsis'),(951,'synquus'),(952,'tacolor'),(953,'tawow'),(954,'tenow'),(955,'tersa'),(956,'thbwa'),(957,'thrni'),(958,'treec'),(959,'triipes'),(960,'turanni'),(961,'twbcr'),(962,'virrons'),(963,'wallc'),(964,'watpi'),(965,'waxwi'),(966,'whcbl'),(967,'whcsp'),(968,'wheat'),(969,'whinc'),(970,'white'),(971,'whkte'),(972,'whwla'),(973,'wilwa'),(974,'woodl'),(975,'woosa'),(976,'woosh'),(977,'woowa'),(978,'wren1'),(979,'wryne'),(980,'wwbte'),(981,'yebcu'),(982,'yelha'),(983,'zenoura');
/*!40000 ALTER TABLE `Storage_person___username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_pi`
--

DROP TABLE IF EXISTS `Storage_pi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_pi` (
  `pi` int(11) NOT NULL,
  PRIMARY KEY (`pi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_pi`
--

LOCK TABLES `Storage_pi` WRITE;
/*!40000 ALTER TABLE `Storage_pi` DISABLE KEYS */;
INSERT INTO `Storage_pi` VALUES (2),(3),(4),(5),(6),(8),(9),(10),(11),(12),(13),(14),(16),(17),(23),(24),(25),(26),(27),(28),(29),(31),(33),(34),(35),(36),(37),(38),(39),(40),(41),(75),(131),(639),(640),(645),(646),(647),(648),(649),(650),(651),(652),(653),(654),(655),(656),(657),(658),(659),(660),(661),(662),(663),(664),(665),(666),(667),(668),(669),(670),(671),(672),(673),(674),(675),(676),(677),(678),(679),(680),(681),(682),(683),(684),(685),(686),(687),(688),(689),(690),(691),(692),(693),(694),(695),(696),(697),(698),(699),(700),(701),(702),(703),(704),(705),(706),(707),(708),(709),(710),(711),(712),(713),(714),(715),(716),(717),(718),(719),(720),(721),(722),(723),(724),(725),(726),(727),(728),(729),(730),(731),(732),(733),(734),(735),(736),(737),(738),(739),(740),(741),(742),(743),(744),(745),(746),(747),(748),(749),(750),(751),(752),(753),(754),(755),(756),(757),(758),(759),(760),(761),(762),(763),(764),(765);
/*!40000 ALTER TABLE `Storage_pi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_pi___resource`
--

DROP TABLE IF EXISTS `Storage_pi___resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_pi___resource` (
  `pi` int(11) NOT NULL,
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`pi`,`resource`),
  KEY `idx_second_dimension` (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_pi___resource`
--

LOCK TABLES `Storage_pi___resource` WRITE;
/*!40000 ALTER TABLE `Storage_pi___resource` DISABLE KEYS */;
INSERT INTO `Storage_pi___resource` VALUES (2,6),(2,7),(3,7),(4,7),(5,7),(6,7),(8,7),(9,7),(10,7),(11,6),(11,7),(12,7),(13,7),(14,7),(16,7),(17,6),(17,7),(23,7),(24,7),(25,6),(25,7),(26,7),(27,6),(27,7),(28,7),(29,7),(31,7),(33,7),(34,7),(35,7),(36,6),(36,7),(37,7),(38,7),(39,7),(40,7),(41,7),(75,7),(131,7),(639,6),(639,7),(640,6),(640,7),(645,7),(646,7),(647,7),(648,7),(649,7),(650,7),(651,7),(652,7),(653,7),(654,7),(655,7),(656,7),(657,7),(658,7),(659,7),(660,7),(661,7),(662,7),(663,7),(664,7),(665,7),(666,7),(667,7),(668,7),(669,7),(670,7),(671,7),(672,7),(673,7),(674,7),(675,7),(676,7),(677,7),(678,7),(679,7),(680,7),(681,7),(682,7),(683,7),(684,7),(685,7),(686,7),(687,7),(688,7),(689,7),(690,7),(691,7),(692,7),(693,7),(694,7),(695,7),(696,7),(697,7),(698,7),(699,7),(700,7),(701,7),(702,7),(703,7),(704,7),(705,7),(706,7),(707,7),(708,7),(709,7),(710,7),(711,7),(712,7),(713,7),(714,7),(715,7),(716,7),(717,7),(718,7),(719,7),(720,7),(721,7),(722,7),(723,7),(724,7),(725,7),(726,7),(727,7),(728,7),(729,7),(730,7),(731,7),(732,7),(733,7),(734,7),(735,7),(736,7),(737,7),(738,7),(739,7),(740,7),(741,7),(742,7),(743,7),(744,7),(745,7),(746,7),(747,7),(748,7),(749,7),(750,7),(751,7),(752,7),(753,7),(754,7),(755,7),(756,7),(757,7),(758,7),(759,7),(760,7),(761,7),(762,7),(763,7),(764,7),(765,7);
/*!40000 ALTER TABLE `Storage_pi___resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_pi___resource_type`
--

DROP TABLE IF EXISTS `Storage_pi___resource_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_pi___resource_type` (
  `pi` int(11) NOT NULL,
  `resource_type` int(11) NOT NULL,
  PRIMARY KEY (`pi`,`resource_type`),
  KEY `idx_second_dimension` (`resource_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_pi___resource_type`
--

LOCK TABLES `Storage_pi___resource_type` WRITE;
/*!40000 ALTER TABLE `Storage_pi___resource_type` DISABLE KEYS */;
INSERT INTO `Storage_pi___resource_type` VALUES (2,8),(2,10),(3,10),(4,10),(5,10),(6,10),(8,10),(9,10),(10,10),(11,8),(11,10),(12,10),(13,10),(14,10),(16,10),(17,8),(17,10),(23,10),(24,10),(25,8),(25,10),(26,10),(27,8),(27,10),(28,10),(29,10),(31,10),(33,10),(34,10),(35,10),(36,8),(36,10),(37,10),(38,10),(39,10),(40,10),(41,10),(75,10),(131,10),(639,8),(639,10),(640,8),(640,10),(645,10),(646,10),(647,10),(648,10),(649,10),(650,10),(651,10),(652,10),(653,10),(654,10),(655,10),(656,10),(657,10),(658,10),(659,10),(660,10),(661,10),(662,10),(663,10),(664,10),(665,10),(666,10),(667,10),(668,10),(669,10),(670,10),(671,10),(672,10),(673,10),(674,10),(675,10),(676,10),(677,10),(678,10),(679,10),(680,10),(681,10),(682,10),(683,10),(684,10),(685,10),(686,10),(687,10),(688,10),(689,10),(690,10),(691,10),(692,10),(693,10),(694,10),(695,10),(696,10),(697,10),(698,10),(699,10),(700,10),(701,10),(702,10),(703,10),(704,10),(705,10),(706,10),(707,10),(708,10),(709,10),(710,10),(711,10),(712,10),(713,10),(714,10),(715,10),(716,10),(717,10),(718,10),(719,10),(720,10),(721,10),(722,10),(723,10),(724,10),(725,10),(726,10),(727,10),(728,10),(729,10),(730,10),(731,10),(732,10),(733,10),(734,10),(735,10),(736,10),(737,10),(738,10),(739,10),(740,10),(741,10),(742,10),(743,10),(744,10),(745,10),(746,10),(747,10),(748,10),(749,10),(750,10),(751,10),(752,10),(753,10),(754,10),(755,10),(756,10),(757,10),(758,10),(759,10),(760,10),(761,10),(762,10),(763,10),(764,10),(765,10);
/*!40000 ALTER TABLE `Storage_pi___resource_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_pi___username`
--

DROP TABLE IF EXISTS `Storage_pi___username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_pi___username` (
  `pi` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`pi`,`username`),
  KEY `idx_second_dimension` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_pi___username`
--

LOCK TABLES `Storage_pi___username` WRITE;
/*!40000 ALTER TABLE `Storage_pi___username` DISABLE KEYS */;
INSERT INTO `Storage_pi___username` VALUES (2,'alpsw'),(2,'aytinis'),(2,'colfl'),(2,'daeju'),(2,'embhala'),(2,'grrwa'),(2,'snobu'),(2,'wren1'),(3,'balsh'),(3,'sancr'),(4,'bitte'),(4,'hoopo'),(4,'sogsh'),(5,'blabi'),(5,'blrth'),(5,'crama'),(5,'cross'),(5,'lbbgu'),(5,'soote'),(6,'marwa'),(6,'tacolor'),(6,'whtpl'),(8,'calla'),(8,'litgu'),(8,'reebu'),(8,'reevi'),(8,'rinou'),(8,'robin'),(8,'sarwa'),(8,'shag1'),(8,'turdo'),(8,'virrons'),(9,'blaca'),(9,'crcco'),(9,'egyni'),(9,'frahata'),(9,'gresh'),(9,'lanwa'),(9,'ovenb'),(9,'palsw'),(9,'parcr'),(9,'phivi'),(9,'razor'),(9,'rocdo'),(9,'sante'),(9,'savsp'),(9,'swath'),(10,'cetwa'),(10,'evegr'),(10,'renni'),(11,'chaff'),(11,'isawh'),(11,'litbu'),(11,'noror'),(12,'galcata'),(13,'starl'),(14,'dunli'),(16,'lanhach'),(16,'pagwa'),(16,'velsc'),(17,'blcbe'),(17,'broth'),(17,'camwa'),(17,'hawow'),(17,'hiporum'),(17,'loeow'),(17,'pibgr'),(17,'rutro'),(17,'sayoebe'),(17,'setusca'),(17,'shtla'),(17,'shttr'),(17,'spewa'),(17,'yerwa'),(17,'ylwwa'),(23,'duswa'),(23,'redsh'),(24,'bluti'),(24,'corsh'),(24,'hoowa'),(24,'ivogu'),(25,'beeea'),(25,'golor'),(25,'grath'),(25,'gresk'),(25,'hawfi'),(25,'ibech'),(25,'piefl'),(25,'redst'),(25,'robgr'),(25,'rosgu'),(25,'royte'),(25,'tersa'),(26,'rersw'),(26,'sposa'),(27,'housp'),(27,'leske'),(28,'kitti'),(28,'rebfl'),(29,'bramb'),(29,'deswh'),(29,'grawa'),(29,'lecte'),(29,'lstla'),(29,'rivwa'),(29,'rolle'),(29,'spasp'),(29,'sylnsis'),(29,'twbcr'),(31,'redwi'),(31,'sibth'),(33,'amero'),(33,'arcte'),(33,'crela'),(33,'thbwa'),(33,'woodl'),(34,'clisw'),(34,'vertera'),(35,'garwa'),(35,'leasa'),(35,'refbl'),(36,'litau'),(36,'sanma'),(37,'icegu'),(37,'yebbu'),(38,'blare'),(38,'blewh'),(38,'bltth'),(38,'blypi'),(38,'carcr'),(38,'categ'),(38,'cirbu'),(38,'coot1'),(38,'creti'),(38,'laranus'),(38,'moure'),(38,'penti'),(38,'phyatus'),(38,'proubis'),(38,'rubro'),(38,'sedwa'),(38,'sibru'),(38,'whcbl'),(38,'whinc'),(38,'yelha'),(39,'medgu'),(40,'aquwa'),(40,'grewa'),(40,'honbu'),(40,'rinpa'),(40,'rupwa'),(40,'rutdo'),(40,'stodo'),(40,'tenow'),(40,'waxwi'),(41,'yebwa'),(75,'egygo'),(131,'bluth'),(639,'crebu'),(639,'magwa'),(639,'parbu'),(640,'coldo'),(640,'norpa'),(645,'amere'),(646,'arcre'),(647,'lotsk'),(648,'ameke'),(648,'palwa'),(648,'swall'),(649,'baisa'),(650,'choug'),(650,'jacsn'),(650,'leswh'),(650,'melnsis'),(651,'bawwa'),(652,'bimla'),(653,'belki'),(654,'synquus'),(655,'blate'),(656,'yebcu'),(657,'bobol'),(658,'blhgu'),(659,'brugu'),(660,'bubsa'),(661,'bullf'),(662,'colpr'),(662,'glaarum'),(662,'litte'),(662,'wilwa'),(663,'chisw'),(663,'netsw'),(664,'scocr'),(664,'serin'),(665,'comni'),(666,'comre'),(667,'comte'),(668,'corbu'),(669,'cucko'),(670,'deswa'),(671,'dumnsis'),(672,'dunno'),(673,'turanni'),(674,'woowa'),(675,'gyrfa'),(675,'marsa'),(676,'eybth'),(677,'bomorum'),(677,'falnsis'),(677,'rook1'),(677,'wwbte'),(678,'fragu'),(679,'comgu'),(680,'glagu'),(681,'firec'),(682,'goldf'),(683,'grefi'),(684,'gresn'),(685,'grewo'),(686,'grnwa'),(687,'guill'),(687,'whkte'),(687,'woosa'),(688,'casgu'),(689,'raven'),(690,'houma'),(691,'hyllina'),(692,'ictwa'),(692,'melwa'),(693,'rusto'),(694,'kingf'),(695,'isash'),(696,'lapbu'),(697,'laragus'),(698,'larinii'),(699,'larsp'),(700,'kestr'),(700,'pinnnis'),(701,'linne'),(702,'tawow'),(703,'lobdo'),(704,'lotti'),(705,'darwa'),(706,'hobby'),(707,'molater'),(708,'musrica'),(709,'nigal'),(710,'nijar'),(711,'norwa'),(712,'olbpi'),(713,'palsa'),(714,'pacsw'),(715,'blrwa'),(716,'hulwa'),(716,'ricpi'),(716,'zenoura'),(717,'jay11'),(717,'laryane'),(717,'pinbu'),(717,'wryne'),(718,'pomsk'),(719,'brardix'),(720,'pursa'),(721,'bonwa'),(722,'redgr'),(723,'reewa'),(724,'reffa'),(725,'renph'),(726,'barow'),(726,'grscu'),(726,'nutcr'),(726,'rocpi'),(727,'greph'),(727,'mimttos'),(727,'sonth'),(727,'wallc'),(728,'rocbu'),(729,'alete'),(729,'blwpr'),(729,'dippe'),(729,'forte'),(729,'gbbgu'),(729,'greti'),(729,'laugu'),(729,'pecsa'),(729,'rebsh'),(729,'roste'),(729,'slegu'),(730,'rocth'),(731,'chabu'),(731,'watpi'),(732,'lesye'),(733,'sabgu'),(734,'stoch'),(735,'coati'),(735,'pingr'),(735,'scaro'),(735,'treec'),(735,'whwla'),(736,'scoow'),(737,'sheow'),(738,'sitnsis'),(739,'skyla'),(740,'snipe'),(741,'snoow'),(742,'shola'),(742,'whcsp'),(742,'woosh'),(743,'spofl'),(744,'comsa'),(744,'gresa'),(744,'greye'),(744,'solsa'),(744,'triipes'),(745,'stevida'),(746,'magpi'),(746,'subwa'),(746,'white'),(747,'scata'),(747,'sumta'),(748,'swift'),(749,'eaowa'),(749,'gshwa'),(750,'tawpi'),(751,'tenwa'),(752,'brite'),(752,'massh'),(752,'pecpi'),(752,'piewh'),(752,'trepi'),(753,'rocsp'),(753,'wheat'),(754,'trufi'),(755,'twite'),(756,'veery'),(757,'semsa'),(758,'ixovius'),(759,'whrsa'),(760,'thrni'),(761,'wilph'),(762,'marti'),(763,'woodc'),(764,'woodp'),(765,'citwa'),(765,'yelwa');
/*!40000 ALTER TABLE `Storage_pi___username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_resource`
--

DROP TABLE IF EXISTS `Storage_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_resource` (
  `resource` int(11) NOT NULL,
  PRIMARY KEY (`resource`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_resource`
--

LOCK TABLES `Storage_resource` WRITE;
/*!40000 ALTER TABLE `Storage_resource` DISABLE KEYS */;
INSERT INTO `Storage_resource` VALUES (6),(7);
/*!40000 ALTER TABLE `Storage_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_resource_type`
--

DROP TABLE IF EXISTS `Storage_resource_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_resource_type` (
  `resource_type` int(11) NOT NULL,
  PRIMARY KEY (`resource_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_resource_type`
--

LOCK TABLES `Storage_resource_type` WRITE;
/*!40000 ALTER TABLE `Storage_resource_type` DISABLE KEYS */;
INSERT INTO `Storage_resource_type` VALUES (8),(10);
/*!40000 ALTER TABLE `Storage_resource_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Storage_username`
--

DROP TABLE IF EXISTS `Storage_username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Storage_username` (
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Storage_username`
--

LOCK TABLES `Storage_username` WRITE;
/*!40000 ALTER TABLE `Storage_username` DISABLE KEYS */;
INSERT INTO `Storage_username` VALUES ('alete'),('alpsw'),('ameke'),('amere'),('amero'),('aquwa'),('arcre'),('arcte'),('aytinis'),('baisa'),('balsh'),('barow'),('bawwa'),('beeea'),('belki'),('bimla'),('bitte'),('blabi'),('blaca'),('blare'),('blate'),('blcbe'),('blewh'),('blhgu'),('blrth'),('blrwa'),('bltth'),('bluth'),('bluti'),('blwpr'),('blypi'),('bobol'),('bomorum'),('bonwa'),('bramb'),('brardix'),('brite'),('broth'),('brugu'),('bubsa'),('bullf'),('calla'),('camwa'),('carcr'),('casgu'),('categ'),('cetwa'),('chabu'),('chaff'),('chisw'),('choug'),('cirbu'),('citwa'),('clisw'),('coati'),('coldo'),('colfl'),('colpr'),('comgu'),('comni'),('comre'),('comsa'),('comte'),('coot1'),('corbu'),('corsh'),('crama'),('crcco'),('crebu'),('crela'),('creti'),('cross'),('cucko'),('daeju'),('darwa'),('deswa'),('deswh'),('dippe'),('dumnsis'),('dunli'),('dunno'),('duswa'),('eaowa'),('egygo'),('egyni'),('embhala'),('evegr'),('eybth'),('falnsis'),('firec'),('forte'),('fragu'),('frahata'),('galcata'),('garwa'),('gbbgu'),('glaarum'),('glagu'),('goldf'),('golor'),('grath'),('grawa'),('grefi'),('greph'),('gresa'),('gresh'),('gresk'),('gresn'),('greti'),('grewa'),('grewo'),('greye'),('grnwa'),('grrwa'),('grscu'),('gshwa'),('guill'),('gyrfa'),('hawfi'),('hawow'),('hiporum'),('hobby'),('honbu'),('hoopo'),('hoowa'),('houma'),('housp'),('hulwa'),('hyllina'),('ibech'),('icegu'),('ictwa'),('isash'),('isawh'),('ivogu'),('ixovius'),('jacsn'),('jay11'),('kestr'),('kingf'),('kitti'),('lanhach'),('lanwa'),('lapbu'),('laragus'),('laranus'),('larinii'),('larsp'),('laryane'),('laugu'),('lbbgu'),('leasa'),('lecte'),('leske'),('leswh'),('lesye'),('linne'),('litau'),('litbu'),('litgu'),('litte'),('lobdo'),('loeow'),('lotsk'),('lotti'),('lstla'),('magpi'),('magwa'),('marsa'),('marti'),('marwa'),('massh'),('medgu'),('melnsis'),('melwa'),('mimttos'),('molater'),('moure'),('musrica'),('netsw'),('nigal'),('nijar'),('noror'),('norpa'),('norwa'),('nutcr'),('olbpi'),('ovenb'),('pacsw'),('pagwa'),('palsa'),('palsw'),('palwa'),('parbu'),('parcr'),('pecpi'),('pecsa'),('penti'),('phivi'),('phyatus'),('pibgr'),('piefl'),('piewh'),('pinbu'),('pingr'),('pinnnis'),('pomsk'),('proubis'),('pursa'),('raven'),('razor'),('rebfl'),('rebsh'),('redgr'),('redsh'),('redst'),('redwi'),('reebu'),('reevi'),('reewa'),('refbl'),('reffa'),('renni'),('renph'),('rersw'),('ricpi'),('rinou'),('rinpa'),('rivwa'),('robgr'),('robin'),('rocbu'),('rocdo'),('rocpi'),('rocsp'),('rocth'),('rolle'),('rook1'),('rosgu'),('roste'),('royte'),('rubro'),('rupwa'),('rusto'),('rutdo'),('rutro'),('sabgu'),('sancr'),('sanma'),('sante'),('sarwa'),('savsp'),('sayoebe'),('scaro'),('scata'),('scocr'),('scoow'),('sedwa'),('semsa'),('serin'),('setusca'),('shag1'),('sheow'),('shola'),('shtla'),('shttr'),('sibru'),('sibth'),('sitnsis'),('skyla'),('slegu'),('snipe'),('snobu'),('snoow'),('sogsh'),('solsa'),('sonth'),('soote'),('spasp'),('spewa'),('spofl'),('sposa'),('starl'),('stevida'),('stoch'),('stodo'),('subwa'),('sumta'),('swall'),('swath'),('swift'),('sylnsis'),('synquus'),('tacolor'),('tawow'),('tawpi'),('tenow'),('tenwa'),('tersa'),('thbwa'),('thrni'),('treec'),('trepi'),('triipes'),('trufi'),('turanni'),('turdo'),('twbcr'),('twite'),('veery'),('velsc'),('vertera'),('virrons'),('wallc'),('watpi'),('waxwi'),('whcbl'),('whcsp'),('wheat'),('whinc'),('white'),('whkte'),('whrsa'),('whtpl'),('whwla'),('wilph'),('wilwa'),('woodc'),('woodl'),('woodp'),('woosa'),('woosh'),('woowa'),('wren1'),('wryne'),('wwbte'),('yebbu'),('yebcu'),('yebwa'),('yelha'),('yelwa'),('yerwa'),('ylwwa'),('zenoura');
/*!40000 ALTER TABLE `Storage_username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'modw_filters'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-15 15:38:53
