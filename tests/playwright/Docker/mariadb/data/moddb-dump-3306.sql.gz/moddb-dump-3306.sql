-- MySQL dump 10.19  Distrib 10.3.35-MariaDB, for Linux (aarch64)
--
-- Host: localhost    Database: moddb
-- ------------------------------------------------------
-- Server version	10.3.35-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `moddb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `moddb` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `moddb`;

--
-- Table structure for table `APIKeys`
--

DROP TABLE IF EXISTS `APIKeys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `APIKeys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_key` varchar(16) DEFAULT NULL,
  `public_key` text DEFAULT NULL,
  `identifier` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `APIKeys`
--

LOCK TABLES `APIKeys` WRITE;
/*!40000 ALTER TABLE `APIKeys` DISABLE KEYS */;
/*!40000 ALTER TABLE `APIKeys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AccountRequests`
--

DROP TABLE IF EXISTS `AccountRequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AccountRequests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text DEFAULT NULL,
  `last_name` text DEFAULT NULL,
  `organization` text DEFAULT NULL,
  `title` text DEFAULT NULL,
  `email_address` text DEFAULT NULL,
  `field_of_science` text DEFAULT NULL,
  `additional_information` text DEFAULT NULL,
  `time_submitted` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(100) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AccountRequests`
--

LOCK TABLES `AccountRequests` WRITE;
/*!40000 ALTER TABLE `AccountRequests` DISABLE KEYS */;
/*!40000 ALTER TABLE `AccountRequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChartPool`
--

DROP TABLE IF EXISTS `ChartPool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ChartPool` (
  `user_id` int(11) DEFAULT NULL,
  `chart_id` text DEFAULT NULL,
  `insertion_rank` int(11) NOT NULL AUTO_INCREMENT,
  `chart_title` text DEFAULT NULL,
  `chart_drill_details` text NOT NULL,
  `chart_date_description` text DEFAULT NULL,
  `type` enum('image','datasheet') DEFAULT NULL,
  `active_role` varchar(30) DEFAULT NULL,
  `image_data` longblob DEFAULT NULL,
  PRIMARY KEY (`insertion_rank`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChartPool`
--

LOCK TABLES `ChartPool` WRITE;
/*!40000 ALTER TABLE `ChartPool` DISABLE KEYS */;
/*!40000 ALTER TABLE `ChartPool` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Colors`
--

DROP TABLE IF EXISTS `Colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Colors` (
  `color` char(8) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`color`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Colors`
--

LOCK TABLES `Colors` WRITE;
/*!40000 ALTER TABLE `Colors` DISABLE KEYS */;
INSERT INTO `Colors` VALUES ('0x00CCFF','',-7),('0x1199FF','blueish',4),('0x339966','green',-187),('0x33abab','',-2),('0x33FF33','green',-200),('0x3aaaaa','green',-192),('0x4e665D','',2),('0x6666FF','purple',-199),('0x669999','ligh blue',-189),('0x66FF00','',-1),('0x69bbed','blue',-400),('0x789abc','',-5),('0x8D4DFF','purple',-10),('0x990099','purple',-186),('0x993333','red-brown',-188),('0x999900','yellow-green',-191),('0x9999FF','',-184),('0x99abab','powder blue',-196),('0x99FF99','',-185),('0xA57E81','',-9),('0xa88d95','yellow',-4),('0xab6565','organish-pink',-193),('0xab8722','yellowish-creamish',-195),('0xCC3300','orange',-190),('0xCC6600','',-183),('0xCC99FF','',-182),('0xDB4230','NULL',3),('0xF4A221','',1),('0xFF6666','',-181),('0xFF66FF','pinkish-purple',-197),('0xFF9966','orange',-185),('0xFF99CC','',-6),('0xFFBC71','',-8);
/*!40000 ALTER TABLE `Colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ExceptionEmailAddresses`
--

DROP TABLE IF EXISTS `ExceptionEmailAddresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ExceptionEmailAddresses` (
  `email_address` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ExceptionEmailAddresses`
--

LOCK TABLES `ExceptionEmailAddresses` WRITE;
/*!40000 ALTER TABLE `ExceptionEmailAddresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ExceptionEmailAddresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESTx509`
--

DROP TABLE IF EXISTS `RESTx509`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RESTx509` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `distinguished_name` text DEFAULT NULL,
  `api_key` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `time_cert_signed` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESTx509`
--

LOCK TABLES `RESTx509` WRITE;
/*!40000 ALTER TABLE `RESTx509` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESTx509` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReportCharts`
--

DROP TABLE IF EXISTS `ReportCharts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReportCharts` (
  `report_id` varchar(100) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `chart_type` text DEFAULT NULL,
  `type` enum('image','datasheet') DEFAULT NULL,
  `selected` tinyint(1) DEFAULT 0,
  `chart_id` text DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT 0,
  `chart_date_description` text DEFAULT NULL,
  `chart_title` varchar(100) DEFAULT NULL,
  `chart_drill_details` text NOT NULL,
  `timeframe_type` text DEFAULT NULL,
  `image_data` longblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReportCharts`
--

LOCK TABLES `ReportCharts` WRITE;
/*!40000 ALTER TABLE `ReportCharts` DISABLE KEYS */;
/*!40000 ALTER TABLE `ReportCharts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReportTemplateCharts`
--

DROP TABLE IF EXISTS `ReportTemplateCharts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReportTemplateCharts` (
  `template_id` int(11) NOT NULL,
  `chart_id` text DEFAULT NULL,
  `ordering` int(11) NOT NULL,
  `chart_date_description` text DEFAULT NULL,
  `chart_title` varchar(100) DEFAULT NULL,
  `chart_drill_details` text DEFAULT NULL,
  `timeframe_type` text DEFAULT NULL,
  UNIQUE KEY `unique` (`template_id`,`ordering`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReportTemplateCharts`
--

LOCK TABLES `ReportTemplateCharts` WRITE;
/*!40000 ALTER TABLE `ReportTemplateCharts` DISABLE KEYS */;
INSERT INTO `ReportTemplateCharts` VALUES (1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.7563606980721138%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22Jobs%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.8709841114161849%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=10&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Previous quarter&timeseries=y&title=PREVIOUS+QUARTER%3A+Total+CPU+Hours+and+Jobs&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',1,'2017-01-01 to 2017-03-31','PREVIOUS QUARTER: Total CPU Hours and Jobs','','Previous quarter'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.7563606980721138%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22Jobs%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.8709841114161849%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-05-19&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=10&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Year to date&timeseries=y&title=YEAR+TO+DATE%3A+Total+CPU+Hours+and+Jobs&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',2,'2017-01-01 to 2017-05-19','YEAR TO DATE: Total CPU Hours and Jobs','','Year to date'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.8362835361396523%2C%22metric%22%3A%22utilization%22%2C%22category%22%3A%22Jobs%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=10&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Previous quarter&timeseries=y&title=PREVIOUS+QUARTER%3A+Percent+CPU+Utilization&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',3,'2017-01-01 to 2017-03-31','PREVIOUS QUARTER: Percent CPU Utilization','','Previous quarter'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.8362835361396523%2C%22metric%22%3A%22utilization%22%2C%22category%22%3A%22Jobs%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-05-19&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=10&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Year to date&timeseries=y&title=YEAR+TO+DATE%3A+Percent+CPU+Utilization&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',4,'2017-01-01 to 2017-05-19','YEAR TO DATE: Percent CPU Utilization','','Year to date'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.8875516747277246%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22person%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.86843077068477%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22person%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Previous quarter&timeseries=n&title=PREVIOUS+QUARTER%3A+CPU+Hours+and+Number+of+Jobs+-+Top+20+Users&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',5,'2017-01-01 to 2017-03-31','PREVIOUS QUARTER: CPU Hours and Number of Jobs - Top 20 Users','','Previous quarter'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.8875516747277246%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22person%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.86843077068477%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22person%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-05-19&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Year to date&timeseries=n&title=YEAR+TO+DATE%3A+CPU+Hours+and+Number+of+Jobs+-+Top+20+Users&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',6,'2017-01-01 to 2017-05-19','YEAR TO DATE: CPU Hours and Number of Jobs - Top 20 Users','','Year to date'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.7387008003042324%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22resource%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.7092602436215469%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22resource%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Previous quarter&timeseries=n&title=PREVIOUS+QUARTER%3A+CPU+Hours+and+Number+of+Jobs+by+Resource&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',7,'2017-01-01 to 2017-03-31','PREVIOUS QUARTER: CPU Hours and Number of Jobs by Resource','','Previous quarter'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.7387008003042324%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22resource%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.7092602436215469%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22resource%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-05-19&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Year to date&timeseries=n&title=YEAR+TO+DATE%3A+CPU+Hours+and+Number+of+Jobs+by+Resource&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',8,'2017-01-01 to 2017-05-19','YEAR TO DATE: CPU Hours and Number of Jobs by Resource','','Year to date'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.8458921141249549%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.6475680299717652%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A3%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.692516068501358%2C%22metric%22%3A%22avg_waitduration_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A2%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Previous quarter&timeseries=n&title=PREVIOUS+QUARTER%3A+CPU+Hours%2C+Number+of+Jobs%2C+and+Wait+Time+per+Job+by+Job+Size&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',9,'2017-01-01 to 2017-03-31','PREVIOUS QUARTER: CPU Hours, Number of Jobs, and Wait Time per Job by Job Size','','Previous quarter'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.8458921141249549%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.6475680299717652%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A3%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.692516068501358%2C%22metric%22%3A%22avg_waitduration_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A2%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-05-19&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Year to date&timeseries=n&title=YEAR+TO+DATE%3A+CPU+Hours%2C+Number+of+Jobs%2C+and+Wait+Time+per+Job+by+Job+Size&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',10,'2017-01-01 to 2017-05-19','YEAR TO DATE: CPU Hours, Number of Jobs, and Wait Time per Job by Job Size','','Year to date'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.1165933087542057%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.73263145649005%2C%22metric%22%3A%22expansion_factor%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Previous quarter&timeseries=n&title=PREVIOUS+QUARTER%3A+CPU+Hours+and+User+Expansion+Factor+by+Job+Size&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',11,'2017-01-01 to 2017-03-31','PREVIOUS QUARTER: CPU Hours and User Expansion Factor by Job Size','','Previous quarter'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.1165933087542057%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.73263145649005%2C%22metric%22%3A%22expansion_factor%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-05-19&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Year to date&timeseries=n&title=YEAR+TO+DATE%3A+CPU+Hours+and+User+Expansion+Factor+by+Job+Size&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',12,'2017-01-01 to 2017-05-19','YEAR TO DATE: CPU Hours and User Expansion Factor by Job Size','','Year to date'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.6455125853438182%2C%22metric%22%3A%22avg_waitduration_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22queue%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Atrue%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Previous quarter&timeseries=n&title=PREVIOUS+QUARTER%3A+Wait+Hours+per+Job+by+Queue&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',13,'2017-01-01 to 2017-03-31','PREVIOUS QUARTER: Wait Hours per Job by Queue','','Previous quarter'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.6455125853438182%2C%22metric%22%3A%22avg_waitduration_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22queue%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Atrue%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-05-19&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Year to date&timeseries=n&title=YEAR+TO+DATE%3A+Wait+Hours+per+Job+by+Queue&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',14,'2017-01-01 to 2017-05-19','YEAR TO DATE: Wait Hours per Job by Queue','','Year to date'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.6885205136927162%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22queue%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.3698379303372821%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22queue%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Atrue%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Previous quarter&timeseries=n&title=PREVIOUS+QUARTER%3A+CPU+Hours+and+Number+of+Jobs+by+Queue&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',15,'2017-01-01 to 2017-03-31','PREVIOUS QUARTER: CPU Hours and Number of Jobs by Queue','','Previous quarter'),(1,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.6885205136927162%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22queue%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.3698379303372821%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22queue%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Atrue%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-05-19&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Year to date&timeseries=n&title=YEAR+TO+DATE%3A+CPU+Hours+and+Number+of+Jobs+by+Queue&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',16,'2017-01-01 to 2017-05-19','YEAR TO DATE: CPU Hours and Number of Jobs by Queue','','Year to date'),(2,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.7563606980721138%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22Jobs%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.8709841114161849%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=10&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Previous quarter&timeseries=true&title=Total+CPU+Hours+and+Jobs&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',1,'2017-01-01 to 2017-03-31','Total CPU Hours and Jobs','','Previous quarter'),(2,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.8362835361396523%2C%22metric%22%3A%22utilization%22%2C%22category%22%3A%22Jobs%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=10&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Previous quarter&timeseries=true&title=Percent+CPU+Utilization&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',2,'2017-01-01 to 2017-03-31','Percent CPU Utilization','','Previous quarter'),(2,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.8875516747277246%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22person%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.86843077068477%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22person%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Previous quarter&timeseries=false&title=CPU+Hours+and+Number+of+Jobs+-+Top+20+Users&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',3,'2017-01-01 to 2017-03-31','CPU Hours and Number of Jobs - Top 20 Users','','Previous quarter'),(2,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.7387008003042324%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22resource%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.7092602436215469%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22resource%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Previous quarter&timeseries=false&title=CPU+Hours+and+Number+of+Jobs+by+Resource&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',4,'2017-01-01 to 2017-03-31','CPU Hours and Number of Jobs by Resource','','Previous quarter'),(2,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.8458921141249549%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.6475680299717652%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A3%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.692516068501358%2C%22metric%22%3A%22avg_waitduration_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A2%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Previous quarter&timeseries=false&title=CPU+Hours%2C+Number+of+Jobs%2C+and+Wait+Time+per+Job+by+Job+Size&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',5,'2017-01-01 to 2017-03-31','CPU Hours, Number of Jobs, and Wait Time per Job by Job Size','','Previous quarter'),(2,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.1165933087542057%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.73263145649005%2C%22metric%22%3A%22expansion_factor%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22jobsize%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22label_asc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Previous quarter&timeseries=false&title=CPU+Hours+and+User+Expansion+Factor+by+Job+Size&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',6,'2017-01-01 to 2017-03-31','CPU Hours and User Expansion Factor by Job Size','','Previous quarter'),(2,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.6455125853438182%2C%22metric%22%3A%22avg_waitduration_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22queue%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Atrue%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Previous quarter&timeseries=false&title=Wait+Hours+per+Job+by+Queue&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',7,'2017-01-01 to 2017-03-31','Wait Hours per Job by Queue','','Previous quarter'),(2,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.6885205136927162%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22queue%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.3698379303372821%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22queue%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Atrue%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Previous quarter&timeseries=false&title=CPU+Hours+and+Number+of+Jobs+by+Queue&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',8,'2017-01-01 to 2017-03-31','CPU Hours and Number of Jobs by Queue','','Previous quarter'),(3,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.7563606980721138%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22Jobs%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.8709841114161849%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=10&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Previous quarter&timeseries=true&title=Total+CPU+Hours+and+Jobs&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',1,'2017-01-01 to 2017-03-31','Total CPU Hours and Jobs','','Previous quarter'),(3,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.8362835361396523%2C%22metric%22%3A%22utilization%22%2C%22category%22%3A%22Jobs%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22none%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=10&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=false&timeframe_label=Previous quarter&timeseries=true&title=Percent+CPU+Utilization&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',2,'2017-01-01 to 2017-03-31','Percent CPU Utilization','','Previous quarter'),(3,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.8875516747277246%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22person%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.86843077068477%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22person%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Previous quarter&timeseries=false&title=CPU+Hours+and+Number+of+Jobs+-+Top+20+Users&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',3,'2017-01-01 to 2017-03-31','CPU Hours and Number of Jobs - Top 20 Users','','Previous quarter'),(3,'controller_module=metric_explorer&aggregation_unit=Auto&data_series=%5B%7B%22id%22%3A0.7387008003042324%2C%22metric%22%3A%22total_cpu_hours%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22resource%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22column%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A0%2C%22enabled%22%3Atrue%7D%2C%7B%22id%22%3A0.7092602436215469%2C%22metric%22%3A%22job_count%22%2C%22category%22%3A%22%22%2C%22realm%22%3A%22Jobs%22%2C%22group_by%22%3A%22resource%22%2C%22x_axis%22%3Afalse%2C%22log_scale%22%3Afalse%2C%22has_std_err%22%3Afalse%2C%22std_err%22%3Afalse%2C%22std_err_labels%22%3A%22%22%2C%22value_labels%22%3Afalse%2C%22display_type%22%3A%22line%22%2C%22line_type%22%3A%22Solid%22%2C%22line_width%22%3A2%2C%22combine_type%22%3A%22side%22%2C%22sort_type%22%3A%22value_desc%22%2C%22filters%22%3A%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D%2C%22ignore_global%22%3Afalse%2C%22long_legend%22%3Atrue%2C%22trend_line%22%3Afalse%2C%22color%22%3A%22auto%22%2C%22shadow%22%3Afalse%2C%22visibility%22%3Anull%2C%22z_index%22%3A1%2C%22enabled%22%3Atrue%7D%5D&defaultDatasetConfig=%7B%7D&end_date=2017-03-31&featured=false&font_size=3&format=hc_jsonstore&global_filters=%7B%22data%22%3A%5B%5D%2C%22total%22%3A0%7D&hide_tooltip=false&legend=%7B%7D&legend_type=bottom_center&limit=20&operation=get_data&share_y_axis=false&showContextMenu=y&show_filters=true&show_guide_lines=y&show_remainder=false&show_warnings=true&start=0&start_date=2017-01-01&swap_xy=true&timeframe_label=Previous quarter&timeseries=false&title=CPU+Hours+and+Number+of+Jobs+by+Resource&trendLineEnabled=&x_axis=%7B%7D&y_axis=%7B%7D',4,'2017-01-01 to 2017-03-31','CPU Hours and Number of Jobs by Resource','','Previous quarter');
/*!40000 ALTER TABLE `ReportTemplateCharts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReportTemplates`
--

DROP TABLE IF EXISTS `ReportTemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReportTemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(1000) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `template` varchar(30) DEFAULT NULL,
  `title` varchar(1000) DEFAULT NULL,
  `header` varchar(1000) DEFAULT NULL,
  `footer` varchar(1000) DEFAULT NULL,
  `format` enum('Pdf','Pptx','Doc','Xls','Html') DEFAULT NULL,
  `schedule` enum('Once','Daily','Weekly','Monthly','Quarterly','Semi-annually','Annually') DEFAULT NULL,
  `delivery` enum('Download','E-mail') DEFAULT NULL,
  `charts_per_page` int(1) DEFAULT NULL,
  `use_submenu` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReportTemplates`
--

LOCK TABLES `ReportTemplates` WRITE;
/*!40000 ALTER TABLE `ReportTemplates` DISABLE KEYS */;
INSERT INTO `ReportTemplates` VALUES (1,'Quarterly Report - Center Director','Quarterly Report - Center Director','GenericReportTemplate','Quarterly Report - Center Director','','','Pdf','Quarterly','E-mail',1,0),(2,'Dashboard Tab Report','Dashboard Tab Report','GenericReportTemplate','Dashboard Tab Report','','','Pdf','Once','E-mail',1,0),(3,'Dashboard Tab Report','Dashboard Tab Report','GenericReportTemplate','Dashboard Tab Report','','','Pdf','Once','E-mail',1,0);
/*!40000 ALTER TABLE `ReportTemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Reports`
--

DROP TABLE IF EXISTS `Reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Reports` (
  `report_id` varchar(100) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(1000) DEFAULT 'TAS Report',
  `derived_from` varchar(1000) DEFAULT NULL,
  `title` varchar(1000) DEFAULT 'TAS Report',
  `header` varchar(1000) DEFAULT NULL,
  `footer` varchar(1000) DEFAULT NULL,
  `format` enum('Pdf','Pptx','Doc','Xls','Html') NOT NULL DEFAULT 'Pdf',
  `schedule` enum('Once','Daily','Weekly','Monthly','Quarterly','Semi-annually','Annually') NOT NULL DEFAULT 'Once',
  `delivery` enum('Download','E-mail') NOT NULL DEFAULT 'E-mail',
  `selected` tinyint(1) NOT NULL DEFAULT 0,
  `charts_per_page` int(1) DEFAULT NULL,
  `active_role` varchar(30) DEFAULT NULL,
  `last_modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reports`
--

LOCK TABLES `Reports` WRITE;
/*!40000 ALTER TABLE `Reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `Reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SessionManager`
--

DROP TABLE IF EXISTS `SessionManager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SessionManager` (
  `session_token` varchar(40) NOT NULL,
  `session_id` text NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `ip_address` varchar(40) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `init_time` varchar(100) NOT NULL,
  `last_active` varchar(100) NOT NULL,
  `used_logout` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`session_token`) USING BTREE,
  KEY `idx_user_id` (`user_id`),
  KEY `idx_init_time` (`init_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SessionManager`
--

LOCK TABLES `SessionManager` WRITE;
/*!40000 ALTER TABLE `SessionManager` DISABLE KEYS */;
/*!40000 ALTER TABLE `SessionManager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserProfiles`
--

DROP TABLE IF EXISTS `UserProfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserProfiles` (
  `user_id` int(11) NOT NULL DEFAULT 0,
  `serialized_profile_data` longblob DEFAULT NULL,
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserProfiles`
--

LOCK TABLES `UserProfiles` WRITE;
/*!40000 ALTER TABLE `UserProfiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserProfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserTypes`
--

DROP TABLE IF EXISTS `UserTypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserTypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) DEFAULT NULL,
  `color` char(7) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserTypes`
--

LOCK TABLES `UserTypes` WRITE;
/*!40000 ALTER TABLE `UserTypes` DISABLE KEYS */;
INSERT INTO `UserTypes` VALUES (1,'External','#000000'),(2,'Internal','#0000ff'),(3,'Testing','#008800'),(4,'Demo','#808000'),(5,'Single Sign On','#b914f6');
/*!40000 ALTER TABLE `UserTypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL DEFAULT '',
  `password` varchar(255) DEFAULT NULL,
  `email_address` varchar(200) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT '',
  `last_name` varchar(50) DEFAULT NULL,
  `time_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `time_last_updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `password_last_updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `account_is_active` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `person_id` int(11) DEFAULT NULL COMMENT 'references TGcDB.people.person_id',
  `organization_id` int(11) DEFAULT NULL COMMENT 'references TGcDB.organizations.organization_id',
  `field_of_science` int(11) DEFAULT NULL,
  `token` varchar(32) DEFAULT NULL,
  `token_expiration` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_type` int(11) NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT 0 COMMENT 'Set when an admin manually updates the [person|organization]_id. Indicates that further modification must be made manually by an admin.',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_uniq_username` (`username`) USING BTREE,
  KEY `person_id_idx` (`person_id`) USING BTREE,
  KEY `idx_user_type` (`user_type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,'Public User',NULL,'public@ccr.xdmod.org','Public','','User','2026-07-15 15:07:22','2026-07-15 15:07:22','0000-00-00 00:00:00',1,-1,-1,0,NULL,'0000-00-00 00:00:00',2,0),(2,'admin','$2y$10$20MxNvzUKpVy9Mq6fjSyLO20rLajMHYngfrl1bRkDWE7yOyC2qugK','admin@localhost','Admin','','User','2026-07-15 15:07:35','2026-07-15 15:07:35','0000-00-00 00:00:00',1,-1,0,0,'zC4ZNrptQCAdfsXj13DfS6EHMZbQRylF','2026-08-14 15:07:35',2,0),(3,'centerdirector','$2y$10$xrxVckpEMXRO1O24sa2H5OXf1mYcd88uQKNROPSuDfbc/x0NI6bxm','centerdirector@example.com','Reed','','Bunting','2026-07-15 15:09:11','2026-07-15 15:09:11','0000-00-00 00:00:00',1,97,1,0,'jRYYiKjF2EtvJWGqtQLg4cFhUh7JDNRF','2026-08-14 15:09:11',1,0),(4,'centerstaff','$2y$10$VpqCJBUHVZIl4J2ioxqr.ebz/0S4tBAwMnCh2HcDAKMqn0qE0iEQq','centerstaff@example.com','Turtle','','Dove','2026-07-15 15:09:11','2026-07-15 15:09:11','0000-00-00 00:00:00',1,111,1,0,'zxfYNCzcutRnEaD4vDor1n8GTi4vGh0D','2026-08-14 15:09:11',1,0),(5,'principal','$2y$10$CPeG8rkz28Ap0HkKNY.P5eUNAF.lVqeB4w5V9qPWR1TjcIbFDplEi','principal@example.com','Caspian','','Tern','2026-07-15 15:09:11','2026-07-15 15:09:11','0000-00-00 00:00:00',1,9,1,0,'wNGl38YXTttao04SOCP8J6cVLOf8dH5u','2026-08-14 15:09:11',1,0),(6,'normaluser','$2y$10$DsNiVgbfNE2HcSYbDxlhu.uOcSdLkMZpEn53Tlyjc.HHD87A4GsUK','normaluser@example.com','','','Whimbrel','2026-07-15 15:09:11','2026-07-15 15:09:11','0000-00-00 00:00:00',1,114,1,0,'9sKxEHNQobl3fPl6qnoWyrT797c7XivJ','2026-08-14 15:09:11',1,0);
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`xdmod`@`localhost`*/ /*!50003 TRIGGER `moddb`.`users_insert_timestamp` BEFORE INSERT ON `moddb`.`Users` FOR EACH ROW
 BEGIN


	SET NEW.time_created = NOW();

	SET NEW.time_last_updated = NOW();


END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`xdmod`@`localhost`*/ /*!50003 TRIGGER `moddb`.`users_update_timestamp` BEFORE UPDATE ON `moddb`.`Users` FOR EACH ROW
 BEGIN


	IF NEW.password <> OLD.password THEN

		SET NEW.password_last_updated = NOW(); 

	END IF; 

	SET NEW.time_last_updated = NOW();


END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `VersionCheck`
--

DROP TABLE IF EXISTS `VersionCheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VersionCheck` (
  `entry_date` datetime NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `name` varchar(255) DEFAULT NULL COMMENT 'Log of xdmod version checks',
  `email` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `current_version` varchar(16) DEFAULT NULL,
  `all_params` text DEFAULT NULL,
  KEY `entry_date` (`entry_date`) USING BTREE,
  KEY `ip` (`ip_address`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VersionCheck`
--

LOCK TABLES `VersionCheck` WRITE;
/*!40000 ALTER TABLE `VersionCheck` DISABLE KEYS */;
/*!40000 ALTER TABLE `VersionCheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_dimensions`
--

DROP TABLE IF EXISTS `acl_dimensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acl_dimensions` (
  `acl_dimension_id` int(11) NOT NULL AUTO_INCREMENT,
  `acl_id` int(11) NOT NULL,
  `group_by_id` int(11) NOT NULL COMMENT 'The group_by that this acl uses to filter query data.',
  PRIMARY KEY (`acl_dimension_id`) USING BTREE,
  KEY `idx_acl_id` (`acl_id`) USING BTREE,
  KEY `idx_group_by_id` (`group_by_id`) USING BTREE,
  CONSTRAINT `fk_ad_acl_id` FOREIGN KEY (`acl_id`) REFERENCES `acls` (`acl_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ad_gb_id` FOREIGN KEY (`group_by_id`) REFERENCES `group_bys` (`group_by_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COMMENT='Tracks which dimension(s) are used by an acl to filter query data.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acl_dimensions`
--

LOCK TABLES `acl_dimensions` WRITE;
/*!40000 ALTER TABLE `acl_dimensions` DISABLE KEYS */;
INSERT INTO `acl_dimensions` VALUES (1,2,7),(2,2,26),(3,2,49),(4,3,5),(5,3,46),(6,3,58),(7,4,6),(8,4,27),(9,4,40),(10,5,5),(11,5,46),(12,5,58);
/*!40000 ALTER TABLE `acl_dimensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_group_bys`
--

DROP TABLE IF EXISTS `acl_group_bys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acl_group_bys` (
  `acl_group_by_id` int(11) NOT NULL AUTO_INCREMENT,
  `acl_id` int(11) NOT NULL,
  `group_by_id` int(11) NOT NULL,
  `realm_id` int(11) NOT NULL,
  `statistic_id` int(11) NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT 1,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`acl_group_by_id`) USING BTREE,
  UNIQUE KEY `uniq_acl_group_by_realm_statistic` (`acl_id`,`group_by_id`,`realm_id`,`statistic_id`) USING BTREE,
  KEY `idx_acl_id` (`acl_id`),
  KEY `idx_group_by_id` (`group_by_id`),
  KEY `idx_realm_id` (`realm_id`),
  KEY `idx_statistic_id` (`statistic_id`),
  CONSTRAINT `fk_agb_acl_id` FOREIGN KEY (`acl_id`) REFERENCES `acls` (`acl_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_agb_group_by_id` FOREIGN KEY (`group_by_id`) REFERENCES `group_bys` (`group_by_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_agb_realm_id` FOREIGN KEY (`realm_id`) REFERENCES `realms` (`realm_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_agb_statistic_id` FOREIGN KEY (`statistic_id`) REFERENCES `statistics` (`statistic_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4935 DEFAULT CHARSET=latin1 COMMENT='Tracks which `acls` have a relation to which `group_bys` ( what is known in the code base as a `QueryDescripter` ).';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acl_group_bys`
--

LOCK TABLES `acl_group_bys` WRITE;
/*!40000 ALTER TABLE `acl_group_bys` DISABLE KEYS */;
INSERT INTO `acl_group_bys` VALUES (1,1,17,1,1,1,1),(2,1,17,1,2,1,1),(3,1,17,1,3,1,1),(4,1,17,1,4,1,1),(5,1,17,1,5,1,1),(6,1,17,1,6,1,1),(7,1,17,1,7,1,1),(8,1,17,1,8,1,1),(9,1,17,1,9,1,1),(10,1,17,1,10,0,1),(11,1,17,1,11,0,1),(12,1,17,1,12,0,1),(13,1,17,1,13,0,1),(14,1,17,1,14,0,1),(15,1,17,1,15,0,1),(16,1,17,1,16,1,1),(17,1,17,1,17,1,1),(18,1,17,1,18,1,1),(19,1,17,1,19,1,1),(20,1,17,1,20,1,1),(21,1,17,1,21,1,1),(22,1,17,1,22,1,1),(23,1,17,1,23,1,1),(24,1,17,1,24,1,1),(25,1,17,1,25,1,1),(26,1,17,1,26,1,1),(27,1,17,1,27,1,1),(28,1,17,1,28,1,1),(29,1,17,1,29,1,1),(30,1,17,1,30,1,1),(31,1,17,1,31,1,1),(32,1,17,1,32,1,1),(33,1,8,1,1,1,1),(34,1,8,1,2,1,1),(35,1,8,1,3,1,1),(36,1,8,1,4,1,1),(37,1,8,1,5,1,1),(38,1,8,1,6,1,1),(39,1,8,1,7,1,1),(40,1,8,1,8,1,1),(41,1,8,1,9,1,1),(42,1,8,1,10,0,1),(43,1,8,1,11,0,1),(44,1,8,1,12,0,1),(45,1,8,1,13,0,1),(46,1,8,1,14,0,1),(47,1,8,1,15,0,1),(48,1,8,1,16,1,1),(49,1,8,1,17,1,1),(50,1,8,1,18,1,1),(51,1,8,1,19,1,1),(52,1,8,1,20,1,1),(53,1,8,1,21,1,1),(54,1,8,1,22,1,1),(55,1,8,1,23,1,1),(56,1,8,1,24,1,1),(57,1,8,1,25,1,1),(58,1,8,1,26,1,1),(59,1,8,1,27,1,1),(60,1,8,1,28,1,1),(61,1,8,1,29,1,1),(62,1,8,1,30,1,1),(63,1,8,1,31,1,1),(64,1,8,1,32,1,1),(65,1,16,1,1,1,1),(66,1,16,1,2,1,1),(67,1,16,1,3,1,1),(68,1,16,1,4,1,1),(69,1,16,1,5,1,1),(70,1,16,1,6,1,1),(71,1,16,1,7,1,1),(72,1,16,1,8,1,1),(73,1,16,1,9,1,1),(74,1,16,1,10,0,1),(75,1,16,1,11,0,1),(76,1,16,1,12,0,1),(77,1,16,1,13,0,1),(78,1,16,1,14,0,1),(79,1,16,1,15,0,1),(80,1,16,1,16,1,1),(81,1,16,1,17,1,1),(82,1,16,1,18,1,1),(83,1,16,1,19,1,1),(84,1,16,1,20,1,1),(85,1,16,1,21,1,1),(86,1,16,1,22,1,1),(87,1,16,1,23,1,1),(88,1,16,1,24,1,1),(89,1,16,1,25,1,1),(90,1,16,1,26,1,1),(91,1,16,1,27,1,1),(92,1,16,1,28,1,1),(93,1,16,1,29,1,1),(94,1,16,1,30,1,1),(95,1,16,1,31,1,1),(96,1,16,1,32,1,1),(97,1,15,1,1,1,1),(98,1,15,1,2,1,1),(99,1,15,1,3,1,1),(100,1,15,1,4,1,1),(101,1,15,1,5,1,1),(102,1,15,1,6,1,1),(103,1,15,1,7,1,1),(104,1,15,1,8,1,1),(105,1,15,1,9,1,1),(106,1,15,1,10,0,1),(107,1,15,1,11,0,1),(108,1,15,1,12,0,1),(109,1,15,1,13,0,1),(110,1,15,1,14,0,1),(111,1,15,1,15,0,1),(112,1,15,1,16,1,1),(113,1,15,1,17,1,1),(114,1,15,1,18,1,1),(115,1,15,1,19,1,1),(116,1,15,1,20,1,1),(117,1,15,1,21,1,1),(118,1,15,1,22,1,1),(119,1,15,1,23,1,1),(120,1,15,1,24,1,1),(121,1,15,1,25,1,1),(122,1,15,1,26,1,1),(123,1,15,1,27,1,1),(124,1,15,1,28,1,1),(125,1,15,1,29,1,1),(126,1,15,1,30,1,1),(127,1,15,1,31,1,1),(128,1,15,1,32,1,1),(129,1,13,1,1,1,1),(130,1,13,1,2,1,1),(131,1,13,1,3,1,1),(132,1,13,1,4,1,1),(133,1,13,1,5,1,1),(134,1,13,1,6,1,1),(135,1,13,1,7,1,1),(136,1,13,1,8,1,1),(137,1,13,1,9,1,1),(138,1,13,1,10,0,1),(139,1,13,1,11,0,1),(140,1,13,1,12,0,1),(141,1,13,1,13,0,1),(142,1,13,1,14,0,1),(143,1,13,1,15,0,1),(144,1,13,1,16,1,1),(145,1,13,1,17,1,1),(146,1,13,1,18,1,1),(147,1,13,1,19,1,1),(148,1,13,1,20,1,1),(149,1,13,1,21,1,1),(150,1,13,1,22,1,1),(151,1,13,1,23,1,1),(152,1,13,1,24,1,1),(153,1,13,1,25,1,1),(154,1,13,1,26,1,1),(155,1,13,1,27,1,1),(156,1,13,1,28,1,1),(157,1,13,1,29,1,1),(158,1,13,1,30,1,1),(159,1,13,1,31,1,1),(160,1,13,1,32,1,1),(161,1,14,1,1,1,1),(162,1,14,1,2,1,1),(163,1,14,1,3,1,1),(164,1,14,1,4,1,1),(165,1,14,1,5,1,1),(166,1,14,1,6,1,1),(167,1,14,1,7,1,1),(168,1,14,1,8,1,1),(169,1,14,1,9,1,1),(170,1,14,1,10,0,1),(171,1,14,1,11,0,1),(172,1,14,1,12,0,1),(173,1,14,1,13,0,1),(174,1,14,1,14,0,1),(175,1,14,1,15,0,1),(176,1,14,1,16,1,1),(177,1,14,1,17,1,1),(178,1,14,1,18,1,1),(179,1,14,1,19,1,1),(180,1,14,1,20,1,1),(181,1,14,1,21,1,1),(182,1,14,1,22,1,1),(183,1,14,1,23,1,1),(184,1,14,1,24,1,1),(185,1,14,1,25,1,1),(186,1,14,1,26,1,1),(187,1,14,1,27,1,1),(188,1,14,1,28,1,1),(189,1,14,1,29,1,1),(190,1,14,1,30,1,1),(191,1,14,1,31,1,1),(192,1,14,1,32,1,1),(193,1,11,1,1,1,1),(194,1,11,1,2,1,1),(195,1,11,1,3,1,1),(196,1,11,1,4,1,1),(197,1,11,1,5,1,1),(198,1,11,1,6,1,1),(199,1,11,1,7,1,1),(200,1,11,1,8,1,1),(201,1,11,1,9,1,1),(202,1,11,1,10,0,1),(203,1,11,1,11,0,1),(204,1,11,1,12,0,1),(205,1,11,1,13,0,1),(206,1,11,1,14,0,1),(207,1,11,1,15,0,1),(208,1,11,1,16,1,1),(209,1,11,1,17,1,1),(210,1,11,1,18,1,1),(211,1,11,1,19,1,1),(212,1,11,1,20,1,1),(213,1,11,1,21,1,1),(214,1,11,1,22,1,1),(215,1,11,1,23,1,1),(216,1,11,1,24,1,1),(217,1,11,1,25,1,1),(218,1,11,1,26,1,1),(219,1,11,1,27,1,1),(220,1,11,1,28,1,1),(221,1,11,1,29,1,1),(222,1,11,1,30,1,1),(223,1,11,1,31,1,1),(224,1,11,1,32,1,1),(225,1,2,1,1,1,1),(226,1,2,1,2,1,1),(227,1,2,1,3,1,1),(228,1,2,1,4,1,1),(229,1,2,1,5,1,1),(230,1,2,1,6,1,1),(231,1,2,1,7,1,1),(232,1,2,1,8,1,1),(233,1,2,1,9,1,1),(234,1,2,1,10,0,1),(235,1,2,1,11,0,1),(236,1,2,1,12,0,1),(237,1,2,1,13,0,1),(238,1,2,1,14,0,1),(239,1,2,1,15,0,1),(240,1,2,1,16,1,1),(241,1,2,1,17,1,1),(242,1,2,1,18,1,1),(243,1,2,1,19,1,1),(244,1,2,1,20,1,1),(245,1,2,1,21,1,1),(246,1,2,1,22,1,1),(247,1,2,1,23,1,1),(248,1,2,1,24,1,1),(249,1,2,1,25,1,1),(250,1,2,1,26,1,1),(251,1,2,1,27,1,1),(252,1,2,1,28,1,1),(253,1,2,1,29,1,1),(254,1,2,1,30,1,1),(255,1,2,1,31,1,1),(256,1,2,1,32,1,1),(257,1,1,1,1,1,1),(258,1,1,1,2,1,1),(259,1,1,1,3,1,1),(260,1,1,1,4,1,1),(261,1,1,1,5,1,1),(262,1,1,1,6,1,1),(263,1,1,1,7,1,1),(264,1,1,1,8,1,1),(265,1,1,1,9,1,1),(266,1,1,1,10,0,1),(267,1,1,1,11,0,1),(268,1,1,1,12,0,1),(269,1,1,1,13,0,1),(270,1,1,1,14,0,1),(271,1,1,1,15,0,1),(272,1,1,1,16,1,1),(273,1,1,1,17,1,1),(274,1,1,1,18,1,1),(275,1,1,1,19,1,1),(276,1,1,1,20,1,1),(277,1,1,1,21,1,1),(278,1,1,1,22,1,1),(279,1,1,1,23,1,1),(280,1,1,1,24,1,1),(281,1,1,1,25,1,1),(282,1,1,1,26,1,1),(283,1,1,1,27,1,1),(284,1,1,1,28,1,1),(285,1,1,1,29,1,1),(286,1,1,1,30,1,1),(287,1,1,1,31,1,1),(288,1,1,1,32,1,1),(289,1,6,1,1,1,1),(290,1,6,1,2,1,1),(291,1,6,1,3,1,1),(292,1,6,1,4,1,1),(293,1,6,1,5,1,1),(294,1,6,1,6,1,1),(295,1,6,1,7,1,1),(296,1,6,1,8,1,1),(297,1,6,1,9,1,1),(298,1,6,1,10,0,1),(299,1,6,1,11,0,1),(300,1,6,1,12,0,1),(301,1,6,1,13,0,1),(302,1,6,1,14,0,1),(303,1,6,1,15,0,1),(304,1,6,1,16,1,1),(305,1,6,1,17,1,1),(306,1,6,1,18,1,1),(307,1,6,1,19,1,1),(308,1,6,1,20,1,1),(309,1,6,1,21,1,1),(310,1,6,1,22,1,1),(311,1,6,1,23,1,1),(312,1,6,1,24,1,1),(313,1,6,1,25,1,1),(314,1,6,1,26,1,1),(315,1,6,1,27,1,1),(316,1,6,1,28,1,1),(317,1,6,1,29,1,1),(318,1,6,1,30,1,1),(319,1,6,1,31,1,1),(320,1,6,1,32,1,1),(321,1,4,1,1,1,1),(322,1,4,1,2,1,1),(323,1,4,1,3,1,1),(324,1,4,1,4,1,1),(325,1,4,1,5,1,1),(326,1,4,1,6,1,1),(327,1,4,1,7,1,1),(328,1,4,1,8,1,1),(329,1,4,1,9,1,1),(330,1,4,1,10,0,1),(331,1,4,1,11,0,1),(332,1,4,1,12,0,1),(333,1,4,1,13,0,1),(334,1,4,1,14,0,1),(335,1,4,1,15,0,1),(336,1,4,1,16,1,1),(337,1,4,1,17,1,1),(338,1,4,1,18,1,1),(339,1,4,1,19,1,1),(340,1,4,1,20,1,1),(341,1,4,1,21,1,1),(342,1,4,1,22,1,1),(343,1,4,1,23,1,1),(344,1,4,1,24,1,1),(345,1,4,1,25,1,1),(346,1,4,1,26,1,1),(347,1,4,1,27,1,1),(348,1,4,1,28,1,1),(349,1,4,1,29,1,1),(350,1,4,1,30,1,1),(351,1,4,1,31,1,1),(352,1,4,1,32,1,1),(353,1,9,1,1,1,1),(354,1,9,1,2,1,1),(355,1,9,1,3,1,1),(356,1,9,1,4,1,1),(357,1,9,1,5,1,1),(358,1,9,1,6,1,1),(359,1,9,1,7,1,1),(360,1,9,1,8,1,1),(361,1,9,1,9,1,1),(362,1,9,1,10,0,1),(363,1,9,1,11,0,1),(364,1,9,1,12,0,1),(365,1,9,1,13,0,1),(366,1,9,1,14,0,1),(367,1,9,1,15,0,1),(368,1,9,1,16,1,1),(369,1,9,1,17,1,1),(370,1,9,1,18,1,1),(371,1,9,1,19,1,1),(372,1,9,1,20,1,1),(373,1,9,1,21,1,1),(374,1,9,1,22,1,1),(375,1,9,1,23,1,1),(376,1,9,1,24,1,1),(377,1,9,1,25,1,1),(378,1,9,1,26,1,1),(379,1,9,1,27,1,1),(380,1,9,1,28,1,1),(381,1,9,1,29,1,1),(382,1,9,1,30,1,1),(383,1,9,1,31,1,1),(384,1,9,1,32,1,1),(385,1,10,1,1,1,1),(386,1,10,1,2,1,1),(387,1,10,1,3,1,1),(388,1,10,1,4,1,1),(389,1,10,1,5,1,1),(390,1,10,1,6,1,1),(391,1,10,1,7,1,1),(392,1,10,1,8,1,1),(393,1,10,1,9,1,1),(394,1,10,1,10,0,1),(395,1,10,1,11,0,1),(396,1,10,1,12,0,1),(397,1,10,1,13,0,1),(398,1,10,1,14,0,1),(399,1,10,1,15,0,1),(400,1,10,1,16,1,1),(401,1,10,1,17,1,1),(402,1,10,1,18,1,1),(403,1,10,1,19,1,1),(404,1,10,1,20,1,1),(405,1,10,1,21,1,1),(406,1,10,1,22,1,1),(407,1,10,1,23,1,1),(408,1,10,1,24,1,1),(409,1,10,1,25,1,1),(410,1,10,1,26,1,1),(411,1,10,1,27,1,1),(412,1,10,1,28,1,1),(413,1,10,1,29,1,1),(414,1,10,1,30,1,1),(415,1,10,1,31,1,1),(416,1,10,1,32,1,1),(417,1,3,1,1,1,1),(418,1,3,1,2,1,1),(419,1,3,1,3,1,1),(420,1,3,1,4,1,1),(421,1,3,1,5,1,1),(422,1,3,1,6,1,1),(423,1,3,1,7,1,1),(424,1,3,1,8,1,1),(425,1,3,1,9,1,1),(426,1,3,1,10,0,1),(427,1,3,1,11,0,1),(428,1,3,1,12,0,1),(429,1,3,1,13,0,1),(430,1,3,1,14,0,1),(431,1,3,1,15,0,1),(432,1,3,1,16,1,1),(433,1,3,1,17,1,1),(434,1,3,1,18,1,1),(435,1,3,1,19,1,1),(436,1,3,1,20,1,1),(437,1,3,1,21,1,1),(438,1,3,1,22,1,1),(439,1,3,1,23,1,1),(440,1,3,1,24,1,1),(441,1,3,1,25,1,1),(442,1,3,1,26,1,1),(443,1,3,1,27,1,1),(444,1,3,1,28,1,1),(445,1,3,1,29,1,1),(446,1,3,1,30,1,1),(447,1,3,1,31,1,1),(448,1,3,1,32,1,1),(449,1,7,1,1,1,1),(450,1,7,1,2,1,1),(451,1,7,1,3,1,1),(452,1,7,1,4,1,1),(453,1,7,1,5,1,1),(454,1,7,1,6,1,1),(455,1,7,1,7,1,1),(456,1,7,1,8,1,1),(457,1,7,1,9,1,1),(458,1,7,1,10,0,1),(459,1,7,1,11,0,1),(460,1,7,1,12,0,1),(461,1,7,1,13,0,1),(462,1,7,1,14,0,1),(463,1,7,1,15,0,1),(464,1,7,1,16,1,1),(465,1,7,1,17,1,1),(466,1,7,1,18,1,1),(467,1,7,1,19,1,1),(468,1,7,1,20,1,1),(469,1,7,1,21,1,1),(470,1,7,1,22,1,1),(471,1,7,1,23,1,1),(472,1,7,1,24,1,1),(473,1,7,1,25,1,1),(474,1,7,1,26,1,1),(475,1,7,1,27,1,1),(476,1,7,1,28,1,1),(477,1,7,1,29,1,1),(478,1,7,1,30,1,1),(479,1,7,1,31,1,1),(480,1,7,1,32,1,1),(481,1,12,1,1,1,0),(482,1,12,1,2,1,0),(483,1,12,1,3,1,0),(484,1,12,1,4,1,0),(485,1,12,1,5,1,0),(486,1,12,1,6,1,0),(487,1,12,1,7,1,0),(488,1,12,1,8,1,0),(489,1,12,1,9,1,0),(490,1,12,1,10,0,0),(491,1,12,1,11,0,0),(492,1,12,1,12,0,0),(493,1,12,1,13,0,0),(494,1,12,1,14,0,0),(495,1,12,1,15,0,0),(496,1,12,1,16,1,0),(497,1,12,1,17,1,0),(498,1,12,1,18,1,0),(499,1,12,1,19,1,0),(500,1,12,1,20,1,0),(501,1,12,1,21,1,0),(502,1,12,1,22,1,0),(503,1,12,1,23,1,0),(504,1,12,1,24,1,0),(505,1,12,1,25,1,0),(506,1,12,1,26,1,0),(507,1,12,1,27,1,0),(508,1,12,1,28,1,0),(509,1,12,1,29,1,0),(510,1,12,1,30,1,0),(511,1,12,1,31,1,0),(512,1,12,1,32,1,0),(513,1,50,3,43,1,1),(514,1,50,3,44,1,1),(515,1,50,3,45,1,1),(516,1,50,3,46,1,1),(517,1,50,3,47,1,1),(518,1,50,3,48,1,1),(519,1,50,3,49,1,1),(520,1,50,3,50,1,1),(521,1,50,3,51,1,1),(522,1,50,3,52,1,1),(523,1,48,3,43,1,1),(524,1,48,3,44,1,1),(525,1,48,3,45,1,1),(526,1,48,3,46,1,1),(527,1,48,3,47,1,1),(528,1,48,3,48,1,1),(529,1,48,3,49,1,1),(530,1,48,3,50,1,1),(531,1,48,3,51,1,1),(532,1,48,3,52,1,1),(533,1,55,3,43,1,1),(534,1,55,3,44,1,1),(535,1,55,3,45,1,1),(536,1,55,3,46,1,1),(537,1,55,3,47,1,1),(538,1,55,3,48,1,1),(539,1,55,3,49,1,1),(540,1,55,3,50,1,1),(541,1,55,3,51,1,1),(542,1,55,3,52,1,1),(543,1,47,3,43,1,1),(544,1,47,3,44,1,1),(545,1,47,3,45,1,1),(546,1,47,3,46,1,1),(547,1,47,3,47,1,1),(548,1,47,3,48,1,1),(549,1,47,3,49,1,1),(550,1,47,3,50,1,1),(551,1,47,3,51,1,1),(552,1,47,3,52,1,1),(553,1,43,3,43,1,1),(554,1,43,3,44,1,1),(555,1,43,3,45,1,1),(556,1,43,3,46,1,1),(557,1,43,3,47,1,1),(558,1,43,3,48,1,1),(559,1,43,3,49,1,1),(560,1,43,3,50,1,1),(561,1,43,3,51,1,1),(562,1,43,3,52,1,1),(563,1,42,3,43,1,1),(564,1,42,3,44,1,1),(565,1,42,3,45,1,1),(566,1,42,3,46,1,1),(567,1,42,3,47,1,1),(568,1,42,3,48,1,1),(569,1,42,3,49,1,1),(570,1,42,3,50,1,1),(571,1,42,3,51,1,1),(572,1,42,3,52,1,1),(573,1,45,3,43,1,1),(574,1,45,3,44,1,1),(575,1,45,3,45,1,1),(576,1,45,3,46,1,1),(577,1,45,3,47,1,1),(578,1,45,3,48,1,1),(579,1,45,3,49,1,1),(580,1,45,3,50,1,1),(581,1,45,3,51,1,1),(582,1,45,3,52,1,1),(583,1,49,3,43,1,1),(584,1,49,3,44,1,1),(585,1,49,3,45,1,1),(586,1,49,3,46,1,1),(587,1,49,3,47,1,1),(588,1,49,3,48,1,1),(589,1,49,3,49,1,1),(590,1,49,3,50,1,1),(591,1,49,3,51,1,1),(592,1,49,3,52,1,1),(593,1,44,3,43,1,0),(594,1,44,3,44,1,0),(595,1,44,3,45,1,0),(596,1,44,3,46,1,0),(597,1,44,3,47,1,0),(598,1,44,3,48,1,0),(599,1,44,3,49,1,0),(600,1,44,3,50,1,0),(601,1,44,3,51,1,0),(602,1,44,3,52,1,0),(603,1,37,3,43,1,1),(604,1,37,3,44,1,1),(605,1,37,3,45,1,1),(606,1,37,3,46,1,1),(607,1,37,3,47,1,1),(608,1,37,3,48,1,1),(609,1,37,3,49,1,1),(610,1,37,3,50,1,1),(611,1,37,3,51,1,1),(612,1,37,3,52,1,1),(613,1,40,3,43,1,1),(614,1,40,3,44,1,1),(615,1,40,3,45,1,1),(616,1,40,3,46,1,1),(617,1,40,3,47,1,1),(618,1,40,3,48,1,1),(619,1,40,3,49,1,1),(620,1,40,3,50,1,1),(621,1,40,3,51,1,1),(622,1,40,3,52,1,1),(623,1,39,3,43,1,1),(624,1,39,3,44,1,1),(625,1,39,3,45,1,1),(626,1,39,3,46,1,1),(627,1,39,3,47,1,1),(628,1,39,3,48,1,1),(629,1,39,3,49,1,1),(630,1,39,3,50,1,1),(631,1,39,3,51,1,1),(632,1,39,3,52,1,1),(633,1,38,3,43,1,1),(634,1,38,3,44,1,1),(635,1,38,3,45,1,1),(636,1,38,3,46,1,1),(637,1,38,3,47,1,1),(638,1,38,3,48,1,1),(639,1,38,3,49,1,1),(640,1,38,3,50,1,1),(641,1,38,3,51,1,1),(642,1,38,3,52,1,1),(643,1,36,3,43,1,1),(644,1,36,3,44,1,1),(645,1,36,3,45,1,1),(646,1,36,3,46,1,1),(647,1,36,3,47,1,1),(648,1,36,3,48,1,1),(649,1,36,3,49,1,1),(650,1,36,3,50,1,1),(651,1,36,3,51,1,1),(652,1,36,3,52,1,1),(653,1,41,3,43,1,1),(654,1,41,3,44,1,1),(655,1,41,3,45,1,1),(656,1,41,3,46,0,1),(657,1,41,3,47,1,1),(658,1,41,3,48,0,1),(659,1,41,3,49,0,1),(660,1,41,3,50,0,1),(661,1,41,3,51,1,1),(662,1,41,3,52,1,1),(663,1,60,4,53,1,1),(664,1,60,4,54,1,1),(665,1,60,4,55,1,1),(666,1,60,4,56,1,1),(667,1,60,4,57,1,1),(668,1,60,4,58,1,1),(669,1,60,4,59,1,1),(670,1,60,4,60,1,1),(671,1,60,4,61,1,1),(672,1,60,4,62,1,1),(673,1,60,4,63,1,1),(674,1,60,4,64,1,1),(675,1,60,4,65,1,1),(676,1,60,4,66,1,1),(677,1,60,4,67,1,1),(678,1,60,4,68,1,1),(679,1,56,4,53,1,1),(680,1,56,4,54,1,1),(681,1,56,4,55,1,1),(682,1,56,4,56,1,1),(683,1,56,4,57,1,1),(684,1,56,4,58,1,1),(685,1,56,4,59,1,1),(686,1,56,4,60,1,1),(687,1,56,4,61,1,1),(688,1,56,4,62,1,1),(689,1,56,4,63,1,1),(690,1,56,4,64,1,1),(691,1,56,4,65,1,1),(692,1,56,4,66,1,1),(693,1,56,4,67,1,1),(694,1,56,4,68,1,1),(695,1,57,4,53,1,1),(696,1,57,4,54,1,1),(697,1,57,4,55,1,1),(698,1,57,4,56,1,1),(699,1,57,4,57,1,1),(700,1,57,4,58,1,1),(701,1,57,4,59,1,1),(702,1,57,4,60,1,1),(703,1,57,4,61,1,1),(704,1,57,4,62,1,1),(705,1,57,4,63,1,1),(706,1,57,4,64,1,1),(707,1,57,4,65,1,1),(708,1,57,4,66,1,1),(709,1,57,4,67,1,1),(710,1,57,4,68,1,1),(711,1,58,4,53,1,1),(712,1,58,4,54,1,1),(713,1,58,4,55,1,1),(714,1,58,4,56,1,1),(715,1,58,4,57,1,1),(716,1,58,4,58,1,1),(717,1,58,4,59,1,1),(718,1,58,4,60,1,1),(719,1,58,4,61,1,1),(720,1,58,4,62,1,1),(721,1,58,4,63,1,1),(722,1,58,4,64,1,1),(723,1,58,4,65,1,1),(724,1,58,4,66,1,1),(725,1,58,4,67,1,1),(726,1,58,4,68,1,1),(727,1,59,4,53,1,1),(728,1,59,4,54,1,1),(729,1,59,4,55,1,1),(730,1,59,4,56,1,1),(731,1,59,4,57,1,1),(732,1,59,4,58,1,1),(733,1,59,4,59,1,1),(734,1,59,4,60,1,1),(735,1,59,4,61,1,1),(736,1,59,4,62,1,1),(737,1,59,4,63,1,1),(738,1,59,4,64,1,1),(739,1,59,4,65,1,1),(740,1,59,4,66,1,1),(741,1,59,4,67,1,1),(742,1,59,4,68,1,1),(743,1,31,2,33,1,1),(744,1,31,2,34,1,1),(745,1,31,2,35,1,1),(746,1,31,2,36,1,1),(747,1,31,2,37,1,1),(748,1,31,2,38,0,1),(749,1,31,2,39,0,1),(750,1,31,2,40,0,1),(751,1,31,2,41,1,1),(752,1,31,2,42,1,1),(753,1,28,2,33,1,1),(754,1,28,2,34,1,1),(755,1,28,2,35,1,1),(756,1,28,2,36,1,1),(757,1,28,2,37,1,1),(758,1,28,2,38,0,1),(759,1,28,2,39,0,1),(760,1,28,2,40,0,1),(761,1,28,2,41,1,1),(762,1,28,2,42,1,1),(763,1,29,2,33,1,1),(764,1,29,2,34,1,1),(765,1,29,2,35,1,1),(766,1,29,2,36,1,1),(767,1,29,2,37,1,1),(768,1,29,2,38,0,1),(769,1,29,2,39,0,1),(770,1,29,2,40,0,1),(771,1,29,2,41,1,1),(772,1,29,2,42,1,1),(773,1,25,2,33,1,1),(774,1,25,2,34,1,1),(775,1,25,2,35,1,1),(776,1,25,2,36,1,1),(777,1,25,2,37,1,1),(778,1,25,2,38,0,1),(779,1,25,2,39,0,1),(780,1,25,2,40,0,1),(781,1,25,2,41,1,1),(782,1,25,2,42,1,1),(783,1,26,2,33,1,1),(784,1,26,2,34,1,1),(785,1,26,2,35,1,1),(786,1,26,2,36,1,1),(787,1,26,2,37,1,1),(788,1,26,2,38,0,1),(789,1,26,2,39,0,1),(790,1,26,2,40,0,1),(791,1,26,2,41,1,1),(792,1,26,2,42,1,1),(793,1,27,2,33,1,1),(794,1,27,2,34,1,1),(795,1,27,2,35,1,1),(796,1,27,2,36,1,1),(797,1,27,2,37,1,1),(798,1,27,2,38,0,1),(799,1,27,2,39,0,1),(800,1,27,2,40,0,1),(801,1,27,2,41,1,1),(802,1,27,2,42,1,1),(803,1,30,2,33,1,0),(804,1,30,2,34,1,0),(805,1,30,2,35,1,0),(806,1,30,2,36,1,0),(807,1,30,2,37,1,0),(808,1,30,2,38,0,0),(809,1,30,2,39,0,0),(810,1,30,2,40,0,0),(811,1,30,2,41,1,0),(812,1,30,2,42,1,0),(813,1,23,2,33,1,1),(814,1,23,2,34,1,1),(815,1,23,2,35,1,1),(816,1,23,2,36,1,1),(817,1,23,2,37,1,1),(818,1,23,2,38,0,1),(819,1,23,2,39,0,1),(820,1,23,2,40,0,1),(821,1,23,2,41,1,1),(822,1,23,2,42,1,1),(823,1,24,2,33,1,1),(824,1,24,2,34,1,1),(825,1,24,2,35,1,1),(826,1,24,2,36,1,1),(827,1,24,2,37,1,1),(828,1,24,2,38,0,1),(829,1,24,2,39,0,1),(830,1,24,2,40,0,1),(831,1,24,2,41,1,1),(832,1,24,2,42,1,1),(833,1,22,2,33,1,1),(834,1,22,2,34,1,1),(835,1,22,2,35,1,1),(836,1,22,2,36,1,1),(837,1,22,2,37,1,1),(838,1,22,2,38,0,1),(839,1,22,2,39,0,1),(840,1,22,2,40,0,1),(841,1,22,2,41,1,1),(842,1,22,2,42,1,1),(1024,2,50,3,43,1,1),(1025,2,50,3,44,1,1),(1026,2,50,3,45,1,1),(1027,2,50,3,46,1,1),(1028,2,50,3,47,1,1),(1029,2,50,3,48,1,1),(1030,2,50,3,49,1,1),(1031,2,50,3,50,1,1),(1032,2,50,3,51,1,1),(1033,2,50,3,52,1,1),(1034,2,48,3,43,1,1),(1035,2,48,3,44,1,1),(1036,2,48,3,45,1,1),(1037,2,48,3,46,1,1),(1038,2,48,3,47,1,1),(1039,2,48,3,48,1,1),(1040,2,48,3,49,1,1),(1041,2,48,3,50,1,1),(1042,2,48,3,51,1,1),(1043,2,48,3,52,1,1),(1044,2,55,3,43,1,1),(1045,2,55,3,44,1,1),(1046,2,55,3,45,1,1),(1047,2,55,3,46,1,1),(1048,2,55,3,47,1,1),(1049,2,55,3,48,1,1),(1050,2,55,3,49,1,1),(1051,2,55,3,50,1,1),(1052,2,55,3,51,1,1),(1053,2,55,3,52,1,1),(1054,2,47,3,43,1,1),(1055,2,47,3,44,1,1),(1056,2,47,3,45,1,1),(1057,2,47,3,46,1,1),(1058,2,47,3,47,1,1),(1059,2,47,3,48,1,1),(1060,2,47,3,49,1,1),(1061,2,47,3,50,1,1),(1062,2,47,3,51,1,1),(1063,2,47,3,52,1,1),(1064,2,43,3,43,1,1),(1065,2,43,3,44,1,1),(1066,2,43,3,45,1,1),(1067,2,43,3,46,1,1),(1068,2,43,3,47,1,1),(1069,2,43,3,48,1,1),(1070,2,43,3,49,1,1),(1071,2,43,3,50,1,1),(1072,2,43,3,51,1,1),(1073,2,43,3,52,1,1),(1074,2,42,3,43,1,1),(1075,2,42,3,44,1,1),(1076,2,42,3,45,1,1),(1077,2,42,3,46,1,1),(1078,2,42,3,47,1,1),(1079,2,42,3,48,1,1),(1080,2,42,3,49,1,1),(1081,2,42,3,50,1,1),(1082,2,42,3,51,1,1),(1083,2,42,3,52,1,1),(1084,2,45,3,43,1,1),(1085,2,45,3,44,1,1),(1086,2,45,3,45,1,1),(1087,2,45,3,46,1,1),(1088,2,45,3,47,1,1),(1089,2,45,3,48,1,1),(1090,2,45,3,49,1,1),(1091,2,45,3,50,1,1),(1092,2,45,3,51,1,1),(1093,2,45,3,52,1,1),(1094,2,49,3,43,1,1),(1095,2,49,3,44,1,1),(1096,2,49,3,45,1,1),(1097,2,49,3,46,1,1),(1098,2,49,3,47,1,1),(1099,2,49,3,48,1,1),(1100,2,49,3,49,1,1),(1101,2,49,3,50,1,1),(1102,2,49,3,51,1,1),(1103,2,49,3,52,1,1),(1104,2,44,3,43,1,1),(1105,2,44,3,44,1,1),(1106,2,44,3,45,1,1),(1107,2,44,3,46,1,1),(1108,2,44,3,47,1,1),(1109,2,44,3,48,1,1),(1110,2,44,3,49,1,1),(1111,2,44,3,50,1,1),(1112,2,44,3,51,1,1),(1113,2,44,3,52,1,1),(1114,2,37,3,43,1,1),(1115,2,37,3,44,1,1),(1116,2,37,3,45,1,1),(1117,2,37,3,46,1,1),(1118,2,37,3,47,1,1),(1119,2,37,3,48,1,1),(1120,2,37,3,49,1,1),(1121,2,37,3,50,1,1),(1122,2,37,3,51,1,1),(1123,2,37,3,52,1,1),(1124,2,40,3,43,1,1),(1125,2,40,3,44,1,1),(1126,2,40,3,45,1,1),(1127,2,40,3,46,1,1),(1128,2,40,3,47,1,1),(1129,2,40,3,48,1,1),(1130,2,40,3,49,1,1),(1131,2,40,3,50,1,1),(1132,2,40,3,51,1,1),(1133,2,40,3,52,1,1),(1134,2,39,3,43,1,1),(1135,2,39,3,44,1,1),(1136,2,39,3,45,1,1),(1137,2,39,3,46,1,1),(1138,2,39,3,47,1,1),(1139,2,39,3,48,1,1),(1140,2,39,3,49,1,1),(1141,2,39,3,50,1,1),(1142,2,39,3,51,1,1),(1143,2,39,3,52,1,1),(1144,2,38,3,43,1,1),(1145,2,38,3,44,1,1),(1146,2,38,3,45,1,1),(1147,2,38,3,46,1,1),(1148,2,38,3,47,1,1),(1149,2,38,3,48,1,1),(1150,2,38,3,49,1,1),(1151,2,38,3,50,1,1),(1152,2,38,3,51,1,1),(1153,2,38,3,52,1,1),(1154,2,36,3,43,1,1),(1155,2,36,3,44,1,1),(1156,2,36,3,45,1,1),(1157,2,36,3,46,1,1),(1158,2,36,3,47,1,1),(1159,2,36,3,48,1,1),(1160,2,36,3,49,1,1),(1161,2,36,3,50,1,1),(1162,2,36,3,51,1,1),(1163,2,36,3,52,1,1),(1164,2,41,3,43,1,1),(1165,2,41,3,44,1,1),(1166,2,41,3,45,1,1),(1167,2,41,3,46,0,1),(1168,2,41,3,47,1,1),(1169,2,41,3,48,0,1),(1170,2,41,3,49,0,1),(1171,2,41,3,50,0,1),(1172,2,41,3,51,1,1),(1173,2,41,3,52,1,1),(1174,2,17,1,1,1,1),(1175,2,17,1,2,1,1),(1176,2,17,1,3,1,1),(1177,2,17,1,4,1,1),(1178,2,17,1,5,1,1),(1179,2,17,1,6,1,1),(1180,2,17,1,7,1,1),(1181,2,17,1,8,1,1),(1182,2,17,1,9,1,1),(1183,2,17,1,10,0,1),(1184,2,17,1,11,0,1),(1185,2,17,1,12,0,1),(1186,2,17,1,13,0,1),(1187,2,17,1,14,0,1),(1188,2,17,1,15,0,1),(1189,2,17,1,16,1,1),(1190,2,17,1,17,1,1),(1191,2,17,1,18,1,1),(1192,2,17,1,19,1,1),(1193,2,17,1,20,1,1),(1194,2,17,1,21,1,1),(1195,2,17,1,22,1,1),(1196,2,17,1,23,1,1),(1197,2,17,1,24,1,1),(1198,2,17,1,25,1,1),(1199,2,17,1,26,1,1),(1200,2,17,1,27,1,1),(1201,2,17,1,28,1,1),(1202,2,17,1,29,1,1),(1203,2,17,1,30,1,1),(1204,2,17,1,31,1,1),(1205,2,17,1,32,1,1),(1206,2,16,1,1,1,1),(1207,2,16,1,2,1,1),(1208,2,16,1,3,1,1),(1209,2,16,1,4,1,1),(1210,2,16,1,5,1,1),(1211,2,16,1,6,1,1),(1212,2,16,1,7,1,1),(1213,2,16,1,8,1,1),(1214,2,16,1,9,1,1),(1215,2,16,1,10,0,1),(1216,2,16,1,11,0,1),(1217,2,16,1,12,0,1),(1218,2,16,1,13,0,1),(1219,2,16,1,14,0,1),(1220,2,16,1,15,0,1),(1221,2,16,1,16,1,1),(1222,2,16,1,17,1,1),(1223,2,16,1,18,1,1),(1224,2,16,1,19,1,1),(1225,2,16,1,20,1,1),(1226,2,16,1,21,1,1),(1227,2,16,1,22,1,1),(1228,2,16,1,23,1,1),(1229,2,16,1,24,1,1),(1230,2,16,1,25,1,1),(1231,2,16,1,26,1,1),(1232,2,16,1,27,1,1),(1233,2,16,1,28,1,1),(1234,2,16,1,29,1,1),(1235,2,16,1,30,1,1),(1236,2,16,1,31,1,1),(1237,2,16,1,32,1,1),(1238,2,15,1,1,1,1),(1239,2,15,1,2,1,1),(1240,2,15,1,3,1,1),(1241,2,15,1,4,1,1),(1242,2,15,1,5,1,1),(1243,2,15,1,6,1,1),(1244,2,15,1,7,1,1),(1245,2,15,1,8,1,1),(1246,2,15,1,9,1,1),(1247,2,15,1,10,0,1),(1248,2,15,1,11,0,1),(1249,2,15,1,12,0,1),(1250,2,15,1,13,0,1),(1251,2,15,1,14,0,1),(1252,2,15,1,15,0,1),(1253,2,15,1,16,1,1),(1254,2,15,1,17,1,1),(1255,2,15,1,18,1,1),(1256,2,15,1,19,1,1),(1257,2,15,1,20,1,1),(1258,2,15,1,21,1,1),(1259,2,15,1,22,1,1),(1260,2,15,1,23,1,1),(1261,2,15,1,24,1,1),(1262,2,15,1,25,1,1),(1263,2,15,1,26,1,1),(1264,2,15,1,27,1,1),(1265,2,15,1,28,1,1),(1266,2,15,1,29,1,1),(1267,2,15,1,30,1,1),(1268,2,15,1,31,1,1),(1269,2,15,1,32,1,1),(1270,2,13,1,1,1,1),(1271,2,13,1,2,1,1),(1272,2,13,1,3,1,1),(1273,2,13,1,4,1,1),(1274,2,13,1,5,1,1),(1275,2,13,1,6,1,1),(1276,2,13,1,7,1,1),(1277,2,13,1,8,1,1),(1278,2,13,1,9,1,1),(1279,2,13,1,10,0,1),(1280,2,13,1,11,0,1),(1281,2,13,1,12,0,1),(1282,2,13,1,13,0,1),(1283,2,13,1,14,0,1),(1284,2,13,1,15,0,1),(1285,2,13,1,16,1,1),(1286,2,13,1,17,1,1),(1287,2,13,1,18,1,1),(1288,2,13,1,19,1,1),(1289,2,13,1,20,1,1),(1290,2,13,1,21,1,1),(1291,2,13,1,22,1,1),(1292,2,13,1,23,1,1),(1293,2,13,1,24,1,1),(1294,2,13,1,25,1,1),(1295,2,13,1,26,1,1),(1296,2,13,1,27,1,1),(1297,2,13,1,28,1,1),(1298,2,13,1,29,1,1),(1299,2,13,1,30,1,1),(1300,2,13,1,31,1,1),(1301,2,13,1,32,1,1),(1302,2,14,1,1,1,1),(1303,2,14,1,2,1,1),(1304,2,14,1,3,1,1),(1305,2,14,1,4,1,1),(1306,2,14,1,5,1,1),(1307,2,14,1,6,1,1),(1308,2,14,1,7,1,1),(1309,2,14,1,8,1,1),(1310,2,14,1,9,1,1),(1311,2,14,1,10,0,1),(1312,2,14,1,11,0,1),(1313,2,14,1,12,0,1),(1314,2,14,1,13,0,1),(1315,2,14,1,14,0,1),(1316,2,14,1,15,0,1),(1317,2,14,1,16,1,1),(1318,2,14,1,17,1,1),(1319,2,14,1,18,1,1),(1320,2,14,1,19,1,1),(1321,2,14,1,20,1,1),(1322,2,14,1,21,1,1),(1323,2,14,1,22,1,1),(1324,2,14,1,23,1,1),(1325,2,14,1,24,1,1),(1326,2,14,1,25,1,1),(1327,2,14,1,26,1,1),(1328,2,14,1,27,1,1),(1329,2,14,1,28,1,1),(1330,2,14,1,29,1,1),(1331,2,14,1,30,1,1),(1332,2,14,1,31,1,1),(1333,2,14,1,32,1,1),(1334,2,11,1,1,1,1),(1335,2,11,1,2,1,1),(1336,2,11,1,3,1,1),(1337,2,11,1,4,1,1),(1338,2,11,1,5,1,1),(1339,2,11,1,6,1,1),(1340,2,11,1,7,1,1),(1341,2,11,1,8,1,1),(1342,2,11,1,9,1,1),(1343,2,11,1,10,0,1),(1344,2,11,1,11,0,1),(1345,2,11,1,12,0,1),(1346,2,11,1,13,0,1),(1347,2,11,1,14,0,1),(1348,2,11,1,15,0,1),(1349,2,11,1,16,1,1),(1350,2,11,1,17,1,1),(1351,2,11,1,18,1,1),(1352,2,11,1,19,1,1),(1353,2,11,1,20,1,1),(1354,2,11,1,21,1,1),(1355,2,11,1,22,1,1),(1356,2,11,1,23,1,1),(1357,2,11,1,24,1,1),(1358,2,11,1,25,1,1),(1359,2,11,1,26,1,1),(1360,2,11,1,27,1,1),(1361,2,11,1,28,1,1),(1362,2,11,1,29,1,1),(1363,2,11,1,30,1,1),(1364,2,11,1,31,1,1),(1365,2,11,1,32,1,1),(1366,2,2,1,1,1,1),(1367,2,2,1,2,1,1),(1368,2,2,1,3,1,1),(1369,2,2,1,4,1,1),(1370,2,2,1,5,1,1),(1371,2,2,1,6,1,1),(1372,2,2,1,7,1,1),(1373,2,2,1,8,1,1),(1374,2,2,1,9,1,1),(1375,2,2,1,10,0,1),(1376,2,2,1,11,0,1),(1377,2,2,1,12,0,1),(1378,2,2,1,13,0,1),(1379,2,2,1,14,0,1),(1380,2,2,1,15,0,1),(1381,2,2,1,16,1,1),(1382,2,2,1,17,1,1),(1383,2,2,1,18,1,1),(1384,2,2,1,19,1,1),(1385,2,2,1,20,1,1),(1386,2,2,1,21,1,1),(1387,2,2,1,22,1,1),(1388,2,2,1,23,1,1),(1389,2,2,1,24,1,1),(1390,2,2,1,25,1,1),(1391,2,2,1,26,1,1),(1392,2,2,1,27,1,1),(1393,2,2,1,28,1,1),(1394,2,2,1,29,1,1),(1395,2,2,1,30,1,1),(1396,2,2,1,31,1,1),(1397,2,2,1,32,1,1),(1398,2,1,1,1,1,1),(1399,2,1,1,2,1,1),(1400,2,1,1,3,1,1),(1401,2,1,1,4,1,1),(1402,2,1,1,5,1,1),(1403,2,1,1,6,1,1),(1404,2,1,1,7,1,1),(1405,2,1,1,8,1,1),(1406,2,1,1,9,1,1),(1407,2,1,1,10,0,1),(1408,2,1,1,11,0,1),(1409,2,1,1,12,0,1),(1410,2,1,1,13,0,1),(1411,2,1,1,14,0,1),(1412,2,1,1,15,0,1),(1413,2,1,1,16,1,1),(1414,2,1,1,17,1,1),(1415,2,1,1,18,1,1),(1416,2,1,1,19,1,1),(1417,2,1,1,20,1,1),(1418,2,1,1,21,1,1),(1419,2,1,1,22,1,1),(1420,2,1,1,23,1,1),(1421,2,1,1,24,1,1),(1422,2,1,1,25,1,1),(1423,2,1,1,26,1,1),(1424,2,1,1,27,1,1),(1425,2,1,1,28,1,1),(1426,2,1,1,29,1,1),(1427,2,1,1,30,1,1),(1428,2,1,1,31,1,1),(1429,2,1,1,32,1,1),(1430,2,8,1,1,1,1),(1431,2,8,1,2,1,1),(1432,2,8,1,3,1,1),(1433,2,8,1,4,1,1),(1434,2,8,1,5,1,1),(1435,2,8,1,6,1,1),(1436,2,8,1,7,1,1),(1437,2,8,1,8,1,1),(1438,2,8,1,9,1,1),(1439,2,8,1,10,0,1),(1440,2,8,1,11,0,1),(1441,2,8,1,12,0,1),(1442,2,8,1,13,0,1),(1443,2,8,1,14,0,1),(1444,2,8,1,15,0,1),(1445,2,8,1,16,1,1),(1446,2,8,1,17,1,1),(1447,2,8,1,18,1,1),(1448,2,8,1,19,1,1),(1449,2,8,1,20,1,1),(1450,2,8,1,21,1,1),(1451,2,8,1,22,1,1),(1452,2,8,1,23,1,1),(1453,2,8,1,24,1,1),(1454,2,8,1,25,1,1),(1455,2,8,1,26,1,1),(1456,2,8,1,27,1,1),(1457,2,8,1,28,1,1),(1458,2,8,1,29,1,1),(1459,2,8,1,30,1,1),(1460,2,8,1,31,1,1),(1461,2,8,1,32,1,1),(1462,2,6,1,1,1,1),(1463,2,6,1,2,1,1),(1464,2,6,1,3,1,1),(1465,2,6,1,4,1,1),(1466,2,6,1,5,1,1),(1467,2,6,1,6,1,1),(1468,2,6,1,7,1,1),(1469,2,6,1,8,1,1),(1470,2,6,1,9,1,1),(1471,2,6,1,10,0,1),(1472,2,6,1,11,0,1),(1473,2,6,1,12,0,1),(1474,2,6,1,13,0,1),(1475,2,6,1,14,0,1),(1476,2,6,1,15,0,1),(1477,2,6,1,16,1,1),(1478,2,6,1,17,1,1),(1479,2,6,1,18,1,1),(1480,2,6,1,19,1,1),(1481,2,6,1,20,1,1),(1482,2,6,1,21,1,1),(1483,2,6,1,22,1,1),(1484,2,6,1,23,1,1),(1485,2,6,1,24,1,1),(1486,2,6,1,25,1,1),(1487,2,6,1,26,1,1),(1488,2,6,1,27,1,1),(1489,2,6,1,28,1,1),(1490,2,6,1,29,1,1),(1491,2,6,1,30,1,1),(1492,2,6,1,31,1,1),(1493,2,6,1,32,1,1),(1494,2,4,1,1,1,1),(1495,2,4,1,2,1,1),(1496,2,4,1,3,1,1),(1497,2,4,1,4,1,1),(1498,2,4,1,5,1,1),(1499,2,4,1,6,1,1),(1500,2,4,1,7,1,1),(1501,2,4,1,8,1,1),(1502,2,4,1,9,1,1),(1503,2,4,1,10,0,1),(1504,2,4,1,11,0,1),(1505,2,4,1,12,0,1),(1506,2,4,1,13,0,1),(1507,2,4,1,14,0,1),(1508,2,4,1,15,0,1),(1509,2,4,1,16,1,1),(1510,2,4,1,17,1,1),(1511,2,4,1,18,1,1),(1512,2,4,1,19,1,1),(1513,2,4,1,20,1,1),(1514,2,4,1,21,1,1),(1515,2,4,1,22,1,1),(1516,2,4,1,23,1,1),(1517,2,4,1,24,1,1),(1518,2,4,1,25,1,1),(1519,2,4,1,26,1,1),(1520,2,4,1,27,1,1),(1521,2,4,1,28,1,1),(1522,2,4,1,29,1,1),(1523,2,4,1,30,1,1),(1524,2,4,1,31,1,1),(1525,2,4,1,32,1,1),(1526,2,9,1,1,1,1),(1527,2,9,1,2,1,1),(1528,2,9,1,3,1,1),(1529,2,9,1,4,1,1),(1530,2,9,1,5,1,1),(1531,2,9,1,6,1,1),(1532,2,9,1,7,1,1),(1533,2,9,1,8,1,1),(1534,2,9,1,9,1,1),(1535,2,9,1,10,0,1),(1536,2,9,1,11,0,1),(1537,2,9,1,12,0,1),(1538,2,9,1,13,0,1),(1539,2,9,1,14,0,1),(1540,2,9,1,15,0,1),(1541,2,9,1,16,1,1),(1542,2,9,1,17,1,1),(1543,2,9,1,18,1,1),(1544,2,9,1,19,1,1),(1545,2,9,1,20,1,1),(1546,2,9,1,21,1,1),(1547,2,9,1,22,1,1),(1548,2,9,1,23,1,1),(1549,2,9,1,24,1,1),(1550,2,9,1,25,1,1),(1551,2,9,1,26,1,1),(1552,2,9,1,27,1,1),(1553,2,9,1,28,1,1),(1554,2,9,1,29,1,1),(1555,2,9,1,30,1,1),(1556,2,9,1,31,1,1),(1557,2,9,1,32,1,1),(1558,2,10,1,1,1,1),(1559,2,10,1,2,1,1),(1560,2,10,1,3,1,1),(1561,2,10,1,4,1,1),(1562,2,10,1,5,1,1),(1563,2,10,1,6,1,1),(1564,2,10,1,7,1,1),(1565,2,10,1,8,1,1),(1566,2,10,1,9,1,1),(1567,2,10,1,10,0,1),(1568,2,10,1,11,0,1),(1569,2,10,1,12,0,1),(1570,2,10,1,13,0,1),(1571,2,10,1,14,0,1),(1572,2,10,1,15,0,1),(1573,2,10,1,16,1,1),(1574,2,10,1,17,1,1),(1575,2,10,1,18,1,1),(1576,2,10,1,19,1,1),(1577,2,10,1,20,1,1),(1578,2,10,1,21,1,1),(1579,2,10,1,22,1,1),(1580,2,10,1,23,1,1),(1581,2,10,1,24,1,1),(1582,2,10,1,25,1,1),(1583,2,10,1,26,1,1),(1584,2,10,1,27,1,1),(1585,2,10,1,28,1,1),(1586,2,10,1,29,1,1),(1587,2,10,1,30,1,1),(1588,2,10,1,31,1,1),(1589,2,10,1,32,1,1),(1590,2,3,1,1,1,1),(1591,2,3,1,2,1,1),(1592,2,3,1,3,1,1),(1593,2,3,1,4,1,1),(1594,2,3,1,5,1,1),(1595,2,3,1,6,1,1),(1596,2,3,1,7,1,1),(1597,2,3,1,8,1,1),(1598,2,3,1,9,1,1),(1599,2,3,1,10,0,1),(1600,2,3,1,11,0,1),(1601,2,3,1,12,0,1),(1602,2,3,1,13,0,1),(1603,2,3,1,14,0,1),(1604,2,3,1,15,0,1),(1605,2,3,1,16,1,1),(1606,2,3,1,17,1,1),(1607,2,3,1,18,1,1),(1608,2,3,1,19,1,1),(1609,2,3,1,20,1,1),(1610,2,3,1,21,1,1),(1611,2,3,1,22,1,1),(1612,2,3,1,23,1,1),(1613,2,3,1,24,1,1),(1614,2,3,1,25,1,1),(1615,2,3,1,26,1,1),(1616,2,3,1,27,1,1),(1617,2,3,1,28,1,1),(1618,2,3,1,29,1,1),(1619,2,3,1,30,1,1),(1620,2,3,1,31,1,1),(1621,2,3,1,32,1,1),(1622,2,7,1,1,1,1),(1623,2,7,1,2,1,1),(1624,2,7,1,3,1,1),(1625,2,7,1,4,1,1),(1626,2,7,1,5,1,1),(1627,2,7,1,6,1,1),(1628,2,7,1,7,1,1),(1629,2,7,1,8,1,1),(1630,2,7,1,9,1,1),(1631,2,7,1,10,0,1),(1632,2,7,1,11,0,1),(1633,2,7,1,12,0,1),(1634,2,7,1,13,0,1),(1635,2,7,1,14,0,1),(1636,2,7,1,15,0,1),(1637,2,7,1,16,1,1),(1638,2,7,1,17,1,1),(1639,2,7,1,18,1,1),(1640,2,7,1,19,1,1),(1641,2,7,1,20,1,1),(1642,2,7,1,21,1,1),(1643,2,7,1,22,1,1),(1644,2,7,1,23,1,1),(1645,2,7,1,24,1,1),(1646,2,7,1,25,1,1),(1647,2,7,1,26,1,1),(1648,2,7,1,27,1,1),(1649,2,7,1,28,1,1),(1650,2,7,1,29,1,1),(1651,2,7,1,30,1,1),(1652,2,7,1,31,1,1),(1653,2,7,1,32,1,1),(1654,2,12,1,1,1,1),(1655,2,12,1,2,1,1),(1656,2,12,1,3,1,1),(1657,2,12,1,4,1,1),(1658,2,12,1,5,1,1),(1659,2,12,1,6,1,1),(1660,2,12,1,7,1,1),(1661,2,12,1,8,1,1),(1662,2,12,1,9,1,1),(1663,2,12,1,10,0,1),(1664,2,12,1,11,0,1),(1665,2,12,1,12,0,1),(1666,2,12,1,13,0,1),(1667,2,12,1,14,0,1),(1668,2,12,1,15,0,1),(1669,2,12,1,16,1,1),(1670,2,12,1,17,1,1),(1671,2,12,1,18,1,1),(1672,2,12,1,19,1,1),(1673,2,12,1,20,1,1),(1674,2,12,1,21,1,1),(1675,2,12,1,22,1,1),(1676,2,12,1,23,1,1),(1677,2,12,1,24,1,1),(1678,2,12,1,25,1,1),(1679,2,12,1,26,1,1),(1680,2,12,1,27,1,1),(1681,2,12,1,28,1,1),(1682,2,12,1,29,1,1),(1683,2,12,1,30,1,1),(1684,2,12,1,31,1,1),(1685,2,12,1,32,1,1),(1686,2,60,4,53,1,1),(1687,2,60,4,54,1,1),(1688,2,60,4,55,1,1),(1689,2,60,4,56,1,1),(1690,2,60,4,57,1,1),(1691,2,60,4,58,1,1),(1692,2,60,4,59,1,1),(1693,2,60,4,60,1,1),(1694,2,60,4,61,1,1),(1695,2,60,4,62,1,1),(1696,2,60,4,63,1,1),(1697,2,60,4,64,1,1),(1698,2,60,4,65,1,1),(1699,2,60,4,66,1,1),(1700,2,60,4,67,1,1),(1701,2,60,4,68,1,1),(1702,2,56,4,53,1,1),(1703,2,56,4,54,1,1),(1704,2,56,4,55,1,1),(1705,2,56,4,56,1,1),(1706,2,56,4,57,1,1),(1707,2,56,4,58,1,1),(1708,2,56,4,59,1,1),(1709,2,56,4,60,1,1),(1710,2,56,4,61,1,1),(1711,2,56,4,62,1,1),(1712,2,56,4,63,1,1),(1713,2,56,4,64,1,1),(1714,2,56,4,65,1,1),(1715,2,56,4,66,1,1),(1716,2,56,4,67,1,1),(1717,2,56,4,68,1,1),(1718,2,57,4,53,1,1),(1719,2,57,4,54,1,1),(1720,2,57,4,55,1,1),(1721,2,57,4,56,1,1),(1722,2,57,4,57,1,1),(1723,2,57,4,58,1,1),(1724,2,57,4,59,1,1),(1725,2,57,4,60,1,1),(1726,2,57,4,61,1,1),(1727,2,57,4,62,1,1),(1728,2,57,4,63,1,1),(1729,2,57,4,64,1,1),(1730,2,57,4,65,1,1),(1731,2,57,4,66,1,1),(1732,2,57,4,67,1,1),(1733,2,57,4,68,1,1),(1734,2,58,4,53,1,1),(1735,2,58,4,54,1,1),(1736,2,58,4,55,1,1),(1737,2,58,4,56,1,1),(1738,2,58,4,57,1,1),(1739,2,58,4,58,1,1),(1740,2,58,4,59,1,1),(1741,2,58,4,60,1,1),(1742,2,58,4,61,1,1),(1743,2,58,4,62,1,1),(1744,2,58,4,63,1,1),(1745,2,58,4,64,1,1),(1746,2,58,4,65,1,1),(1747,2,58,4,66,1,1),(1748,2,58,4,67,1,1),(1749,2,58,4,68,1,1),(1750,2,59,4,53,1,1),(1751,2,59,4,54,1,1),(1752,2,59,4,55,1,1),(1753,2,59,4,56,1,1),(1754,2,59,4,57,1,1),(1755,2,59,4,58,1,1),(1756,2,59,4,59,1,1),(1757,2,59,4,60,1,1),(1758,2,59,4,61,1,1),(1759,2,59,4,62,1,1),(1760,2,59,4,63,1,1),(1761,2,59,4,64,1,1),(1762,2,59,4,65,1,1),(1763,2,59,4,66,1,1),(1764,2,59,4,67,1,1),(1765,2,59,4,68,1,1),(1766,2,31,2,33,1,1),(1767,2,31,2,34,1,1),(1768,2,31,2,35,1,1),(1769,2,31,2,36,1,1),(1770,2,31,2,37,1,1),(1771,2,31,2,38,0,1),(1772,2,31,2,39,0,1),(1773,2,31,2,40,0,1),(1774,2,31,2,41,1,1),(1775,2,31,2,42,1,1),(1776,2,28,2,33,1,1),(1777,2,28,2,34,1,1),(1778,2,28,2,35,1,1),(1779,2,28,2,36,1,1),(1780,2,28,2,37,1,1),(1781,2,28,2,38,0,1),(1782,2,28,2,39,0,1),(1783,2,28,2,40,0,1),(1784,2,28,2,41,1,1),(1785,2,28,2,42,1,1),(1786,2,29,2,33,1,1),(1787,2,29,2,34,1,1),(1788,2,29,2,35,1,1),(1789,2,29,2,36,1,1),(1790,2,29,2,37,1,1),(1791,2,29,2,38,0,1),(1792,2,29,2,39,0,1),(1793,2,29,2,40,0,1),(1794,2,29,2,41,1,1),(1795,2,29,2,42,1,1),(1796,2,25,2,33,1,1),(1797,2,25,2,34,1,1),(1798,2,25,2,35,1,1),(1799,2,25,2,36,1,1),(1800,2,25,2,37,1,1),(1801,2,25,2,38,0,1),(1802,2,25,2,39,0,1),(1803,2,25,2,40,0,1),(1804,2,25,2,41,1,1),(1805,2,25,2,42,1,1),(1806,2,26,2,33,1,1),(1807,2,26,2,34,1,1),(1808,2,26,2,35,1,1),(1809,2,26,2,36,1,1),(1810,2,26,2,37,1,1),(1811,2,26,2,38,0,1),(1812,2,26,2,39,0,1),(1813,2,26,2,40,0,1),(1814,2,26,2,41,1,1),(1815,2,26,2,42,1,1),(1816,2,27,2,33,1,1),(1817,2,27,2,34,1,1),(1818,2,27,2,35,1,1),(1819,2,27,2,36,1,1),(1820,2,27,2,37,1,1),(1821,2,27,2,38,0,1),(1822,2,27,2,39,0,1),(1823,2,27,2,40,0,1),(1824,2,27,2,41,1,1),(1825,2,27,2,42,1,1),(1826,2,30,2,33,1,1),(1827,2,30,2,34,1,1),(1828,2,30,2,35,1,1),(1829,2,30,2,36,1,1),(1830,2,30,2,37,1,1),(1831,2,30,2,38,0,1),(1832,2,30,2,39,0,1),(1833,2,30,2,40,0,1),(1834,2,30,2,41,1,1),(1835,2,30,2,42,1,1),(1836,2,23,2,33,1,1),(1837,2,23,2,34,1,1),(1838,2,23,2,35,1,1),(1839,2,23,2,36,1,1),(1840,2,23,2,37,1,1),(1841,2,23,2,38,0,1),(1842,2,23,2,39,0,1),(1843,2,23,2,40,0,1),(1844,2,23,2,41,1,1),(1845,2,23,2,42,1,1),(1846,2,24,2,33,1,1),(1847,2,24,2,34,1,1),(1848,2,24,2,35,1,1),(1849,2,24,2,36,1,1),(1850,2,24,2,37,1,1),(1851,2,24,2,38,0,1),(1852,2,24,2,39,0,1),(1853,2,24,2,40,0,1),(1854,2,24,2,41,1,1),(1855,2,24,2,42,1,1),(1856,2,22,2,33,1,1),(1857,2,22,2,34,1,1),(1858,2,22,2,35,1,1),(1859,2,22,2,36,1,1),(1860,2,22,2,37,1,1),(1861,2,22,2,38,0,1),(1862,2,22,2,39,0,1),(1863,2,22,2,40,0,1),(1864,2,22,2,41,1,1),(1865,2,22,2,42,1,1),(2047,3,50,3,43,1,1),(2048,3,50,3,44,1,1),(2049,3,50,3,45,1,1),(2050,3,50,3,46,1,1),(2051,3,50,3,47,1,1),(2052,3,50,3,48,1,1),(2053,3,50,3,49,1,1),(2054,3,50,3,50,1,1),(2055,3,50,3,51,1,1),(2056,3,50,3,52,1,1),(2057,3,48,3,43,1,1),(2058,3,48,3,44,1,1),(2059,3,48,3,45,1,1),(2060,3,48,3,46,1,1),(2061,3,48,3,47,1,1),(2062,3,48,3,48,1,1),(2063,3,48,3,49,1,1),(2064,3,48,3,50,1,1),(2065,3,48,3,51,1,1),(2066,3,48,3,52,1,1),(2067,3,55,3,43,1,1),(2068,3,55,3,44,1,1),(2069,3,55,3,45,1,1),(2070,3,55,3,46,1,1),(2071,3,55,3,47,1,1),(2072,3,55,3,48,1,1),(2073,3,55,3,49,1,1),(2074,3,55,3,50,1,1),(2075,3,55,3,51,1,1),(2076,3,55,3,52,1,1),(2077,3,47,3,43,1,1),(2078,3,47,3,44,1,1),(2079,3,47,3,45,1,1),(2080,3,47,3,46,1,1),(2081,3,47,3,47,1,1),(2082,3,47,3,48,1,1),(2083,3,47,3,49,1,1),(2084,3,47,3,50,1,1),(2085,3,47,3,51,1,1),(2086,3,47,3,52,1,1),(2087,3,43,3,43,1,1),(2088,3,43,3,44,1,1),(2089,3,43,3,45,1,1),(2090,3,43,3,46,1,1),(2091,3,43,3,47,1,1),(2092,3,43,3,48,1,1),(2093,3,43,3,49,1,1),(2094,3,43,3,50,1,1),(2095,3,43,3,51,1,1),(2096,3,43,3,52,1,1),(2097,3,42,3,43,1,1),(2098,3,42,3,44,1,1),(2099,3,42,3,45,1,1),(2100,3,42,3,46,1,1),(2101,3,42,3,47,1,1),(2102,3,42,3,48,1,1),(2103,3,42,3,49,1,1),(2104,3,42,3,50,1,1),(2105,3,42,3,51,1,1),(2106,3,42,3,52,1,1),(2107,3,45,3,43,1,1),(2108,3,45,3,44,1,1),(2109,3,45,3,45,1,1),(2110,3,45,3,46,1,1),(2111,3,45,3,47,1,1),(2112,3,45,3,48,1,1),(2113,3,45,3,49,1,1),(2114,3,45,3,50,1,1),(2115,3,45,3,51,1,1),(2116,3,45,3,52,1,1),(2117,3,49,3,43,1,1),(2118,3,49,3,44,1,1),(2119,3,49,3,45,1,1),(2120,3,49,3,46,1,1),(2121,3,49,3,47,1,1),(2122,3,49,3,48,1,1),(2123,3,49,3,49,1,1),(2124,3,49,3,50,1,1),(2125,3,49,3,51,1,1),(2126,3,49,3,52,1,1),(2127,3,44,3,43,1,1),(2128,3,44,3,44,1,1),(2129,3,44,3,45,1,1),(2130,3,44,3,46,1,1),(2131,3,44,3,47,1,1),(2132,3,44,3,48,1,1),(2133,3,44,3,49,1,1),(2134,3,44,3,50,1,1),(2135,3,44,3,51,1,1),(2136,3,44,3,52,1,1),(2137,3,37,3,43,1,1),(2138,3,37,3,44,1,1),(2139,3,37,3,45,1,1),(2140,3,37,3,46,1,1),(2141,3,37,3,47,1,1),(2142,3,37,3,48,1,1),(2143,3,37,3,49,1,1),(2144,3,37,3,50,1,1),(2145,3,37,3,51,1,1),(2146,3,37,3,52,1,1),(2147,3,40,3,43,1,1),(2148,3,40,3,44,1,1),(2149,3,40,3,45,1,1),(2150,3,40,3,46,1,1),(2151,3,40,3,47,1,1),(2152,3,40,3,48,1,1),(2153,3,40,3,49,1,1),(2154,3,40,3,50,1,1),(2155,3,40,3,51,1,1),(2156,3,40,3,52,1,1),(2157,3,39,3,43,1,1),(2158,3,39,3,44,1,1),(2159,3,39,3,45,1,1),(2160,3,39,3,46,1,1),(2161,3,39,3,47,1,1),(2162,3,39,3,48,1,1),(2163,3,39,3,49,1,1),(2164,3,39,3,50,1,1),(2165,3,39,3,51,1,1),(2166,3,39,3,52,1,1),(2167,3,38,3,43,1,1),(2168,3,38,3,44,1,1),(2169,3,38,3,45,1,1),(2170,3,38,3,46,1,1),(2171,3,38,3,47,1,1),(2172,3,38,3,48,1,1),(2173,3,38,3,49,1,1),(2174,3,38,3,50,1,1),(2175,3,38,3,51,1,1),(2176,3,38,3,52,1,1),(2177,3,36,3,43,1,1),(2178,3,36,3,44,1,1),(2179,3,36,3,45,1,1),(2180,3,36,3,46,1,1),(2181,3,36,3,47,1,1),(2182,3,36,3,48,1,1),(2183,3,36,3,49,1,1),(2184,3,36,3,50,1,1),(2185,3,36,3,51,1,1),(2186,3,36,3,52,1,1),(2187,3,41,3,43,1,1),(2188,3,41,3,44,1,1),(2189,3,41,3,45,1,1),(2190,3,41,3,46,0,1),(2191,3,41,3,47,1,1),(2192,3,41,3,48,0,1),(2193,3,41,3,49,0,1),(2194,3,41,3,50,0,1),(2195,3,41,3,51,1,1),(2196,3,41,3,52,1,1),(2197,3,17,1,1,1,1),(2198,3,17,1,2,1,1),(2199,3,17,1,3,1,1),(2200,3,17,1,4,1,1),(2201,3,17,1,5,1,1),(2202,3,17,1,6,1,1),(2203,3,17,1,7,1,1),(2204,3,17,1,8,1,1),(2205,3,17,1,9,1,1),(2206,3,17,1,10,0,1),(2207,3,17,1,11,0,1),(2208,3,17,1,12,0,1),(2209,3,17,1,13,0,1),(2210,3,17,1,14,0,1),(2211,3,17,1,15,0,1),(2212,3,17,1,16,1,1),(2213,3,17,1,17,1,1),(2214,3,17,1,18,1,1),(2215,3,17,1,19,1,1),(2216,3,17,1,20,1,1),(2217,3,17,1,21,1,1),(2218,3,17,1,22,1,1),(2219,3,17,1,23,1,1),(2220,3,17,1,24,1,1),(2221,3,17,1,25,1,1),(2222,3,17,1,26,1,1),(2223,3,17,1,27,1,1),(2224,3,17,1,28,1,1),(2225,3,17,1,29,1,1),(2226,3,17,1,30,1,1),(2227,3,17,1,31,1,1),(2228,3,17,1,32,1,1),(2229,3,16,1,1,1,1),(2230,3,16,1,2,1,1),(2231,3,16,1,3,1,1),(2232,3,16,1,4,1,1),(2233,3,16,1,5,1,1),(2234,3,16,1,6,1,1),(2235,3,16,1,7,1,1),(2236,3,16,1,8,1,1),(2237,3,16,1,9,1,1),(2238,3,16,1,10,0,1),(2239,3,16,1,11,0,1),(2240,3,16,1,12,0,1),(2241,3,16,1,13,0,1),(2242,3,16,1,14,0,1),(2243,3,16,1,15,0,1),(2244,3,16,1,16,1,1),(2245,3,16,1,17,1,1),(2246,3,16,1,18,1,1),(2247,3,16,1,19,1,1),(2248,3,16,1,20,1,1),(2249,3,16,1,21,1,1),(2250,3,16,1,22,1,1),(2251,3,16,1,23,1,1),(2252,3,16,1,24,1,1),(2253,3,16,1,25,1,1),(2254,3,16,1,26,1,1),(2255,3,16,1,27,1,1),(2256,3,16,1,28,1,1),(2257,3,16,1,29,1,1),(2258,3,16,1,30,1,1),(2259,3,16,1,31,1,1),(2260,3,16,1,32,1,1),(2261,3,15,1,1,1,1),(2262,3,15,1,2,1,1),(2263,3,15,1,3,1,1),(2264,3,15,1,4,1,1),(2265,3,15,1,5,1,1),(2266,3,15,1,6,1,1),(2267,3,15,1,7,1,1),(2268,3,15,1,8,1,1),(2269,3,15,1,9,1,1),(2270,3,15,1,10,0,1),(2271,3,15,1,11,0,1),(2272,3,15,1,12,0,1),(2273,3,15,1,13,0,1),(2274,3,15,1,14,0,1),(2275,3,15,1,15,0,1),(2276,3,15,1,16,1,1),(2277,3,15,1,17,1,1),(2278,3,15,1,18,1,1),(2279,3,15,1,19,1,1),(2280,3,15,1,20,1,1),(2281,3,15,1,21,1,1),(2282,3,15,1,22,1,1),(2283,3,15,1,23,1,1),(2284,3,15,1,24,1,1),(2285,3,15,1,25,1,1),(2286,3,15,1,26,1,1),(2287,3,15,1,27,1,1),(2288,3,15,1,28,1,1),(2289,3,15,1,29,1,1),(2290,3,15,1,30,1,1),(2291,3,15,1,31,1,1),(2292,3,15,1,32,1,1),(2293,3,13,1,1,1,1),(2294,3,13,1,2,1,1),(2295,3,13,1,3,1,1),(2296,3,13,1,4,1,1),(2297,3,13,1,5,1,1),(2298,3,13,1,6,1,1),(2299,3,13,1,7,1,1),(2300,3,13,1,8,1,1),(2301,3,13,1,9,1,1),(2302,3,13,1,10,0,1),(2303,3,13,1,11,0,1),(2304,3,13,1,12,0,1),(2305,3,13,1,13,0,1),(2306,3,13,1,14,0,1),(2307,3,13,1,15,0,1),(2308,3,13,1,16,1,1),(2309,3,13,1,17,1,1),(2310,3,13,1,18,1,1),(2311,3,13,1,19,1,1),(2312,3,13,1,20,1,1),(2313,3,13,1,21,1,1),(2314,3,13,1,22,1,1),(2315,3,13,1,23,1,1),(2316,3,13,1,24,1,1),(2317,3,13,1,25,1,1),(2318,3,13,1,26,1,1),(2319,3,13,1,27,1,1),(2320,3,13,1,28,1,1),(2321,3,13,1,29,1,1),(2322,3,13,1,30,1,1),(2323,3,13,1,31,1,1),(2324,3,13,1,32,1,1),(2325,3,14,1,1,1,1),(2326,3,14,1,2,1,1),(2327,3,14,1,3,1,1),(2328,3,14,1,4,1,1),(2329,3,14,1,5,1,1),(2330,3,14,1,6,1,1),(2331,3,14,1,7,1,1),(2332,3,14,1,8,1,1),(2333,3,14,1,9,1,1),(2334,3,14,1,10,0,1),(2335,3,14,1,11,0,1),(2336,3,14,1,12,0,1),(2337,3,14,1,13,0,1),(2338,3,14,1,14,0,1),(2339,3,14,1,15,0,1),(2340,3,14,1,16,1,1),(2341,3,14,1,17,1,1),(2342,3,14,1,18,1,1),(2343,3,14,1,19,1,1),(2344,3,14,1,20,1,1),(2345,3,14,1,21,1,1),(2346,3,14,1,22,1,1),(2347,3,14,1,23,1,1),(2348,3,14,1,24,1,1),(2349,3,14,1,25,1,1),(2350,3,14,1,26,1,1),(2351,3,14,1,27,1,1),(2352,3,14,1,28,1,1),(2353,3,14,1,29,1,1),(2354,3,14,1,30,1,1),(2355,3,14,1,31,1,1),(2356,3,14,1,32,1,1),(2357,3,11,1,1,1,1),(2358,3,11,1,2,1,1),(2359,3,11,1,3,1,1),(2360,3,11,1,4,1,1),(2361,3,11,1,5,1,1),(2362,3,11,1,6,1,1),(2363,3,11,1,7,1,1),(2364,3,11,1,8,1,1),(2365,3,11,1,9,1,1),(2366,3,11,1,10,0,1),(2367,3,11,1,11,0,1),(2368,3,11,1,12,0,1),(2369,3,11,1,13,0,1),(2370,3,11,1,14,0,1),(2371,3,11,1,15,0,1),(2372,3,11,1,16,1,1),(2373,3,11,1,17,1,1),(2374,3,11,1,18,1,1),(2375,3,11,1,19,1,1),(2376,3,11,1,20,1,1),(2377,3,11,1,21,1,1),(2378,3,11,1,22,1,1),(2379,3,11,1,23,1,1),(2380,3,11,1,24,1,1),(2381,3,11,1,25,1,1),(2382,3,11,1,26,1,1),(2383,3,11,1,27,1,1),(2384,3,11,1,28,1,1),(2385,3,11,1,29,1,1),(2386,3,11,1,30,1,1),(2387,3,11,1,31,1,1),(2388,3,11,1,32,1,1),(2389,3,2,1,1,1,1),(2390,3,2,1,2,1,1),(2391,3,2,1,3,1,1),(2392,3,2,1,4,1,1),(2393,3,2,1,5,1,1),(2394,3,2,1,6,1,1),(2395,3,2,1,7,1,1),(2396,3,2,1,8,1,1),(2397,3,2,1,9,1,1),(2398,3,2,1,10,0,1),(2399,3,2,1,11,0,1),(2400,3,2,1,12,0,1),(2401,3,2,1,13,0,1),(2402,3,2,1,14,0,1),(2403,3,2,1,15,0,1),(2404,3,2,1,16,1,1),(2405,3,2,1,17,1,1),(2406,3,2,1,18,1,1),(2407,3,2,1,19,1,1),(2408,3,2,1,20,1,1),(2409,3,2,1,21,1,1),(2410,3,2,1,22,1,1),(2411,3,2,1,23,1,1),(2412,3,2,1,24,1,1),(2413,3,2,1,25,1,1),(2414,3,2,1,26,1,1),(2415,3,2,1,27,1,1),(2416,3,2,1,28,1,1),(2417,3,2,1,29,1,1),(2418,3,2,1,30,1,1),(2419,3,2,1,31,1,1),(2420,3,2,1,32,1,1),(2421,3,1,1,1,1,1),(2422,3,1,1,2,1,1),(2423,3,1,1,3,1,1),(2424,3,1,1,4,1,1),(2425,3,1,1,5,1,1),(2426,3,1,1,6,1,1),(2427,3,1,1,7,1,1),(2428,3,1,1,8,1,1),(2429,3,1,1,9,1,1),(2430,3,1,1,10,0,1),(2431,3,1,1,11,0,1),(2432,3,1,1,12,0,1),(2433,3,1,1,13,0,1),(2434,3,1,1,14,0,1),(2435,3,1,1,15,0,1),(2436,3,1,1,16,1,1),(2437,3,1,1,17,1,1),(2438,3,1,1,18,1,1),(2439,3,1,1,19,1,1),(2440,3,1,1,20,1,1),(2441,3,1,1,21,1,1),(2442,3,1,1,22,1,1),(2443,3,1,1,23,1,1),(2444,3,1,1,24,1,1),(2445,3,1,1,25,1,1),(2446,3,1,1,26,1,1),(2447,3,1,1,27,1,1),(2448,3,1,1,28,1,1),(2449,3,1,1,29,1,1),(2450,3,1,1,30,1,1),(2451,3,1,1,31,1,1),(2452,3,1,1,32,1,1),(2453,3,8,1,1,1,1),(2454,3,8,1,2,1,1),(2455,3,8,1,3,1,1),(2456,3,8,1,4,1,1),(2457,3,8,1,5,1,1),(2458,3,8,1,6,1,1),(2459,3,8,1,7,1,1),(2460,3,8,1,8,1,1),(2461,3,8,1,9,1,1),(2462,3,8,1,10,0,1),(2463,3,8,1,11,0,1),(2464,3,8,1,12,0,1),(2465,3,8,1,13,0,1),(2466,3,8,1,14,0,1),(2467,3,8,1,15,0,1),(2468,3,8,1,16,1,1),(2469,3,8,1,17,1,1),(2470,3,8,1,18,1,1),(2471,3,8,1,19,1,1),(2472,3,8,1,20,1,1),(2473,3,8,1,21,1,1),(2474,3,8,1,22,1,1),(2475,3,8,1,23,1,1),(2476,3,8,1,24,1,1),(2477,3,8,1,25,1,1),(2478,3,8,1,26,1,1),(2479,3,8,1,27,1,1),(2480,3,8,1,28,1,1),(2481,3,8,1,29,1,1),(2482,3,8,1,30,1,1),(2483,3,8,1,31,1,1),(2484,3,8,1,32,1,1),(2485,3,6,1,1,1,1),(2486,3,6,1,2,1,1),(2487,3,6,1,3,1,1),(2488,3,6,1,4,1,1),(2489,3,6,1,5,1,1),(2490,3,6,1,6,1,1),(2491,3,6,1,7,1,1),(2492,3,6,1,8,1,1),(2493,3,6,1,9,1,1),(2494,3,6,1,10,0,1),(2495,3,6,1,11,0,1),(2496,3,6,1,12,0,1),(2497,3,6,1,13,0,1),(2498,3,6,1,14,0,1),(2499,3,6,1,15,0,1),(2500,3,6,1,16,1,1),(2501,3,6,1,17,1,1),(2502,3,6,1,18,1,1),(2503,3,6,1,19,1,1),(2504,3,6,1,20,1,1),(2505,3,6,1,21,1,1),(2506,3,6,1,22,1,1),(2507,3,6,1,23,1,1),(2508,3,6,1,24,1,1),(2509,3,6,1,25,1,1),(2510,3,6,1,26,1,1),(2511,3,6,1,27,1,1),(2512,3,6,1,28,1,1),(2513,3,6,1,29,1,1),(2514,3,6,1,30,1,1),(2515,3,6,1,31,1,1),(2516,3,6,1,32,1,1),(2517,3,4,1,1,1,1),(2518,3,4,1,2,1,1),(2519,3,4,1,3,1,1),(2520,3,4,1,4,1,1),(2521,3,4,1,5,1,1),(2522,3,4,1,6,1,1),(2523,3,4,1,7,1,1),(2524,3,4,1,8,1,1),(2525,3,4,1,9,1,1),(2526,3,4,1,10,0,1),(2527,3,4,1,11,0,1),(2528,3,4,1,12,0,1),(2529,3,4,1,13,0,1),(2530,3,4,1,14,0,1),(2531,3,4,1,15,0,1),(2532,3,4,1,16,1,1),(2533,3,4,1,17,1,1),(2534,3,4,1,18,1,1),(2535,3,4,1,19,1,1),(2536,3,4,1,20,1,1),(2537,3,4,1,21,1,1),(2538,3,4,1,22,1,1),(2539,3,4,1,23,1,1),(2540,3,4,1,24,1,1),(2541,3,4,1,25,1,1),(2542,3,4,1,26,1,1),(2543,3,4,1,27,1,1),(2544,3,4,1,28,1,1),(2545,3,4,1,29,1,1),(2546,3,4,1,30,1,1),(2547,3,4,1,31,1,1),(2548,3,4,1,32,1,1),(2549,3,9,1,1,1,1),(2550,3,9,1,2,1,1),(2551,3,9,1,3,1,1),(2552,3,9,1,4,1,1),(2553,3,9,1,5,1,1),(2554,3,9,1,6,1,1),(2555,3,9,1,7,1,1),(2556,3,9,1,8,1,1),(2557,3,9,1,9,1,1),(2558,3,9,1,10,0,1),(2559,3,9,1,11,0,1),(2560,3,9,1,12,0,1),(2561,3,9,1,13,0,1),(2562,3,9,1,14,0,1),(2563,3,9,1,15,0,1),(2564,3,9,1,16,1,1),(2565,3,9,1,17,1,1),(2566,3,9,1,18,1,1),(2567,3,9,1,19,1,1),(2568,3,9,1,20,1,1),(2569,3,9,1,21,1,1),(2570,3,9,1,22,1,1),(2571,3,9,1,23,1,1),(2572,3,9,1,24,1,1),(2573,3,9,1,25,1,1),(2574,3,9,1,26,1,1),(2575,3,9,1,27,1,1),(2576,3,9,1,28,1,1),(2577,3,9,1,29,1,1),(2578,3,9,1,30,1,1),(2579,3,9,1,31,1,1),(2580,3,9,1,32,1,1),(2581,3,10,1,1,1,1),(2582,3,10,1,2,1,1),(2583,3,10,1,3,1,1),(2584,3,10,1,4,1,1),(2585,3,10,1,5,1,1),(2586,3,10,1,6,1,1),(2587,3,10,1,7,1,1),(2588,3,10,1,8,1,1),(2589,3,10,1,9,1,1),(2590,3,10,1,10,0,1),(2591,3,10,1,11,0,1),(2592,3,10,1,12,0,1),(2593,3,10,1,13,0,1),(2594,3,10,1,14,0,1),(2595,3,10,1,15,0,1),(2596,3,10,1,16,1,1),(2597,3,10,1,17,1,1),(2598,3,10,1,18,1,1),(2599,3,10,1,19,1,1),(2600,3,10,1,20,1,1),(2601,3,10,1,21,1,1),(2602,3,10,1,22,1,1),(2603,3,10,1,23,1,1),(2604,3,10,1,24,1,1),(2605,3,10,1,25,1,1),(2606,3,10,1,26,1,1),(2607,3,10,1,27,1,1),(2608,3,10,1,28,1,1),(2609,3,10,1,29,1,1),(2610,3,10,1,30,1,1),(2611,3,10,1,31,1,1),(2612,3,10,1,32,1,1),(2613,3,3,1,1,1,1),(2614,3,3,1,2,1,1),(2615,3,3,1,3,1,1),(2616,3,3,1,4,1,1),(2617,3,3,1,5,1,1),(2618,3,3,1,6,1,1),(2619,3,3,1,7,1,1),(2620,3,3,1,8,1,1),(2621,3,3,1,9,1,1),(2622,3,3,1,10,0,1),(2623,3,3,1,11,0,1),(2624,3,3,1,12,0,1),(2625,3,3,1,13,0,1),(2626,3,3,1,14,0,1),(2627,3,3,1,15,0,1),(2628,3,3,1,16,1,1),(2629,3,3,1,17,1,1),(2630,3,3,1,18,1,1),(2631,3,3,1,19,1,1),(2632,3,3,1,20,1,1),(2633,3,3,1,21,1,1),(2634,3,3,1,22,1,1),(2635,3,3,1,23,1,1),(2636,3,3,1,24,1,1),(2637,3,3,1,25,1,1),(2638,3,3,1,26,1,1),(2639,3,3,1,27,1,1),(2640,3,3,1,28,1,1),(2641,3,3,1,29,1,1),(2642,3,3,1,30,1,1),(2643,3,3,1,31,1,1),(2644,3,3,1,32,1,1),(2645,3,7,1,1,1,1),(2646,3,7,1,2,1,1),(2647,3,7,1,3,1,1),(2648,3,7,1,4,1,1),(2649,3,7,1,5,1,1),(2650,3,7,1,6,1,1),(2651,3,7,1,7,1,1),(2652,3,7,1,8,1,1),(2653,3,7,1,9,1,1),(2654,3,7,1,10,0,1),(2655,3,7,1,11,0,1),(2656,3,7,1,12,0,1),(2657,3,7,1,13,0,1),(2658,3,7,1,14,0,1),(2659,3,7,1,15,0,1),(2660,3,7,1,16,1,1),(2661,3,7,1,17,1,1),(2662,3,7,1,18,1,1),(2663,3,7,1,19,1,1),(2664,3,7,1,20,1,1),(2665,3,7,1,21,1,1),(2666,3,7,1,22,1,1),(2667,3,7,1,23,1,1),(2668,3,7,1,24,1,1),(2669,3,7,1,25,1,1),(2670,3,7,1,26,1,1),(2671,3,7,1,27,1,1),(2672,3,7,1,28,1,1),(2673,3,7,1,29,1,1),(2674,3,7,1,30,1,1),(2675,3,7,1,31,1,1),(2676,3,7,1,32,1,1),(2677,3,12,1,1,1,1),(2678,3,12,1,2,1,1),(2679,3,12,1,3,1,1),(2680,3,12,1,4,1,1),(2681,3,12,1,5,1,1),(2682,3,12,1,6,1,1),(2683,3,12,1,7,1,1),(2684,3,12,1,8,1,1),(2685,3,12,1,9,1,1),(2686,3,12,1,10,0,1),(2687,3,12,1,11,0,1),(2688,3,12,1,12,0,1),(2689,3,12,1,13,0,1),(2690,3,12,1,14,0,1),(2691,3,12,1,15,0,1),(2692,3,12,1,16,1,1),(2693,3,12,1,17,1,1),(2694,3,12,1,18,1,1),(2695,3,12,1,19,1,1),(2696,3,12,1,20,1,1),(2697,3,12,1,21,1,1),(2698,3,12,1,22,1,1),(2699,3,12,1,23,1,1),(2700,3,12,1,24,1,1),(2701,3,12,1,25,1,1),(2702,3,12,1,26,1,1),(2703,3,12,1,27,1,1),(2704,3,12,1,28,1,1),(2705,3,12,1,29,1,1),(2706,3,12,1,30,1,1),(2707,3,12,1,31,1,1),(2708,3,12,1,32,1,1),(2709,3,60,4,53,1,1),(2710,3,60,4,54,1,1),(2711,3,60,4,55,1,1),(2712,3,60,4,56,1,1),(2713,3,60,4,57,1,1),(2714,3,60,4,58,1,1),(2715,3,60,4,59,1,1),(2716,3,60,4,60,1,1),(2717,3,60,4,61,1,1),(2718,3,60,4,62,1,1),(2719,3,60,4,63,1,1),(2720,3,60,4,64,1,1),(2721,3,60,4,65,1,1),(2722,3,60,4,66,1,1),(2723,3,60,4,67,1,1),(2724,3,60,4,68,1,1),(2725,3,56,4,53,1,1),(2726,3,56,4,54,1,1),(2727,3,56,4,55,1,1),(2728,3,56,4,56,1,1),(2729,3,56,4,57,1,1),(2730,3,56,4,58,1,1),(2731,3,56,4,59,1,1),(2732,3,56,4,60,1,1),(2733,3,56,4,61,1,1),(2734,3,56,4,62,1,1),(2735,3,56,4,63,1,1),(2736,3,56,4,64,1,1),(2737,3,56,4,65,1,1),(2738,3,56,4,66,1,1),(2739,3,56,4,67,1,1),(2740,3,56,4,68,1,1),(2741,3,57,4,53,1,1),(2742,3,57,4,54,1,1),(2743,3,57,4,55,1,1),(2744,3,57,4,56,1,1),(2745,3,57,4,57,1,1),(2746,3,57,4,58,1,1),(2747,3,57,4,59,1,1),(2748,3,57,4,60,1,1),(2749,3,57,4,61,1,1),(2750,3,57,4,62,1,1),(2751,3,57,4,63,1,1),(2752,3,57,4,64,1,1),(2753,3,57,4,65,1,1),(2754,3,57,4,66,1,1),(2755,3,57,4,67,1,1),(2756,3,57,4,68,1,1),(2757,3,58,4,53,1,1),(2758,3,58,4,54,1,1),(2759,3,58,4,55,1,1),(2760,3,58,4,56,1,1),(2761,3,58,4,57,1,1),(2762,3,58,4,58,1,1),(2763,3,58,4,59,1,1),(2764,3,58,4,60,1,1),(2765,3,58,4,61,1,1),(2766,3,58,4,62,1,1),(2767,3,58,4,63,1,1),(2768,3,58,4,64,1,1),(2769,3,58,4,65,1,1),(2770,3,58,4,66,1,1),(2771,3,58,4,67,1,1),(2772,3,58,4,68,1,1),(2773,3,59,4,53,1,1),(2774,3,59,4,54,1,1),(2775,3,59,4,55,1,1),(2776,3,59,4,56,1,1),(2777,3,59,4,57,1,1),(2778,3,59,4,58,1,1),(2779,3,59,4,59,1,1),(2780,3,59,4,60,1,1),(2781,3,59,4,61,1,1),(2782,3,59,4,62,1,1),(2783,3,59,4,63,1,1),(2784,3,59,4,64,1,1),(2785,3,59,4,65,1,1),(2786,3,59,4,66,1,1),(2787,3,59,4,67,1,1),(2788,3,59,4,68,1,1),(2789,3,31,2,33,1,1),(2790,3,31,2,34,1,1),(2791,3,31,2,35,1,1),(2792,3,31,2,36,1,1),(2793,3,31,2,37,1,1),(2794,3,31,2,38,0,1),(2795,3,31,2,39,0,1),(2796,3,31,2,40,0,1),(2797,3,31,2,41,1,1),(2798,3,31,2,42,1,1),(2799,3,28,2,33,1,1),(2800,3,28,2,34,1,1),(2801,3,28,2,35,1,1),(2802,3,28,2,36,1,1),(2803,3,28,2,37,1,1),(2804,3,28,2,38,0,1),(2805,3,28,2,39,0,1),(2806,3,28,2,40,0,1),(2807,3,28,2,41,1,1),(2808,3,28,2,42,1,1),(2809,3,29,2,33,1,1),(2810,3,29,2,34,1,1),(2811,3,29,2,35,1,1),(2812,3,29,2,36,1,1),(2813,3,29,2,37,1,1),(2814,3,29,2,38,0,1),(2815,3,29,2,39,0,1),(2816,3,29,2,40,0,1),(2817,3,29,2,41,1,1),(2818,3,29,2,42,1,1),(2819,3,25,2,33,1,1),(2820,3,25,2,34,1,1),(2821,3,25,2,35,1,1),(2822,3,25,2,36,1,1),(2823,3,25,2,37,1,1),(2824,3,25,2,38,0,1),(2825,3,25,2,39,0,1),(2826,3,25,2,40,0,1),(2827,3,25,2,41,1,1),(2828,3,25,2,42,1,1),(2829,3,26,2,33,1,1),(2830,3,26,2,34,1,1),(2831,3,26,2,35,1,1),(2832,3,26,2,36,1,1),(2833,3,26,2,37,1,1),(2834,3,26,2,38,0,1),(2835,3,26,2,39,0,1),(2836,3,26,2,40,0,1),(2837,3,26,2,41,1,1),(2838,3,26,2,42,1,1),(2839,3,27,2,33,1,1),(2840,3,27,2,34,1,1),(2841,3,27,2,35,1,1),(2842,3,27,2,36,1,1),(2843,3,27,2,37,1,1),(2844,3,27,2,38,0,1),(2845,3,27,2,39,0,1),(2846,3,27,2,40,0,1),(2847,3,27,2,41,1,1),(2848,3,27,2,42,1,1),(2849,3,30,2,33,1,1),(2850,3,30,2,34,1,1),(2851,3,30,2,35,1,1),(2852,3,30,2,36,1,1),(2853,3,30,2,37,1,1),(2854,3,30,2,38,0,1),(2855,3,30,2,39,0,1),(2856,3,30,2,40,0,1),(2857,3,30,2,41,1,1),(2858,3,30,2,42,1,1),(2859,3,23,2,33,1,1),(2860,3,23,2,34,1,1),(2861,3,23,2,35,1,1),(2862,3,23,2,36,1,1),(2863,3,23,2,37,1,1),(2864,3,23,2,38,0,1),(2865,3,23,2,39,0,1),(2866,3,23,2,40,0,1),(2867,3,23,2,41,1,1),(2868,3,23,2,42,1,1),(2869,3,24,2,33,1,1),(2870,3,24,2,34,1,1),(2871,3,24,2,35,1,1),(2872,3,24,2,36,1,1),(2873,3,24,2,37,1,1),(2874,3,24,2,38,0,1),(2875,3,24,2,39,0,1),(2876,3,24,2,40,0,1),(2877,3,24,2,41,1,1),(2878,3,24,2,42,1,1),(2879,3,22,2,33,1,1),(2880,3,22,2,34,1,1),(2881,3,22,2,35,1,1),(2882,3,22,2,36,1,1),(2883,3,22,2,37,1,1),(2884,3,22,2,38,0,1),(2885,3,22,2,39,0,1),(2886,3,22,2,40,0,1),(2887,3,22,2,41,1,1),(2888,3,22,2,42,1,1),(3070,4,50,3,43,1,1),(3071,4,50,3,44,1,1),(3072,4,50,3,45,1,1),(3073,4,50,3,46,1,1),(3074,4,50,3,47,1,1),(3075,4,50,3,48,1,1),(3076,4,50,3,49,1,1),(3077,4,50,3,50,1,1),(3078,4,50,3,51,1,1),(3079,4,50,3,52,1,1),(3080,4,48,3,43,1,1),(3081,4,48,3,44,1,1),(3082,4,48,3,45,1,1),(3083,4,48,3,46,1,1),(3084,4,48,3,47,1,1),(3085,4,48,3,48,1,1),(3086,4,48,3,49,1,1),(3087,4,48,3,50,1,1),(3088,4,48,3,51,1,1),(3089,4,48,3,52,1,1),(3090,4,55,3,43,1,1),(3091,4,55,3,44,1,1),(3092,4,55,3,45,1,1),(3093,4,55,3,46,1,1),(3094,4,55,3,47,1,1),(3095,4,55,3,48,1,1),(3096,4,55,3,49,1,1),(3097,4,55,3,50,1,1),(3098,4,55,3,51,1,1),(3099,4,55,3,52,1,1),(3100,4,47,3,43,1,1),(3101,4,47,3,44,1,1),(3102,4,47,3,45,1,1),(3103,4,47,3,46,1,1),(3104,4,47,3,47,1,1),(3105,4,47,3,48,1,1),(3106,4,47,3,49,1,1),(3107,4,47,3,50,1,1),(3108,4,47,3,51,1,1),(3109,4,47,3,52,1,1),(3110,4,43,3,43,1,1),(3111,4,43,3,44,1,1),(3112,4,43,3,45,1,1),(3113,4,43,3,46,1,1),(3114,4,43,3,47,1,1),(3115,4,43,3,48,1,1),(3116,4,43,3,49,1,1),(3117,4,43,3,50,1,1),(3118,4,43,3,51,1,1),(3119,4,43,3,52,1,1),(3120,4,42,3,43,1,1),(3121,4,42,3,44,1,1),(3122,4,42,3,45,1,1),(3123,4,42,3,46,1,1),(3124,4,42,3,47,1,1),(3125,4,42,3,48,1,1),(3126,4,42,3,49,1,1),(3127,4,42,3,50,1,1),(3128,4,42,3,51,1,1),(3129,4,42,3,52,1,1),(3130,4,45,3,43,1,1),(3131,4,45,3,44,1,1),(3132,4,45,3,45,1,1),(3133,4,45,3,46,1,1),(3134,4,45,3,47,1,1),(3135,4,45,3,48,1,1),(3136,4,45,3,49,1,1),(3137,4,45,3,50,1,1),(3138,4,45,3,51,1,1),(3139,4,45,3,52,1,1),(3140,4,49,3,43,1,1),(3141,4,49,3,44,1,1),(3142,4,49,3,45,1,1),(3143,4,49,3,46,1,1),(3144,4,49,3,47,1,1),(3145,4,49,3,48,1,1),(3146,4,49,3,49,1,1),(3147,4,49,3,50,1,1),(3148,4,49,3,51,1,1),(3149,4,49,3,52,1,1),(3150,4,44,3,43,1,1),(3151,4,44,3,44,1,1),(3152,4,44,3,45,1,1),(3153,4,44,3,46,1,1),(3154,4,44,3,47,1,1),(3155,4,44,3,48,1,1),(3156,4,44,3,49,1,1),(3157,4,44,3,50,1,1),(3158,4,44,3,51,1,1),(3159,4,44,3,52,1,1),(3160,4,37,3,43,1,1),(3161,4,37,3,44,1,1),(3162,4,37,3,45,1,1),(3163,4,37,3,46,1,1),(3164,4,37,3,47,1,1),(3165,4,37,3,48,1,1),(3166,4,37,3,49,1,1),(3167,4,37,3,50,1,1),(3168,4,37,3,51,1,1),(3169,4,37,3,52,1,1),(3170,4,40,3,43,1,1),(3171,4,40,3,44,1,1),(3172,4,40,3,45,1,1),(3173,4,40,3,46,1,1),(3174,4,40,3,47,1,1),(3175,4,40,3,48,1,1),(3176,4,40,3,49,1,1),(3177,4,40,3,50,1,1),(3178,4,40,3,51,1,1),(3179,4,40,3,52,1,1),(3180,4,39,3,43,1,1),(3181,4,39,3,44,1,1),(3182,4,39,3,45,1,1),(3183,4,39,3,46,1,1),(3184,4,39,3,47,1,1),(3185,4,39,3,48,1,1),(3186,4,39,3,49,1,1),(3187,4,39,3,50,1,1),(3188,4,39,3,51,1,1),(3189,4,39,3,52,1,1),(3190,4,38,3,43,1,1),(3191,4,38,3,44,1,1),(3192,4,38,3,45,1,1),(3193,4,38,3,46,1,1),(3194,4,38,3,47,1,1),(3195,4,38,3,48,1,1),(3196,4,38,3,49,1,1),(3197,4,38,3,50,1,1),(3198,4,38,3,51,1,1),(3199,4,38,3,52,1,1),(3200,4,36,3,43,1,1),(3201,4,36,3,44,1,1),(3202,4,36,3,45,1,1),(3203,4,36,3,46,1,1),(3204,4,36,3,47,1,1),(3205,4,36,3,48,1,1),(3206,4,36,3,49,1,1),(3207,4,36,3,50,1,1),(3208,4,36,3,51,1,1),(3209,4,36,3,52,1,1),(3210,4,41,3,43,1,1),(3211,4,41,3,44,1,1),(3212,4,41,3,45,1,1),(3213,4,41,3,46,0,1),(3214,4,41,3,47,1,1),(3215,4,41,3,48,0,1),(3216,4,41,3,49,0,1),(3217,4,41,3,50,0,1),(3218,4,41,3,51,1,1),(3219,4,41,3,52,1,1),(3220,4,17,1,1,1,1),(3221,4,17,1,2,1,1),(3222,4,17,1,3,1,1),(3223,4,17,1,4,1,1),(3224,4,17,1,5,1,1),(3225,4,17,1,6,1,1),(3226,4,17,1,7,1,1),(3227,4,17,1,8,1,1),(3228,4,17,1,9,1,1),(3229,4,17,1,10,0,1),(3230,4,17,1,11,0,1),(3231,4,17,1,12,0,1),(3232,4,17,1,13,0,1),(3233,4,17,1,14,0,1),(3234,4,17,1,15,0,1),(3235,4,17,1,16,1,1),(3236,4,17,1,17,1,1),(3237,4,17,1,18,1,1),(3238,4,17,1,19,1,1),(3239,4,17,1,20,1,1),(3240,4,17,1,21,1,1),(3241,4,17,1,22,1,1),(3242,4,17,1,23,1,1),(3243,4,17,1,24,1,1),(3244,4,17,1,25,1,1),(3245,4,17,1,26,1,1),(3246,4,17,1,27,1,1),(3247,4,17,1,28,1,1),(3248,4,17,1,29,1,1),(3249,4,17,1,30,1,1),(3250,4,17,1,31,1,1),(3251,4,17,1,32,1,1),(3252,4,16,1,1,1,1),(3253,4,16,1,2,1,1),(3254,4,16,1,3,1,1),(3255,4,16,1,4,1,1),(3256,4,16,1,5,1,1),(3257,4,16,1,6,1,1),(3258,4,16,1,7,1,1),(3259,4,16,1,8,1,1),(3260,4,16,1,9,1,1),(3261,4,16,1,10,0,1),(3262,4,16,1,11,0,1),(3263,4,16,1,12,0,1),(3264,4,16,1,13,0,1),(3265,4,16,1,14,0,1),(3266,4,16,1,15,0,1),(3267,4,16,1,16,1,1),(3268,4,16,1,17,1,1),(3269,4,16,1,18,1,1),(3270,4,16,1,19,1,1),(3271,4,16,1,20,1,1),(3272,4,16,1,21,1,1),(3273,4,16,1,22,1,1),(3274,4,16,1,23,1,1),(3275,4,16,1,24,1,1),(3276,4,16,1,25,1,1),(3277,4,16,1,26,1,1),(3278,4,16,1,27,1,1),(3279,4,16,1,28,1,1),(3280,4,16,1,29,1,1),(3281,4,16,1,30,1,1),(3282,4,16,1,31,1,1),(3283,4,16,1,32,1,1),(3284,4,15,1,1,1,1),(3285,4,15,1,2,1,1),(3286,4,15,1,3,1,1),(3287,4,15,1,4,1,1),(3288,4,15,1,5,1,1),(3289,4,15,1,6,1,1),(3290,4,15,1,7,1,1),(3291,4,15,1,8,1,1),(3292,4,15,1,9,1,1),(3293,4,15,1,10,0,1),(3294,4,15,1,11,0,1),(3295,4,15,1,12,0,1),(3296,4,15,1,13,0,1),(3297,4,15,1,14,0,1),(3298,4,15,1,15,0,1),(3299,4,15,1,16,1,1),(3300,4,15,1,17,1,1),(3301,4,15,1,18,1,1),(3302,4,15,1,19,1,1),(3303,4,15,1,20,1,1),(3304,4,15,1,21,1,1),(3305,4,15,1,22,1,1),(3306,4,15,1,23,1,1),(3307,4,15,1,24,1,1),(3308,4,15,1,25,1,1),(3309,4,15,1,26,1,1),(3310,4,15,1,27,1,1),(3311,4,15,1,28,1,1),(3312,4,15,1,29,1,1),(3313,4,15,1,30,1,1),(3314,4,15,1,31,1,1),(3315,4,15,1,32,1,1),(3316,4,13,1,1,1,1),(3317,4,13,1,2,1,1),(3318,4,13,1,3,1,1),(3319,4,13,1,4,1,1),(3320,4,13,1,5,1,1),(3321,4,13,1,6,1,1),(3322,4,13,1,7,1,1),(3323,4,13,1,8,1,1),(3324,4,13,1,9,1,1),(3325,4,13,1,10,0,1),(3326,4,13,1,11,0,1),(3327,4,13,1,12,0,1),(3328,4,13,1,13,0,1),(3329,4,13,1,14,0,1),(3330,4,13,1,15,0,1),(3331,4,13,1,16,1,1),(3332,4,13,1,17,1,1),(3333,4,13,1,18,1,1),(3334,4,13,1,19,1,1),(3335,4,13,1,20,1,1),(3336,4,13,1,21,1,1),(3337,4,13,1,22,1,1),(3338,4,13,1,23,1,1),(3339,4,13,1,24,1,1),(3340,4,13,1,25,1,1),(3341,4,13,1,26,1,1),(3342,4,13,1,27,1,1),(3343,4,13,1,28,1,1),(3344,4,13,1,29,1,1),(3345,4,13,1,30,1,1),(3346,4,13,1,31,1,1),(3347,4,13,1,32,1,1),(3348,4,14,1,1,1,1),(3349,4,14,1,2,1,1),(3350,4,14,1,3,1,1),(3351,4,14,1,4,1,1),(3352,4,14,1,5,1,1),(3353,4,14,1,6,1,1),(3354,4,14,1,7,1,1),(3355,4,14,1,8,1,1),(3356,4,14,1,9,1,1),(3357,4,14,1,10,0,1),(3358,4,14,1,11,0,1),(3359,4,14,1,12,0,1),(3360,4,14,1,13,0,1),(3361,4,14,1,14,0,1),(3362,4,14,1,15,0,1),(3363,4,14,1,16,1,1),(3364,4,14,1,17,1,1),(3365,4,14,1,18,1,1),(3366,4,14,1,19,1,1),(3367,4,14,1,20,1,1),(3368,4,14,1,21,1,1),(3369,4,14,1,22,1,1),(3370,4,14,1,23,1,1),(3371,4,14,1,24,1,1),(3372,4,14,1,25,1,1),(3373,4,14,1,26,1,1),(3374,4,14,1,27,1,1),(3375,4,14,1,28,1,1),(3376,4,14,1,29,1,1),(3377,4,14,1,30,1,1),(3378,4,14,1,31,1,1),(3379,4,14,1,32,1,1),(3380,4,11,1,1,1,1),(3381,4,11,1,2,1,1),(3382,4,11,1,3,1,1),(3383,4,11,1,4,1,1),(3384,4,11,1,5,1,1),(3385,4,11,1,6,1,1),(3386,4,11,1,7,1,1),(3387,4,11,1,8,1,1),(3388,4,11,1,9,1,1),(3389,4,11,1,10,0,1),(3390,4,11,1,11,0,1),(3391,4,11,1,12,0,1),(3392,4,11,1,13,0,1),(3393,4,11,1,14,0,1),(3394,4,11,1,15,0,1),(3395,4,11,1,16,1,1),(3396,4,11,1,17,1,1),(3397,4,11,1,18,1,1),(3398,4,11,1,19,1,1),(3399,4,11,1,20,1,1),(3400,4,11,1,21,1,1),(3401,4,11,1,22,1,1),(3402,4,11,1,23,1,1),(3403,4,11,1,24,1,1),(3404,4,11,1,25,1,1),(3405,4,11,1,26,1,1),(3406,4,11,1,27,1,1),(3407,4,11,1,28,1,1),(3408,4,11,1,29,1,1),(3409,4,11,1,30,1,1),(3410,4,11,1,31,1,1),(3411,4,11,1,32,1,1),(3412,4,2,1,1,1,1),(3413,4,2,1,2,1,1),(3414,4,2,1,3,1,1),(3415,4,2,1,4,1,1),(3416,4,2,1,5,1,1),(3417,4,2,1,6,1,1),(3418,4,2,1,7,1,1),(3419,4,2,1,8,1,1),(3420,4,2,1,9,1,1),(3421,4,2,1,10,0,1),(3422,4,2,1,11,0,1),(3423,4,2,1,12,0,1),(3424,4,2,1,13,0,1),(3425,4,2,1,14,0,1),(3426,4,2,1,15,0,1),(3427,4,2,1,16,1,1),(3428,4,2,1,17,1,1),(3429,4,2,1,18,1,1),(3430,4,2,1,19,1,1),(3431,4,2,1,20,1,1),(3432,4,2,1,21,1,1),(3433,4,2,1,22,1,1),(3434,4,2,1,23,1,1),(3435,4,2,1,24,1,1),(3436,4,2,1,25,1,1),(3437,4,2,1,26,1,1),(3438,4,2,1,27,1,1),(3439,4,2,1,28,1,1),(3440,4,2,1,29,1,1),(3441,4,2,1,30,1,1),(3442,4,2,1,31,1,1),(3443,4,2,1,32,1,1),(3444,4,1,1,1,1,1),(3445,4,1,1,2,1,1),(3446,4,1,1,3,1,1),(3447,4,1,1,4,1,1),(3448,4,1,1,5,1,1),(3449,4,1,1,6,1,1),(3450,4,1,1,7,1,1),(3451,4,1,1,8,1,1),(3452,4,1,1,9,1,1),(3453,4,1,1,10,0,1),(3454,4,1,1,11,0,1),(3455,4,1,1,12,0,1),(3456,4,1,1,13,0,1),(3457,4,1,1,14,0,1),(3458,4,1,1,15,0,1),(3459,4,1,1,16,1,1),(3460,4,1,1,17,1,1),(3461,4,1,1,18,1,1),(3462,4,1,1,19,1,1),(3463,4,1,1,20,1,1),(3464,4,1,1,21,1,1),(3465,4,1,1,22,1,1),(3466,4,1,1,23,1,1),(3467,4,1,1,24,1,1),(3468,4,1,1,25,1,1),(3469,4,1,1,26,1,1),(3470,4,1,1,27,1,1),(3471,4,1,1,28,1,1),(3472,4,1,1,29,1,1),(3473,4,1,1,30,1,1),(3474,4,1,1,31,1,1),(3475,4,1,1,32,1,1),(3476,4,8,1,1,1,1),(3477,4,8,1,2,1,1),(3478,4,8,1,3,1,1),(3479,4,8,1,4,1,1),(3480,4,8,1,5,1,1),(3481,4,8,1,6,1,1),(3482,4,8,1,7,1,1),(3483,4,8,1,8,1,1),(3484,4,8,1,9,1,1),(3485,4,8,1,10,0,1),(3486,4,8,1,11,0,1),(3487,4,8,1,12,0,1),(3488,4,8,1,13,0,1),(3489,4,8,1,14,0,1),(3490,4,8,1,15,0,1),(3491,4,8,1,16,1,1),(3492,4,8,1,17,1,1),(3493,4,8,1,18,1,1),(3494,4,8,1,19,1,1),(3495,4,8,1,20,1,1),(3496,4,8,1,21,1,1),(3497,4,8,1,22,1,1),(3498,4,8,1,23,1,1),(3499,4,8,1,24,1,1),(3500,4,8,1,25,1,1),(3501,4,8,1,26,1,1),(3502,4,8,1,27,1,1),(3503,4,8,1,28,1,1),(3504,4,8,1,29,1,1),(3505,4,8,1,30,1,1),(3506,4,8,1,31,1,1),(3507,4,8,1,32,1,1),(3508,4,6,1,1,1,1),(3509,4,6,1,2,1,1),(3510,4,6,1,3,1,1),(3511,4,6,1,4,1,1),(3512,4,6,1,5,1,1),(3513,4,6,1,6,1,1),(3514,4,6,1,7,1,1),(3515,4,6,1,8,1,1),(3516,4,6,1,9,1,1),(3517,4,6,1,10,0,1),(3518,4,6,1,11,0,1),(3519,4,6,1,12,0,1),(3520,4,6,1,13,0,1),(3521,4,6,1,14,0,1),(3522,4,6,1,15,0,1),(3523,4,6,1,16,1,1),(3524,4,6,1,17,1,1),(3525,4,6,1,18,1,1),(3526,4,6,1,19,1,1),(3527,4,6,1,20,1,1),(3528,4,6,1,21,1,1),(3529,4,6,1,22,1,1),(3530,4,6,1,23,1,1),(3531,4,6,1,24,1,1),(3532,4,6,1,25,1,1),(3533,4,6,1,26,1,1),(3534,4,6,1,27,1,1),(3535,4,6,1,28,1,1),(3536,4,6,1,29,1,1),(3537,4,6,1,30,1,1),(3538,4,6,1,31,1,1),(3539,4,6,1,32,1,1),(3540,4,4,1,1,1,1),(3541,4,4,1,2,1,1),(3542,4,4,1,3,1,1),(3543,4,4,1,4,1,1),(3544,4,4,1,5,1,1),(3545,4,4,1,6,1,1),(3546,4,4,1,7,1,1),(3547,4,4,1,8,1,1),(3548,4,4,1,9,1,1),(3549,4,4,1,10,0,1),(3550,4,4,1,11,0,1),(3551,4,4,1,12,0,1),(3552,4,4,1,13,0,1),(3553,4,4,1,14,0,1),(3554,4,4,1,15,0,1),(3555,4,4,1,16,1,1),(3556,4,4,1,17,1,1),(3557,4,4,1,18,1,1),(3558,4,4,1,19,1,1),(3559,4,4,1,20,1,1),(3560,4,4,1,21,1,1),(3561,4,4,1,22,1,1),(3562,4,4,1,23,1,1),(3563,4,4,1,24,1,1),(3564,4,4,1,25,1,1),(3565,4,4,1,26,1,1),(3566,4,4,1,27,1,1),(3567,4,4,1,28,1,1),(3568,4,4,1,29,1,1),(3569,4,4,1,30,1,1),(3570,4,4,1,31,1,1),(3571,4,4,1,32,1,1),(3572,4,9,1,1,1,1),(3573,4,9,1,2,1,1),(3574,4,9,1,3,1,1),(3575,4,9,1,4,1,1),(3576,4,9,1,5,1,1),(3577,4,9,1,6,1,1),(3578,4,9,1,7,1,1),(3579,4,9,1,8,1,1),(3580,4,9,1,9,1,1),(3581,4,9,1,10,0,1),(3582,4,9,1,11,0,1),(3583,4,9,1,12,0,1),(3584,4,9,1,13,0,1),(3585,4,9,1,14,0,1),(3586,4,9,1,15,0,1),(3587,4,9,1,16,1,1),(3588,4,9,1,17,1,1),(3589,4,9,1,18,1,1),(3590,4,9,1,19,1,1),(3591,4,9,1,20,1,1),(3592,4,9,1,21,1,1),(3593,4,9,1,22,1,1),(3594,4,9,1,23,1,1),(3595,4,9,1,24,1,1),(3596,4,9,1,25,1,1),(3597,4,9,1,26,1,1),(3598,4,9,1,27,1,1),(3599,4,9,1,28,1,1),(3600,4,9,1,29,1,1),(3601,4,9,1,30,1,1),(3602,4,9,1,31,1,1),(3603,4,9,1,32,1,1),(3604,4,10,1,1,1,1),(3605,4,10,1,2,1,1),(3606,4,10,1,3,1,1),(3607,4,10,1,4,1,1),(3608,4,10,1,5,1,1),(3609,4,10,1,6,1,1),(3610,4,10,1,7,1,1),(3611,4,10,1,8,1,1),(3612,4,10,1,9,1,1),(3613,4,10,1,10,0,1),(3614,4,10,1,11,0,1),(3615,4,10,1,12,0,1),(3616,4,10,1,13,0,1),(3617,4,10,1,14,0,1),(3618,4,10,1,15,0,1),(3619,4,10,1,16,1,1),(3620,4,10,1,17,1,1),(3621,4,10,1,18,1,1),(3622,4,10,1,19,1,1),(3623,4,10,1,20,1,1),(3624,4,10,1,21,1,1),(3625,4,10,1,22,1,1),(3626,4,10,1,23,1,1),(3627,4,10,1,24,1,1),(3628,4,10,1,25,1,1),(3629,4,10,1,26,1,1),(3630,4,10,1,27,1,1),(3631,4,10,1,28,1,1),(3632,4,10,1,29,1,1),(3633,4,10,1,30,1,1),(3634,4,10,1,31,1,1),(3635,4,10,1,32,1,1),(3636,4,3,1,1,1,1),(3637,4,3,1,2,1,1),(3638,4,3,1,3,1,1),(3639,4,3,1,4,1,1),(3640,4,3,1,5,1,1),(3641,4,3,1,6,1,1),(3642,4,3,1,7,1,1),(3643,4,3,1,8,1,1),(3644,4,3,1,9,1,1),(3645,4,3,1,10,0,1),(3646,4,3,1,11,0,1),(3647,4,3,1,12,0,1),(3648,4,3,1,13,0,1),(3649,4,3,1,14,0,1),(3650,4,3,1,15,0,1),(3651,4,3,1,16,1,1),(3652,4,3,1,17,1,1),(3653,4,3,1,18,1,1),(3654,4,3,1,19,1,1),(3655,4,3,1,20,1,1),(3656,4,3,1,21,1,1),(3657,4,3,1,22,1,1),(3658,4,3,1,23,1,1),(3659,4,3,1,24,1,1),(3660,4,3,1,25,1,1),(3661,4,3,1,26,1,1),(3662,4,3,1,27,1,1),(3663,4,3,1,28,1,1),(3664,4,3,1,29,1,1),(3665,4,3,1,30,1,1),(3666,4,3,1,31,1,1),(3667,4,3,1,32,1,1),(3668,4,7,1,1,1,1),(3669,4,7,1,2,1,1),(3670,4,7,1,3,1,1),(3671,4,7,1,4,1,1),(3672,4,7,1,5,1,1),(3673,4,7,1,6,1,1),(3674,4,7,1,7,1,1),(3675,4,7,1,8,1,1),(3676,4,7,1,9,1,1),(3677,4,7,1,10,0,1),(3678,4,7,1,11,0,1),(3679,4,7,1,12,0,1),(3680,4,7,1,13,0,1),(3681,4,7,1,14,0,1),(3682,4,7,1,15,0,1),(3683,4,7,1,16,1,1),(3684,4,7,1,17,1,1),(3685,4,7,1,18,1,1),(3686,4,7,1,19,1,1),(3687,4,7,1,20,1,1),(3688,4,7,1,21,1,1),(3689,4,7,1,22,1,1),(3690,4,7,1,23,1,1),(3691,4,7,1,24,1,1),(3692,4,7,1,25,1,1),(3693,4,7,1,26,1,1),(3694,4,7,1,27,1,1),(3695,4,7,1,28,1,1),(3696,4,7,1,29,1,1),(3697,4,7,1,30,1,1),(3698,4,7,1,31,1,1),(3699,4,7,1,32,1,1),(3700,4,12,1,1,1,1),(3701,4,12,1,2,1,1),(3702,4,12,1,3,1,1),(3703,4,12,1,4,1,1),(3704,4,12,1,5,1,1),(3705,4,12,1,6,1,1),(3706,4,12,1,7,1,1),(3707,4,12,1,8,1,1),(3708,4,12,1,9,1,1),(3709,4,12,1,10,0,1),(3710,4,12,1,11,0,1),(3711,4,12,1,12,0,1),(3712,4,12,1,13,0,1),(3713,4,12,1,14,0,1),(3714,4,12,1,15,0,1),(3715,4,12,1,16,1,1),(3716,4,12,1,17,1,1),(3717,4,12,1,18,1,1),(3718,4,12,1,19,1,1),(3719,4,12,1,20,1,1),(3720,4,12,1,21,1,1),(3721,4,12,1,22,1,1),(3722,4,12,1,23,1,1),(3723,4,12,1,24,1,1),(3724,4,12,1,25,1,1),(3725,4,12,1,26,1,1),(3726,4,12,1,27,1,1),(3727,4,12,1,28,1,1),(3728,4,12,1,29,1,1),(3729,4,12,1,30,1,1),(3730,4,12,1,31,1,1),(3731,4,12,1,32,1,1),(3732,4,60,4,53,1,1),(3733,4,60,4,54,1,1),(3734,4,60,4,55,1,1),(3735,4,60,4,56,1,1),(3736,4,60,4,57,1,1),(3737,4,60,4,58,1,1),(3738,4,60,4,59,1,1),(3739,4,60,4,60,1,1),(3740,4,60,4,61,1,1),(3741,4,60,4,62,1,1),(3742,4,60,4,63,1,1),(3743,4,60,4,64,1,1),(3744,4,60,4,65,1,1),(3745,4,60,4,66,1,1),(3746,4,60,4,67,1,1),(3747,4,60,4,68,1,1),(3748,4,56,4,53,1,1),(3749,4,56,4,54,1,1),(3750,4,56,4,55,1,1),(3751,4,56,4,56,1,1),(3752,4,56,4,57,1,1),(3753,4,56,4,58,1,1),(3754,4,56,4,59,1,1),(3755,4,56,4,60,1,1),(3756,4,56,4,61,1,1),(3757,4,56,4,62,1,1),(3758,4,56,4,63,1,1),(3759,4,56,4,64,1,1),(3760,4,56,4,65,1,1),(3761,4,56,4,66,1,1),(3762,4,56,4,67,1,1),(3763,4,56,4,68,1,1),(3764,4,57,4,53,1,1),(3765,4,57,4,54,1,1),(3766,4,57,4,55,1,1),(3767,4,57,4,56,1,1),(3768,4,57,4,57,1,1),(3769,4,57,4,58,1,1),(3770,4,57,4,59,1,1),(3771,4,57,4,60,1,1),(3772,4,57,4,61,1,1),(3773,4,57,4,62,1,1),(3774,4,57,4,63,1,1),(3775,4,57,4,64,1,1),(3776,4,57,4,65,1,1),(3777,4,57,4,66,1,1),(3778,4,57,4,67,1,1),(3779,4,57,4,68,1,1),(3780,4,58,4,53,1,1),(3781,4,58,4,54,1,1),(3782,4,58,4,55,1,1),(3783,4,58,4,56,1,1),(3784,4,58,4,57,1,1),(3785,4,58,4,58,1,1),(3786,4,58,4,59,1,1),(3787,4,58,4,60,1,1),(3788,4,58,4,61,1,1),(3789,4,58,4,62,1,1),(3790,4,58,4,63,1,1),(3791,4,58,4,64,1,1),(3792,4,58,4,65,1,1),(3793,4,58,4,66,1,1),(3794,4,58,4,67,1,1),(3795,4,58,4,68,1,1),(3796,4,59,4,53,1,1),(3797,4,59,4,54,1,1),(3798,4,59,4,55,1,1),(3799,4,59,4,56,1,1),(3800,4,59,4,57,1,1),(3801,4,59,4,58,1,1),(3802,4,59,4,59,1,1),(3803,4,59,4,60,1,1),(3804,4,59,4,61,1,1),(3805,4,59,4,62,1,1),(3806,4,59,4,63,1,1),(3807,4,59,4,64,1,1),(3808,4,59,4,65,1,1),(3809,4,59,4,66,1,1),(3810,4,59,4,67,1,1),(3811,4,59,4,68,1,1),(3812,4,31,2,33,1,1),(3813,4,31,2,34,1,1),(3814,4,31,2,35,1,1),(3815,4,31,2,36,1,1),(3816,4,31,2,37,1,1),(3817,4,31,2,38,0,1),(3818,4,31,2,39,0,1),(3819,4,31,2,40,0,1),(3820,4,31,2,41,1,1),(3821,4,31,2,42,1,1),(3822,4,28,2,33,1,1),(3823,4,28,2,34,1,1),(3824,4,28,2,35,1,1),(3825,4,28,2,36,1,1),(3826,4,28,2,37,1,1),(3827,4,28,2,38,0,1),(3828,4,28,2,39,0,1),(3829,4,28,2,40,0,1),(3830,4,28,2,41,1,1),(3831,4,28,2,42,1,1),(3832,4,29,2,33,1,1),(3833,4,29,2,34,1,1),(3834,4,29,2,35,1,1),(3835,4,29,2,36,1,1),(3836,4,29,2,37,1,1),(3837,4,29,2,38,0,1),(3838,4,29,2,39,0,1),(3839,4,29,2,40,0,1),(3840,4,29,2,41,1,1),(3841,4,29,2,42,1,1),(3842,4,25,2,33,1,1),(3843,4,25,2,34,1,1),(3844,4,25,2,35,1,1),(3845,4,25,2,36,1,1),(3846,4,25,2,37,1,1),(3847,4,25,2,38,0,1),(3848,4,25,2,39,0,1),(3849,4,25,2,40,0,1),(3850,4,25,2,41,1,1),(3851,4,25,2,42,1,1),(3852,4,26,2,33,1,1),(3853,4,26,2,34,1,1),(3854,4,26,2,35,1,1),(3855,4,26,2,36,1,1),(3856,4,26,2,37,1,1),(3857,4,26,2,38,0,1),(3858,4,26,2,39,0,1),(3859,4,26,2,40,0,1),(3860,4,26,2,41,1,1),(3861,4,26,2,42,1,1),(3862,4,27,2,33,1,1),(3863,4,27,2,34,1,1),(3864,4,27,2,35,1,1),(3865,4,27,2,36,1,1),(3866,4,27,2,37,1,1),(3867,4,27,2,38,0,1),(3868,4,27,2,39,0,1),(3869,4,27,2,40,0,1),(3870,4,27,2,41,1,1),(3871,4,27,2,42,1,1),(3872,4,30,2,33,1,1),(3873,4,30,2,34,1,1),(3874,4,30,2,35,1,1),(3875,4,30,2,36,1,1),(3876,4,30,2,37,1,1),(3877,4,30,2,38,0,1),(3878,4,30,2,39,0,1),(3879,4,30,2,40,0,1),(3880,4,30,2,41,1,1),(3881,4,30,2,42,1,1),(3882,4,23,2,33,1,1),(3883,4,23,2,34,1,1),(3884,4,23,2,35,1,1),(3885,4,23,2,36,1,1),(3886,4,23,2,37,1,1),(3887,4,23,2,38,0,1),(3888,4,23,2,39,0,1),(3889,4,23,2,40,0,1),(3890,4,23,2,41,1,1),(3891,4,23,2,42,1,1),(3892,4,24,2,33,1,1),(3893,4,24,2,34,1,1),(3894,4,24,2,35,1,1),(3895,4,24,2,36,1,1),(3896,4,24,2,37,1,1),(3897,4,24,2,38,0,1),(3898,4,24,2,39,0,1),(3899,4,24,2,40,0,1),(3900,4,24,2,41,1,1),(3901,4,24,2,42,1,1),(3902,4,22,2,33,1,1),(3903,4,22,2,34,1,1),(3904,4,22,2,35,1,1),(3905,4,22,2,36,1,1),(3906,4,22,2,37,1,1),(3907,4,22,2,38,0,1),(3908,4,22,2,39,0,1),(3909,4,22,2,40,0,1),(3910,4,22,2,41,1,1),(3911,4,22,2,42,1,1),(4093,5,50,3,43,1,1),(4094,5,50,3,44,1,1),(4095,5,50,3,45,1,1),(4096,5,50,3,46,1,1),(4097,5,50,3,47,1,1),(4098,5,50,3,48,1,1),(4099,5,50,3,49,1,1),(4100,5,50,3,50,1,1),(4101,5,50,3,51,1,1),(4102,5,50,3,52,1,1),(4103,5,48,3,43,1,1),(4104,5,48,3,44,1,1),(4105,5,48,3,45,1,1),(4106,5,48,3,46,1,1),(4107,5,48,3,47,1,1),(4108,5,48,3,48,1,1),(4109,5,48,3,49,1,1),(4110,5,48,3,50,1,1),(4111,5,48,3,51,1,1),(4112,5,48,3,52,1,1),(4113,5,55,3,43,1,1),(4114,5,55,3,44,1,1),(4115,5,55,3,45,1,1),(4116,5,55,3,46,1,1),(4117,5,55,3,47,1,1),(4118,5,55,3,48,1,1),(4119,5,55,3,49,1,1),(4120,5,55,3,50,1,1),(4121,5,55,3,51,1,1),(4122,5,55,3,52,1,1),(4123,5,47,3,43,1,1),(4124,5,47,3,44,1,1),(4125,5,47,3,45,1,1),(4126,5,47,3,46,1,1),(4127,5,47,3,47,1,1),(4128,5,47,3,48,1,1),(4129,5,47,3,49,1,1),(4130,5,47,3,50,1,1),(4131,5,47,3,51,1,1),(4132,5,47,3,52,1,1),(4133,5,43,3,43,1,1),(4134,5,43,3,44,1,1),(4135,5,43,3,45,1,1),(4136,5,43,3,46,1,1),(4137,5,43,3,47,1,1),(4138,5,43,3,48,1,1),(4139,5,43,3,49,1,1),(4140,5,43,3,50,1,1),(4141,5,43,3,51,1,1),(4142,5,43,3,52,1,1),(4143,5,42,3,43,1,1),(4144,5,42,3,44,1,1),(4145,5,42,3,45,1,1),(4146,5,42,3,46,1,1),(4147,5,42,3,47,1,1),(4148,5,42,3,48,1,1),(4149,5,42,3,49,1,1),(4150,5,42,3,50,1,1),(4151,5,42,3,51,1,1),(4152,5,42,3,52,1,1),(4153,5,45,3,43,1,1),(4154,5,45,3,44,1,1),(4155,5,45,3,45,1,1),(4156,5,45,3,46,1,1),(4157,5,45,3,47,1,1),(4158,5,45,3,48,1,1),(4159,5,45,3,49,1,1),(4160,5,45,3,50,1,1),(4161,5,45,3,51,1,1),(4162,5,45,3,52,1,1),(4163,5,49,3,43,1,1),(4164,5,49,3,44,1,1),(4165,5,49,3,45,1,1),(4166,5,49,3,46,1,1),(4167,5,49,3,47,1,1),(4168,5,49,3,48,1,1),(4169,5,49,3,49,1,1),(4170,5,49,3,50,1,1),(4171,5,49,3,51,1,1),(4172,5,49,3,52,1,1),(4173,5,44,3,43,1,1),(4174,5,44,3,44,1,1),(4175,5,44,3,45,1,1),(4176,5,44,3,46,1,1),(4177,5,44,3,47,1,1),(4178,5,44,3,48,1,1),(4179,5,44,3,49,1,1),(4180,5,44,3,50,1,1),(4181,5,44,3,51,1,1),(4182,5,44,3,52,1,1),(4183,5,37,3,43,1,1),(4184,5,37,3,44,1,1),(4185,5,37,3,45,1,1),(4186,5,37,3,46,1,1),(4187,5,37,3,47,1,1),(4188,5,37,3,48,1,1),(4189,5,37,3,49,1,1),(4190,5,37,3,50,1,1),(4191,5,37,3,51,1,1),(4192,5,37,3,52,1,1),(4193,5,40,3,43,1,1),(4194,5,40,3,44,1,1),(4195,5,40,3,45,1,1),(4196,5,40,3,46,1,1),(4197,5,40,3,47,1,1),(4198,5,40,3,48,1,1),(4199,5,40,3,49,1,1),(4200,5,40,3,50,1,1),(4201,5,40,3,51,1,1),(4202,5,40,3,52,1,1),(4203,5,39,3,43,1,1),(4204,5,39,3,44,1,1),(4205,5,39,3,45,1,1),(4206,5,39,3,46,1,1),(4207,5,39,3,47,1,1),(4208,5,39,3,48,1,1),(4209,5,39,3,49,1,1),(4210,5,39,3,50,1,1),(4211,5,39,3,51,1,1),(4212,5,39,3,52,1,1),(4213,5,38,3,43,1,1),(4214,5,38,3,44,1,1),(4215,5,38,3,45,1,1),(4216,5,38,3,46,1,1),(4217,5,38,3,47,1,1),(4218,5,38,3,48,1,1),(4219,5,38,3,49,1,1),(4220,5,38,3,50,1,1),(4221,5,38,3,51,1,1),(4222,5,38,3,52,1,1),(4223,5,36,3,43,1,1),(4224,5,36,3,44,1,1),(4225,5,36,3,45,1,1),(4226,5,36,3,46,1,1),(4227,5,36,3,47,1,1),(4228,5,36,3,48,1,1),(4229,5,36,3,49,1,1),(4230,5,36,3,50,1,1),(4231,5,36,3,51,1,1),(4232,5,36,3,52,1,1),(4233,5,41,3,43,1,1),(4234,5,41,3,44,1,1),(4235,5,41,3,45,1,1),(4236,5,41,3,46,0,1),(4237,5,41,3,47,1,1),(4238,5,41,3,48,0,1),(4239,5,41,3,49,0,1),(4240,5,41,3,50,0,1),(4241,5,41,3,51,1,1),(4242,5,41,3,52,1,1),(4243,5,17,1,1,1,1),(4244,5,17,1,2,1,1),(4245,5,17,1,3,1,1),(4246,5,17,1,4,1,1),(4247,5,17,1,5,1,1),(4248,5,17,1,6,1,1),(4249,5,17,1,7,1,1),(4250,5,17,1,8,1,1),(4251,5,17,1,9,1,1),(4252,5,17,1,10,0,1),(4253,5,17,1,11,0,1),(4254,5,17,1,12,0,1),(4255,5,17,1,13,0,1),(4256,5,17,1,14,0,1),(4257,5,17,1,15,0,1),(4258,5,17,1,16,1,1),(4259,5,17,1,17,1,1),(4260,5,17,1,18,1,1),(4261,5,17,1,19,1,1),(4262,5,17,1,20,1,1),(4263,5,17,1,21,1,1),(4264,5,17,1,22,1,1),(4265,5,17,1,23,1,1),(4266,5,17,1,24,1,1),(4267,5,17,1,25,1,1),(4268,5,17,1,26,1,1),(4269,5,17,1,27,1,1),(4270,5,17,1,28,1,1),(4271,5,17,1,29,1,1),(4272,5,17,1,30,1,1),(4273,5,17,1,31,1,1),(4274,5,17,1,32,1,1),(4275,5,16,1,1,1,1),(4276,5,16,1,2,1,1),(4277,5,16,1,3,1,1),(4278,5,16,1,4,1,1),(4279,5,16,1,5,1,1),(4280,5,16,1,6,1,1),(4281,5,16,1,7,1,1),(4282,5,16,1,8,1,1),(4283,5,16,1,9,1,1),(4284,5,16,1,10,0,1),(4285,5,16,1,11,0,1),(4286,5,16,1,12,0,1),(4287,5,16,1,13,0,1),(4288,5,16,1,14,0,1),(4289,5,16,1,15,0,1),(4290,5,16,1,16,1,1),(4291,5,16,1,17,1,1),(4292,5,16,1,18,1,1),(4293,5,16,1,19,1,1),(4294,5,16,1,20,1,1),(4295,5,16,1,21,1,1),(4296,5,16,1,22,1,1),(4297,5,16,1,23,1,1),(4298,5,16,1,24,1,1),(4299,5,16,1,25,1,1),(4300,5,16,1,26,1,1),(4301,5,16,1,27,1,1),(4302,5,16,1,28,1,1),(4303,5,16,1,29,1,1),(4304,5,16,1,30,1,1),(4305,5,16,1,31,1,1),(4306,5,16,1,32,1,1),(4307,5,15,1,1,1,1),(4308,5,15,1,2,1,1),(4309,5,15,1,3,1,1),(4310,5,15,1,4,1,1),(4311,5,15,1,5,1,1),(4312,5,15,1,6,1,1),(4313,5,15,1,7,1,1),(4314,5,15,1,8,1,1),(4315,5,15,1,9,1,1),(4316,5,15,1,10,0,1),(4317,5,15,1,11,0,1),(4318,5,15,1,12,0,1),(4319,5,15,1,13,0,1),(4320,5,15,1,14,0,1),(4321,5,15,1,15,0,1),(4322,5,15,1,16,1,1),(4323,5,15,1,17,1,1),(4324,5,15,1,18,1,1),(4325,5,15,1,19,1,1),(4326,5,15,1,20,1,1),(4327,5,15,1,21,1,1),(4328,5,15,1,22,1,1),(4329,5,15,1,23,1,1),(4330,5,15,1,24,1,1),(4331,5,15,1,25,1,1),(4332,5,15,1,26,1,1),(4333,5,15,1,27,1,1),(4334,5,15,1,28,1,1),(4335,5,15,1,29,1,1),(4336,5,15,1,30,1,1),(4337,5,15,1,31,1,1),(4338,5,15,1,32,1,1),(4339,5,13,1,1,1,1),(4340,5,13,1,2,1,1),(4341,5,13,1,3,1,1),(4342,5,13,1,4,1,1),(4343,5,13,1,5,1,1),(4344,5,13,1,6,1,1),(4345,5,13,1,7,1,1),(4346,5,13,1,8,1,1),(4347,5,13,1,9,1,1),(4348,5,13,1,10,0,1),(4349,5,13,1,11,0,1),(4350,5,13,1,12,0,1),(4351,5,13,1,13,0,1),(4352,5,13,1,14,0,1),(4353,5,13,1,15,0,1),(4354,5,13,1,16,1,1),(4355,5,13,1,17,1,1),(4356,5,13,1,18,1,1),(4357,5,13,1,19,1,1),(4358,5,13,1,20,1,1),(4359,5,13,1,21,1,1),(4360,5,13,1,22,1,1),(4361,5,13,1,23,1,1),(4362,5,13,1,24,1,1),(4363,5,13,1,25,1,1),(4364,5,13,1,26,1,1),(4365,5,13,1,27,1,1),(4366,5,13,1,28,1,1),(4367,5,13,1,29,1,1),(4368,5,13,1,30,1,1),(4369,5,13,1,31,1,1),(4370,5,13,1,32,1,1),(4371,5,14,1,1,1,1),(4372,5,14,1,2,1,1),(4373,5,14,1,3,1,1),(4374,5,14,1,4,1,1),(4375,5,14,1,5,1,1),(4376,5,14,1,6,1,1),(4377,5,14,1,7,1,1),(4378,5,14,1,8,1,1),(4379,5,14,1,9,1,1),(4380,5,14,1,10,0,1),(4381,5,14,1,11,0,1),(4382,5,14,1,12,0,1),(4383,5,14,1,13,0,1),(4384,5,14,1,14,0,1),(4385,5,14,1,15,0,1),(4386,5,14,1,16,1,1),(4387,5,14,1,17,1,1),(4388,5,14,1,18,1,1),(4389,5,14,1,19,1,1),(4390,5,14,1,20,1,1),(4391,5,14,1,21,1,1),(4392,5,14,1,22,1,1),(4393,5,14,1,23,1,1),(4394,5,14,1,24,1,1),(4395,5,14,1,25,1,1),(4396,5,14,1,26,1,1),(4397,5,14,1,27,1,1),(4398,5,14,1,28,1,1),(4399,5,14,1,29,1,1),(4400,5,14,1,30,1,1),(4401,5,14,1,31,1,1),(4402,5,14,1,32,1,1),(4403,5,11,1,1,1,1),(4404,5,11,1,2,1,1),(4405,5,11,1,3,1,1),(4406,5,11,1,4,1,1),(4407,5,11,1,5,1,1),(4408,5,11,1,6,1,1),(4409,5,11,1,7,1,1),(4410,5,11,1,8,1,1),(4411,5,11,1,9,1,1),(4412,5,11,1,10,0,1),(4413,5,11,1,11,0,1),(4414,5,11,1,12,0,1),(4415,5,11,1,13,0,1),(4416,5,11,1,14,0,1),(4417,5,11,1,15,0,1),(4418,5,11,1,16,1,1),(4419,5,11,1,17,1,1),(4420,5,11,1,18,1,1),(4421,5,11,1,19,1,1),(4422,5,11,1,20,1,1),(4423,5,11,1,21,1,1),(4424,5,11,1,22,1,1),(4425,5,11,1,23,1,1),(4426,5,11,1,24,1,1),(4427,5,11,1,25,1,1),(4428,5,11,1,26,1,1),(4429,5,11,1,27,1,1),(4430,5,11,1,28,1,1),(4431,5,11,1,29,1,1),(4432,5,11,1,30,1,1),(4433,5,11,1,31,1,1),(4434,5,11,1,32,1,1),(4435,5,2,1,1,1,1),(4436,5,2,1,2,1,1),(4437,5,2,1,3,1,1),(4438,5,2,1,4,1,1),(4439,5,2,1,5,1,1),(4440,5,2,1,6,1,1),(4441,5,2,1,7,1,1),(4442,5,2,1,8,1,1),(4443,5,2,1,9,1,1),(4444,5,2,1,10,0,1),(4445,5,2,1,11,0,1),(4446,5,2,1,12,0,1),(4447,5,2,1,13,0,1),(4448,5,2,1,14,0,1),(4449,5,2,1,15,0,1),(4450,5,2,1,16,1,1),(4451,5,2,1,17,1,1),(4452,5,2,1,18,1,1),(4453,5,2,1,19,1,1),(4454,5,2,1,20,1,1),(4455,5,2,1,21,1,1),(4456,5,2,1,22,1,1),(4457,5,2,1,23,1,1),(4458,5,2,1,24,1,1),(4459,5,2,1,25,1,1),(4460,5,2,1,26,1,1),(4461,5,2,1,27,1,1),(4462,5,2,1,28,1,1),(4463,5,2,1,29,1,1),(4464,5,2,1,30,1,1),(4465,5,2,1,31,1,1),(4466,5,2,1,32,1,1),(4467,5,1,1,1,1,1),(4468,5,1,1,2,1,1),(4469,5,1,1,3,1,1),(4470,5,1,1,4,1,1),(4471,5,1,1,5,1,1),(4472,5,1,1,6,1,1),(4473,5,1,1,7,1,1),(4474,5,1,1,8,1,1),(4475,5,1,1,9,1,1),(4476,5,1,1,10,0,1),(4477,5,1,1,11,0,1),(4478,5,1,1,12,0,1),(4479,5,1,1,13,0,1),(4480,5,1,1,14,0,1),(4481,5,1,1,15,0,1),(4482,5,1,1,16,1,1),(4483,5,1,1,17,1,1),(4484,5,1,1,18,1,1),(4485,5,1,1,19,1,1),(4486,5,1,1,20,1,1),(4487,5,1,1,21,1,1),(4488,5,1,1,22,1,1),(4489,5,1,1,23,1,1),(4490,5,1,1,24,1,1),(4491,5,1,1,25,1,1),(4492,5,1,1,26,1,1),(4493,5,1,1,27,1,1),(4494,5,1,1,28,1,1),(4495,5,1,1,29,1,1),(4496,5,1,1,30,1,1),(4497,5,1,1,31,1,1),(4498,5,1,1,32,1,1),(4499,5,8,1,1,1,1),(4500,5,8,1,2,1,1),(4501,5,8,1,3,1,1),(4502,5,8,1,4,1,1),(4503,5,8,1,5,1,1),(4504,5,8,1,6,1,1),(4505,5,8,1,7,1,1),(4506,5,8,1,8,1,1),(4507,5,8,1,9,1,1),(4508,5,8,1,10,0,1),(4509,5,8,1,11,0,1),(4510,5,8,1,12,0,1),(4511,5,8,1,13,0,1),(4512,5,8,1,14,0,1),(4513,5,8,1,15,0,1),(4514,5,8,1,16,1,1),(4515,5,8,1,17,1,1),(4516,5,8,1,18,1,1),(4517,5,8,1,19,1,1),(4518,5,8,1,20,1,1),(4519,5,8,1,21,1,1),(4520,5,8,1,22,1,1),(4521,5,8,1,23,1,1),(4522,5,8,1,24,1,1),(4523,5,8,1,25,1,1),(4524,5,8,1,26,1,1),(4525,5,8,1,27,1,1),(4526,5,8,1,28,1,1),(4527,5,8,1,29,1,1),(4528,5,8,1,30,1,1),(4529,5,8,1,31,1,1),(4530,5,8,1,32,1,1),(4531,5,6,1,1,1,1),(4532,5,6,1,2,1,1),(4533,5,6,1,3,1,1),(4534,5,6,1,4,1,1),(4535,5,6,1,5,1,1),(4536,5,6,1,6,1,1),(4537,5,6,1,7,1,1),(4538,5,6,1,8,1,1),(4539,5,6,1,9,1,1),(4540,5,6,1,10,0,1),(4541,5,6,1,11,0,1),(4542,5,6,1,12,0,1),(4543,5,6,1,13,0,1),(4544,5,6,1,14,0,1),(4545,5,6,1,15,0,1),(4546,5,6,1,16,1,1),(4547,5,6,1,17,1,1),(4548,5,6,1,18,1,1),(4549,5,6,1,19,1,1),(4550,5,6,1,20,1,1),(4551,5,6,1,21,1,1),(4552,5,6,1,22,1,1),(4553,5,6,1,23,1,1),(4554,5,6,1,24,1,1),(4555,5,6,1,25,1,1),(4556,5,6,1,26,1,1),(4557,5,6,1,27,1,1),(4558,5,6,1,28,1,1),(4559,5,6,1,29,1,1),(4560,5,6,1,30,1,1),(4561,5,6,1,31,1,1),(4562,5,6,1,32,1,1),(4563,5,4,1,1,1,1),(4564,5,4,1,2,1,1),(4565,5,4,1,3,1,1),(4566,5,4,1,4,1,1),(4567,5,4,1,5,1,1),(4568,5,4,1,6,1,1),(4569,5,4,1,7,1,1),(4570,5,4,1,8,1,1),(4571,5,4,1,9,1,1),(4572,5,4,1,10,0,1),(4573,5,4,1,11,0,1),(4574,5,4,1,12,0,1),(4575,5,4,1,13,0,1),(4576,5,4,1,14,0,1),(4577,5,4,1,15,0,1),(4578,5,4,1,16,1,1),(4579,5,4,1,17,1,1),(4580,5,4,1,18,1,1),(4581,5,4,1,19,1,1),(4582,5,4,1,20,1,1),(4583,5,4,1,21,1,1),(4584,5,4,1,22,1,1),(4585,5,4,1,23,1,1),(4586,5,4,1,24,1,1),(4587,5,4,1,25,1,1),(4588,5,4,1,26,1,1),(4589,5,4,1,27,1,1),(4590,5,4,1,28,1,1),(4591,5,4,1,29,1,1),(4592,5,4,1,30,1,1),(4593,5,4,1,31,1,1),(4594,5,4,1,32,1,1),(4595,5,9,1,1,1,1),(4596,5,9,1,2,1,1),(4597,5,9,1,3,1,1),(4598,5,9,1,4,1,1),(4599,5,9,1,5,1,1),(4600,5,9,1,6,1,1),(4601,5,9,1,7,1,1),(4602,5,9,1,8,1,1),(4603,5,9,1,9,1,1),(4604,5,9,1,10,0,1),(4605,5,9,1,11,0,1),(4606,5,9,1,12,0,1),(4607,5,9,1,13,0,1),(4608,5,9,1,14,0,1),(4609,5,9,1,15,0,1),(4610,5,9,1,16,1,1),(4611,5,9,1,17,1,1),(4612,5,9,1,18,1,1),(4613,5,9,1,19,1,1),(4614,5,9,1,20,1,1),(4615,5,9,1,21,1,1),(4616,5,9,1,22,1,1),(4617,5,9,1,23,1,1),(4618,5,9,1,24,1,1),(4619,5,9,1,25,1,1),(4620,5,9,1,26,1,1),(4621,5,9,1,27,1,1),(4622,5,9,1,28,1,1),(4623,5,9,1,29,1,1),(4624,5,9,1,30,1,1),(4625,5,9,1,31,1,1),(4626,5,9,1,32,1,1),(4627,5,10,1,1,1,1),(4628,5,10,1,2,1,1),(4629,5,10,1,3,1,1),(4630,5,10,1,4,1,1),(4631,5,10,1,5,1,1),(4632,5,10,1,6,1,1),(4633,5,10,1,7,1,1),(4634,5,10,1,8,1,1),(4635,5,10,1,9,1,1),(4636,5,10,1,10,0,1),(4637,5,10,1,11,0,1),(4638,5,10,1,12,0,1),(4639,5,10,1,13,0,1),(4640,5,10,1,14,0,1),(4641,5,10,1,15,0,1),(4642,5,10,1,16,1,1),(4643,5,10,1,17,1,1),(4644,5,10,1,18,1,1),(4645,5,10,1,19,1,1),(4646,5,10,1,20,1,1),(4647,5,10,1,21,1,1),(4648,5,10,1,22,1,1),(4649,5,10,1,23,1,1),(4650,5,10,1,24,1,1),(4651,5,10,1,25,1,1),(4652,5,10,1,26,1,1),(4653,5,10,1,27,1,1),(4654,5,10,1,28,1,1),(4655,5,10,1,29,1,1),(4656,5,10,1,30,1,1),(4657,5,10,1,31,1,1),(4658,5,10,1,32,1,1),(4659,5,3,1,1,1,1),(4660,5,3,1,2,1,1),(4661,5,3,1,3,1,1),(4662,5,3,1,4,1,1),(4663,5,3,1,5,1,1),(4664,5,3,1,6,1,1),(4665,5,3,1,7,1,1),(4666,5,3,1,8,1,1),(4667,5,3,1,9,1,1),(4668,5,3,1,10,0,1),(4669,5,3,1,11,0,1),(4670,5,3,1,12,0,1),(4671,5,3,1,13,0,1),(4672,5,3,1,14,0,1),(4673,5,3,1,15,0,1),(4674,5,3,1,16,1,1),(4675,5,3,1,17,1,1),(4676,5,3,1,18,1,1),(4677,5,3,1,19,1,1),(4678,5,3,1,20,1,1),(4679,5,3,1,21,1,1),(4680,5,3,1,22,1,1),(4681,5,3,1,23,1,1),(4682,5,3,1,24,1,1),(4683,5,3,1,25,1,1),(4684,5,3,1,26,1,1),(4685,5,3,1,27,1,1),(4686,5,3,1,28,1,1),(4687,5,3,1,29,1,1),(4688,5,3,1,30,1,1),(4689,5,3,1,31,1,1),(4690,5,3,1,32,1,1),(4691,5,7,1,1,1,1),(4692,5,7,1,2,1,1),(4693,5,7,1,3,1,1),(4694,5,7,1,4,1,1),(4695,5,7,1,5,1,1),(4696,5,7,1,6,1,1),(4697,5,7,1,7,1,1),(4698,5,7,1,8,1,1),(4699,5,7,1,9,1,1),(4700,5,7,1,10,0,1),(4701,5,7,1,11,0,1),(4702,5,7,1,12,0,1),(4703,5,7,1,13,0,1),(4704,5,7,1,14,0,1),(4705,5,7,1,15,0,1),(4706,5,7,1,16,1,1),(4707,5,7,1,17,1,1),(4708,5,7,1,18,1,1),(4709,5,7,1,19,1,1),(4710,5,7,1,20,1,1),(4711,5,7,1,21,1,1),(4712,5,7,1,22,1,1),(4713,5,7,1,23,1,1),(4714,5,7,1,24,1,1),(4715,5,7,1,25,1,1),(4716,5,7,1,26,1,1),(4717,5,7,1,27,1,1),(4718,5,7,1,28,1,1),(4719,5,7,1,29,1,1),(4720,5,7,1,30,1,1),(4721,5,7,1,31,1,1),(4722,5,7,1,32,1,1),(4723,5,12,1,1,1,1),(4724,5,12,1,2,1,1),(4725,5,12,1,3,1,1),(4726,5,12,1,4,1,1),(4727,5,12,1,5,1,1),(4728,5,12,1,6,1,1),(4729,5,12,1,7,1,1),(4730,5,12,1,8,1,1),(4731,5,12,1,9,1,1),(4732,5,12,1,10,0,1),(4733,5,12,1,11,0,1),(4734,5,12,1,12,0,1),(4735,5,12,1,13,0,1),(4736,5,12,1,14,0,1),(4737,5,12,1,15,0,1),(4738,5,12,1,16,1,1),(4739,5,12,1,17,1,1),(4740,5,12,1,18,1,1),(4741,5,12,1,19,1,1),(4742,5,12,1,20,1,1),(4743,5,12,1,21,1,1),(4744,5,12,1,22,1,1),(4745,5,12,1,23,1,1),(4746,5,12,1,24,1,1),(4747,5,12,1,25,1,1),(4748,5,12,1,26,1,1),(4749,5,12,1,27,1,1),(4750,5,12,1,28,1,1),(4751,5,12,1,29,1,1),(4752,5,12,1,30,1,1),(4753,5,12,1,31,1,1),(4754,5,12,1,32,1,1),(4755,5,60,4,53,1,1),(4756,5,60,4,54,1,1),(4757,5,60,4,55,1,1),(4758,5,60,4,56,1,1),(4759,5,60,4,57,1,1),(4760,5,60,4,58,1,1),(4761,5,60,4,59,1,1),(4762,5,60,4,60,1,1),(4763,5,60,4,61,1,1),(4764,5,60,4,62,1,1),(4765,5,60,4,63,1,1),(4766,5,60,4,64,1,1),(4767,5,60,4,65,1,1),(4768,5,60,4,66,1,1),(4769,5,60,4,67,1,1),(4770,5,60,4,68,1,1),(4771,5,56,4,53,1,1),(4772,5,56,4,54,1,1),(4773,5,56,4,55,1,1),(4774,5,56,4,56,1,1),(4775,5,56,4,57,1,1),(4776,5,56,4,58,1,1),(4777,5,56,4,59,1,1),(4778,5,56,4,60,1,1),(4779,5,56,4,61,1,1),(4780,5,56,4,62,1,1),(4781,5,56,4,63,1,1),(4782,5,56,4,64,1,1),(4783,5,56,4,65,1,1),(4784,5,56,4,66,1,1),(4785,5,56,4,67,1,1),(4786,5,56,4,68,1,1),(4787,5,57,4,53,1,1),(4788,5,57,4,54,1,1),(4789,5,57,4,55,1,1),(4790,5,57,4,56,1,1),(4791,5,57,4,57,1,1),(4792,5,57,4,58,1,1),(4793,5,57,4,59,1,1),(4794,5,57,4,60,1,1),(4795,5,57,4,61,1,1),(4796,5,57,4,62,1,1),(4797,5,57,4,63,1,1),(4798,5,57,4,64,1,1),(4799,5,57,4,65,1,1),(4800,5,57,4,66,1,1),(4801,5,57,4,67,1,1),(4802,5,57,4,68,1,1),(4803,5,58,4,53,1,1),(4804,5,58,4,54,1,1),(4805,5,58,4,55,1,1),(4806,5,58,4,56,1,1),(4807,5,58,4,57,1,1),(4808,5,58,4,58,1,1),(4809,5,58,4,59,1,1),(4810,5,58,4,60,1,1),(4811,5,58,4,61,1,1),(4812,5,58,4,62,1,1),(4813,5,58,4,63,1,1),(4814,5,58,4,64,1,1),(4815,5,58,4,65,1,1),(4816,5,58,4,66,1,1),(4817,5,58,4,67,1,1),(4818,5,58,4,68,1,1),(4819,5,59,4,53,1,1),(4820,5,59,4,54,1,1),(4821,5,59,4,55,1,1),(4822,5,59,4,56,1,1),(4823,5,59,4,57,1,1),(4824,5,59,4,58,1,1),(4825,5,59,4,59,1,1),(4826,5,59,4,60,1,1),(4827,5,59,4,61,1,1),(4828,5,59,4,62,1,1),(4829,5,59,4,63,1,1),(4830,5,59,4,64,1,1),(4831,5,59,4,65,1,1),(4832,5,59,4,66,1,1),(4833,5,59,4,67,1,1),(4834,5,59,4,68,1,1),(4835,5,31,2,33,1,1),(4836,5,31,2,34,1,1),(4837,5,31,2,35,1,1),(4838,5,31,2,36,1,1),(4839,5,31,2,37,1,1),(4840,5,31,2,38,0,1),(4841,5,31,2,39,0,1),(4842,5,31,2,40,0,1),(4843,5,31,2,41,1,1),(4844,5,31,2,42,1,1),(4845,5,28,2,33,1,1),(4846,5,28,2,34,1,1),(4847,5,28,2,35,1,1),(4848,5,28,2,36,1,1),(4849,5,28,2,37,1,1),(4850,5,28,2,38,0,1),(4851,5,28,2,39,0,1),(4852,5,28,2,40,0,1),(4853,5,28,2,41,1,1),(4854,5,28,2,42,1,1),(4855,5,29,2,33,1,1),(4856,5,29,2,34,1,1),(4857,5,29,2,35,1,1),(4858,5,29,2,36,1,1),(4859,5,29,2,37,1,1),(4860,5,29,2,38,0,1),(4861,5,29,2,39,0,1),(4862,5,29,2,40,0,1),(4863,5,29,2,41,1,1),(4864,5,29,2,42,1,1),(4865,5,25,2,33,1,1),(4866,5,25,2,34,1,1),(4867,5,25,2,35,1,1),(4868,5,25,2,36,1,1),(4869,5,25,2,37,1,1),(4870,5,25,2,38,0,1),(4871,5,25,2,39,0,1),(4872,5,25,2,40,0,1),(4873,5,25,2,41,1,1),(4874,5,25,2,42,1,1),(4875,5,26,2,33,1,1),(4876,5,26,2,34,1,1),(4877,5,26,2,35,1,1),(4878,5,26,2,36,1,1),(4879,5,26,2,37,1,1),(4880,5,26,2,38,0,1),(4881,5,26,2,39,0,1),(4882,5,26,2,40,0,1),(4883,5,26,2,41,1,1),(4884,5,26,2,42,1,1),(4885,5,27,2,33,1,1),(4886,5,27,2,34,1,1),(4887,5,27,2,35,1,1),(4888,5,27,2,36,1,1),(4889,5,27,2,37,1,1),(4890,5,27,2,38,0,1),(4891,5,27,2,39,0,1),(4892,5,27,2,40,0,1),(4893,5,27,2,41,1,1),(4894,5,27,2,42,1,1),(4895,5,30,2,33,1,1),(4896,5,30,2,34,1,1),(4897,5,30,2,35,1,1),(4898,5,30,2,36,1,1),(4899,5,30,2,37,1,1),(4900,5,30,2,38,0,1),(4901,5,30,2,39,0,1),(4902,5,30,2,40,0,1),(4903,5,30,2,41,1,1),(4904,5,30,2,42,1,1),(4905,5,23,2,33,1,1),(4906,5,23,2,34,1,1),(4907,5,23,2,35,1,1),(4908,5,23,2,36,1,1),(4909,5,23,2,37,1,1),(4910,5,23,2,38,0,1),(4911,5,23,2,39,0,1),(4912,5,23,2,40,0,1),(4913,5,23,2,41,1,1),(4914,5,23,2,42,1,1),(4915,5,24,2,33,1,1),(4916,5,24,2,34,1,1),(4917,5,24,2,35,1,1),(4918,5,24,2,36,1,1),(4919,5,24,2,37,1,1),(4920,5,24,2,38,0,1),(4921,5,24,2,39,0,1),(4922,5,24,2,40,0,1),(4923,5,24,2,41,1,1),(4924,5,24,2,42,1,1),(4925,5,22,2,33,1,1),(4926,5,22,2,34,1,1),(4927,5,22,2,35,1,1),(4928,5,22,2,36,1,1),(4929,5,22,2,37,1,1),(4930,5,22,2,38,0,1),(4931,5,22,2,39,0,1),(4932,5,22,2,40,0,1),(4933,5,22,2,41,1,1),(4934,5,22,2,42,1,1);
/*!40000 ALTER TABLE `acl_group_bys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_hierarchies`
--

DROP TABLE IF EXISTS `acl_hierarchies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acl_hierarchies` (
  `acl_hierarchy_id` int(11) NOT NULL AUTO_INCREMENT,
  `acl_id` int(11) NOT NULL,
  `hierarchy_id` int(11) NOT NULL,
  `level` int(11) NOT NULL DEFAULT 0,
  `filter_override` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`acl_hierarchy_id`) USING BTREE,
  KEY `idx_aclid_hierarchyid` (`acl_id`,`hierarchy_id`) USING BTREE,
  KEY `idx_hierarchy_id` (`hierarchy_id`),
  CONSTRAINT `fk_ah_acl_id` FOREIGN KEY (`acl_id`) REFERENCES `acls` (`acl_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ah_hierarchy_id` FOREIGN KEY (`hierarchy_id`) REFERENCES `hierarchies` (`hierarchy_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COMMENT='Tracks which `acls` have a relationship with which `hierarchies`';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acl_hierarchies`
--

LOCK TABLES `acl_hierarchies` WRITE;
/*!40000 ALTER TABLE `acl_hierarchies` DISABLE KEYS */;
INSERT INTO `acl_hierarchies` VALUES (1,1,1,0,0),(2,2,1,100,0),(3,3,1,400,0),(4,4,1,200,0),(5,5,1,300,0);
/*!40000 ALTER TABLE `acl_hierarchies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_tabs`
--

DROP TABLE IF EXISTS `acl_tabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acl_tabs` (
  `acl_tab_id` int(11) NOT NULL AUTO_INCREMENT,
  `acl_id` int(11) NOT NULL,
  `tab_id` int(11) NOT NULL,
  `parent_acl_tab_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`acl_tab_id`) USING BTREE,
  KEY `idx_acl_tab` (`acl_id`,`tab_id`),
  KEY `idx_tab_id` (`tab_id`),
  CONSTRAINT `fk_at_acl_id` FOREIGN KEY (`acl_id`) REFERENCES `acls` (`acl_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_at_tab_id` FOREIGN KEY (`tab_id`) REFERENCES `tabs` (`tab_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COMMENT='Tracks which `acls` have a relationship with which `tabs`';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acl_tabs`
--

LOCK TABLES `acl_tabs` WRITE;
/*!40000 ALTER TABLE `acl_tabs` DISABLE KEYS */;
INSERT INTO `acl_tabs` VALUES (1,1,1,NULL),(2,1,2,NULL),(3,1,3,NULL),(4,2,1,NULL),(5,2,2,NULL),(6,2,4,NULL),(7,2,5,NULL),(8,2,6,NULL),(9,2,7,NULL),(10,2,3,NULL),(11,3,1,NULL),(12,3,2,NULL),(13,3,4,NULL),(14,3,5,NULL),(15,3,6,NULL),(16,3,7,NULL),(17,3,3,NULL),(18,4,1,NULL),(19,4,2,NULL),(20,4,4,NULL),(21,4,5,NULL),(22,4,6,NULL),(23,4,7,NULL),(24,4,3,NULL),(25,5,1,NULL),(26,5,2,NULL),(27,5,4,NULL),(28,5,5,NULL),(29,5,6,NULL),(30,5,7,NULL),(31,5,3,NULL);
/*!40000 ALTER TABLE `acl_tabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_types`
--

DROP TABLE IF EXISTS `acl_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acl_types` (
  `acl_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `display` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`acl_type_id`) USING BTREE,
  KEY `idx_module_id` (`module_id`),
  CONSTRAINT `fk_atp_module_id` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COMMENT='Tracks types that pertain only to acls';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acl_types`
--

LOCK TABLES `acl_types` WRITE;
/*!40000 ALTER TABLE `acl_types` DISABLE KEYS */;
INSERT INTO `acl_types` VALUES (1,1,'data','Data'),(2,1,'feature','Feature');
/*!40000 ALTER TABLE `acl_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acls`
--

DROP TABLE IF EXISTS `acls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acls` (
  `acl_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `acl_type_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `display` varchar(1024) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`acl_id`) USING BTREE,
  UNIQUE KEY `idx_module_id_name` (`module_id`,`name`) USING BTREE,
  KEY `idx_type_id` (`acl_type_id`),
  CONSTRAINT `fk_a_acl_type_id` FOREIGN KEY (`acl_type_id`) REFERENCES `acl_types` (`acl_type_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_a_module_id` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COMMENT='Tracks the currently defined `acls`';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acls`
--

LOCK TABLES `acls` WRITE;
/*!40000 ALTER TABLE `acls` DISABLE KEYS */;
INSERT INTO `acls` VALUES (1,1,1,'pub','Public',1),(2,1,1,'usr','User',1),(3,1,1,'cd','Center Director',1),(4,1,1,'pi','Principal Investigator',1),(5,1,1,'cs','Center Staff',1),(6,1,2,'mgr','Manager',1),(7,1,2,'dev','Developer',1);
/*!40000 ALTER TABLE `acls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_export_requests`
--

DROP TABLE IF EXISTS `batch_export_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_export_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'References the user that requested the export.',
  `realm` varchar(255) NOT NULL COMMENT 'The realm from which data will be exported.',
  `start_date` date NOT NULL COMMENT 'Start date for the date range of the data that will be exported.',
  `end_date` date NOT NULL COMMENT 'End date for the date range of the data that will be exported.',
  `export_file_format` enum('CSV','JSON') NOT NULL COMMENT 'File format that will be used to store the exported data.',
  `requested_datetime` datetime NOT NULL COMMENT 'Date and time the export request was created.',
  `export_succeeded` tinyint(1) DEFAULT NULL COMMENT 'True if the export was a success, false if not, null if the request has not yet been processed.',
  `export_created_datetime` datetime DEFAULT NULL COMMENT 'Date and time the export data was generated.',
  `downloaded_datetime` datetime DEFAULT NULL COMMENT 'Date and time of the first download of the exported data.',
  `export_expires_datetime` datetime DEFAULT NULL COMMENT 'Date and time the export data will expire.',
  `export_expired` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'True if the export has expired, false if not.',
  `last_modified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'True if the export has been deleted',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_requested_datetime` (`requested_datetime`),
  KEY `idx_state` (`is_deleted`,`export_succeeded`,`export_expired`,`export_created_datetime`),
  CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Data warehouse batch export requests.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_export_requests`
--

LOCK TABLES `batch_export_requests` WRITE;
/*!40000 ALTER TABLE `batch_export_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_export_requests` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`xdmod`@`localhost`*/ /*!50003 TRIGGER `moddb`.`batch_export_requests_before_insert` BEFORE INSERT ON `moddb`.`batch_export_requests` FOR EACH ROW
 BEGIN
SET NEW.requested_datetime = NOW();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `group_bys`
--

DROP TABLE IF EXISTS `group_bys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_bys` (
  `group_by_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `realm_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`group_by_id`) USING BTREE,
  UNIQUE KEY `idx_module_id_realm_id_name` (`module_id`,`realm_id`,`name`) USING BTREE,
  KEY `idx_module_id` (`module_id`),
  KEY `idx_realm_id` (`realm_id`),
  CONSTRAINT `fk_gb_module_id` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gb_realm_id` FOREIGN KEY (`realm_id`) REFERENCES `realms` (`realm_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1 COMMENT='Tracks which `group_bys` are available to the system';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_bys`
--

LOCK TABLES `group_bys` WRITE;
/*!40000 ALTER TABLE `group_bys` DISABLE KEYS */;
INSERT INTO `group_bys` VALUES (18,1,1,'day'),(8,1,1,'fieldofscience'),(15,1,1,'gpucount'),(16,1,1,'jobsize'),(14,1,1,'jobwaittime'),(13,1,1,'jobwalltime'),(19,1,1,'month'),(11,1,1,'nodecount'),(17,1,1,'none'),(2,1,1,'nsfdirectorate'),(1,1,1,'parentscience'),(7,1,1,'person'),(6,1,1,'pi'),(5,1,1,'provider'),(4,1,1,'qos'),(20,1,1,'quarter'),(9,1,1,'queue'),(10,1,1,'resource'),(3,1,1,'resource_type'),(12,1,1,'username'),(21,1,1,'year'),(32,1,2,'day'),(22,1,2,'fieldofscience'),(33,1,2,'month'),(25,1,2,'mountpoint'),(31,1,2,'none'),(23,1,2,'nsfdirectorate'),(24,1,2,'parentscience'),(26,1,2,'person'),(27,1,2,'pi'),(34,1,2,'quarter'),(28,1,2,'resource'),(29,1,2,'resource_type'),(30,1,2,'username'),(35,1,2,'year'),(55,1,3,'configuration'),(51,1,3,'day'),(37,1,3,'domain'),(39,1,3,'fieldofscience'),(41,1,3,'instance_state'),(52,1,3,'month'),(50,1,3,'none'),(38,1,3,'nsfdirectorate'),(36,1,3,'parentscience'),(49,1,3,'person'),(40,1,3,'pi'),(48,1,3,'project'),(46,1,3,'provider'),(53,1,3,'quarter'),(47,1,3,'resource'),(45,1,3,'submission_venue'),(44,1,3,'username'),(43,1,3,'vm_size'),(42,1,3,'vm_size_memory'),(54,1,3,'year'),(61,1,4,'day'),(62,1,4,'month'),(60,1,4,'none'),(58,1,4,'provider'),(63,1,4,'quarter'),(56,1,4,'resource'),(59,1,4,'resource_allocation_type'),(57,1,4,'resource_type'),(64,1,4,'year');
/*!40000 ALTER TABLE `group_bys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hierarchies`
--

DROP TABLE IF EXISTS `hierarchies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hierarchies` (
  `hierarchy_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `display` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`hierarchy_id`) USING BTREE,
  KEY `idx_module_id` (`module_id`),
  CONSTRAINT `fk_h_module_id` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COMMENT='Tracks the module installed `hierarchies`.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hierarchies`
--

LOCK TABLES `hierarchies` WRITE;
/*!40000 ALTER TABLE `hierarchies` DISABLE KEYS */;
INSERT INTO `hierarchies` VALUES (1,1,'acl_hierarchy','ACL Hierarchy');
/*!40000 ALTER TABLE `hierarchies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_versions`
--

DROP TABLE IF EXISTS `module_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module_versions` (
  `module_version_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `version_major` int(11) NOT NULL DEFAULT 0,
  `version_minor` int(11) NOT NULL DEFAULT 0,
  `version_patch` int(11) NOT NULL DEFAULT 1,
  `version_pre_release` varchar(12) NOT NULL DEFAULT '',
  `created_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_modified_on` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`module_version_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COMMENT='Tracks per module versions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_versions`
--

LOCK TABLES `module_versions` WRITE;
/*!40000 ALTER TABLE `module_versions` DISABLE KEYS */;
INSERT INTO `module_versions` VALUES (1,1,11,0,3,'','2026-07-15 15:07:22','2026-07-15 15:07:22');
/*!40000 ALTER TABLE `module_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `current_version_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `display` varchar(1024) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`module_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COMMENT='Currently installed modules';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,1,'xdmod','Xdmod',1);
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `realms`
--

DROP TABLE IF EXISTS `realms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `realms` (
  `realm_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `display` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`realm_id`) USING BTREE,
  UNIQUE KEY `idx_module_id_name` (`module_id`,`name`) USING BTREE,
  KEY `fk_r_module_id` (`module_id`),
  CONSTRAINT `fk_r_module_id` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COMMENT='Tracks which `realms` are available to the system';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `realms`
--

LOCK TABLES `realms` WRITE;
/*!40000 ALTER TABLE `realms` DISABLE KEYS */;
INSERT INTO `realms` VALUES (1,1,'Jobs','Jobs'),(2,1,'Storage','Storage'),(3,1,'Cloud','Cloud'),(4,1,'ResourceSpecifications','Resource Specifications');
/*!40000 ALTER TABLE `realms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_template_acls`
--

DROP TABLE IF EXISTS `report_template_acls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_template_acls` (
  `report_template_acl_id` int(11) NOT NULL AUTO_INCREMENT,
  `report_template_id` int(11) NOT NULL,
  `acl_id` int(11) NOT NULL,
  UNIQUE KEY `idx_report_template_acl_id` (`report_template_acl_id`) USING BTREE,
  KEY `idx_report_template_id` (`report_template_id`),
  KEY `idx_acl_id` (`acl_id`),
  CONSTRAINT `fk_rta_acl_id` FOREIGN KEY (`acl_id`) REFERENCES `acls` (`acl_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COMMENT='Tracks which acls have access to which report templates.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_template_acls`
--

LOCK TABLES `report_template_acls` WRITE;
/*!40000 ALTER TABLE `report_template_acls` DISABLE KEYS */;
INSERT INTO `report_template_acls` VALUES (1,1,3),(2,2,3),(3,3,5);
/*!40000 ALTER TABLE `report_template_acls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_template_acls_staging`
--

DROP TABLE IF EXISTS `report_template_acls_staging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_template_acls_staging` (
  `template_id` int(11) DEFAULT NULL,
  `acl_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_template_acls_staging`
--

LOCK TABLES `report_template_acls_staging` WRITE;
/*!40000 ALTER TABLE `report_template_acls_staging` DISABLE KEYS */;
INSERT INTO `report_template_acls_staging` VALUES (1,'cd'),(2,'cd'),(3,'cs');
/*!40000 ALTER TABLE `report_template_acls_staging` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resource_type_realms`
--

DROP TABLE IF EXISTS `resource_type_realms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource_type_realms` (
  `resource_type_realm_id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_type_id` int(11) NOT NULL,
  `realm_id` int(11) NOT NULL,
  PRIMARY KEY (`resource_type_realm_id`),
  KEY `idx_resource_type_id_realm_name` (`resource_type_id`,`realm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource_type_realms`
--

LOCK TABLES `resource_type_realms` WRITE;
/*!40000 ALTER TABLE `resource_type_realms` DISABLE KEYS */;
INSERT INTO `resource_type_realms` VALUES (6,1,1),(21,1,1),(36,1,1),(52,1,1),(67,1,1),(82,1,1),(7,1,4),(22,1,4),(37,1,4),(53,1,4),(68,1,4),(83,1,4),(8,2,1),(23,2,1),(38,2,1),(54,2,1),(69,2,1),(84,2,1),(9,2,4),(24,2,4),(39,2,4),(55,2,4),(70,2,4),(85,2,4),(3,3,1),(18,3,1),(33,3,1),(49,3,1),(64,3,1),(79,3,1),(4,3,4),(19,3,4),(34,3,4),(50,3,4),(65,3,4),(80,3,4),(1,5,3),(16,5,3),(31,5,3),(47,5,3),(62,5,3),(77,5,3),(2,5,4),(17,5,4),(32,5,4),(48,5,4),(63,5,4),(78,5,4),(14,6,1),(29,6,1),(44,6,1),(60,6,1),(75,6,1),(90,6,1),(15,6,4),(30,6,4),(45,6,4),(61,6,4),(76,6,4),(91,6,4),(12,7,3),(27,7,3),(42,7,3),(58,7,3),(73,7,3),(88,7,3),(13,7,4),(28,7,4),(43,7,4),(59,7,4),(74,7,4),(89,7,4),(11,8,2),(26,8,2),(41,8,2),(57,8,2),(72,8,2),(87,8,2),(5,9,2),(20,9,2),(35,9,2),(51,9,2),(66,9,2),(81,9,2),(10,10,2),(25,10,2),(40,10,2),(56,10,2),(71,10,2),(86,10,2);
/*!40000 ALTER TABLE `resource_type_realms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statistics`
--

DROP TABLE IF EXISTS `statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statistics` (
  `statistic_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `realm_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`statistic_id`) USING BTREE,
  UNIQUE KEY `idx_module_id_realm_id_name` (`module_id`,`realm_id`,`name`) USING BTREE,
  KEY `idx_module_id` (`module_id`),
  KEY `idx_realm_id` (`realm_id`),
  CONSTRAINT `fk_s_module_id` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_s_realm_id` FOREIGN KEY (`realm_id`) REFERENCES `realms` (`realm_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1 COMMENT='Tracks all of the `statistics` currently available to the system';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statistics`
--

LOCK TABLES `statistics` WRITE;
/*!40000 ALTER TABLE `statistics` DISABLE KEYS */;
INSERT INTO `statistics` VALUES (1,1,1,'active_person_count'),(17,1,1,'active_pi_count'),(31,1,1,'active_resource_count'),(30,1,1,'avg_cpu_hours'),(24,1,1,'avg_gpus'),(29,1,1,'avg_gpu_hours'),(28,1,1,'avg_job_size_weighted_by_cpu_hours'),(27,1,1,'avg_job_size_weighted_by_gpu_hours'),(26,1,1,'avg_node_hours'),(25,1,1,'avg_processors'),(23,1,1,'avg_waitduration_hours'),(22,1,1,'avg_wallduration_hours'),(21,1,1,'expansion_factor'),(20,1,1,'job_count'),(19,1,1,'max_processors'),(18,1,1,'min_processors'),(16,1,1,'normalized_avg_processors'),(2,1,1,'running_job_count'),(15,1,1,'sem_avg_cpu_hours'),(12,1,1,'sem_avg_gpus'),(14,1,1,'sem_avg_node_hours'),(13,1,1,'sem_avg_processors'),(11,1,1,'sem_avg_waitduration_hours'),(10,1,1,'sem_avg_wallduration_hours'),(9,1,1,'started_job_count'),(8,1,1,'submitted_job_count'),(7,1,1,'total_cpu_hours'),(6,1,1,'total_gpu_hours'),(5,1,1,'total_node_hours'),(4,1,1,'total_waitduration_hours'),(3,1,1,'total_wallduration_hours'),(32,1,1,'utilization'),(34,1,2,'avg_file_count'),(35,1,2,'avg_hard_threshold'),(36,1,2,'avg_logical_usage'),(33,1,2,'avg_logical_utilization'),(37,1,2,'avg_physical_usage'),(41,1,2,'avg_soft_threshold'),(38,1,2,'sem_file_count'),(39,1,2,'sem_logical_usage'),(40,1,2,'sem_physical_usage'),(42,1,2,'user_count'),(43,1,3,'cloud_avg_cores_reserved'),(44,1,3,'cloud_avg_memory_reserved'),(45,1,3,'cloud_avg_rv_storage_reserved'),(46,1,3,'cloud_avg_wallduration_hours'),(47,1,3,'cloud_core_time'),(52,1,3,'cloud_core_utilization'),(48,1,3,'cloud_num_sessions_ended'),(49,1,3,'cloud_num_sessions_running'),(50,1,3,'cloud_num_sessions_started'),(51,1,3,'cloud_wall_time'),(66,1,4,'allocated_avg_number_of_cpu_cores'),(62,1,4,'allocated_avg_number_of_cpu_nodes'),(68,1,4,'allocated_avg_number_of_gpus'),(64,1,4,'allocated_avg_number_of_gpu_nodes'),(54,1,4,'allocated_cpu_core_hours'),(58,1,4,'allocated_cpu_node_hours'),(56,1,4,'allocated_gpu_hours'),(60,1,4,'allocated_gpu_node_hours'),(65,1,4,'total_avg_number_of_cpu_cores'),(61,1,4,'total_avg_number_of_cpu_nodes'),(67,1,4,'total_avg_number_of_gpus'),(63,1,4,'total_avg_number_of_gpu_nodes'),(53,1,4,'total_cpu_core_hours'),(57,1,4,'total_cpu_node_hours'),(55,1,4,'total_gpu_hours'),(59,1,4,'total_gpu_node_hours');
/*!40000 ALTER TABLE `statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabs`
--

DROP TABLE IF EXISTS `tabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabs` (
  `tab_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `parent_tab_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`tab_id`) USING BTREE,
  KEY `idx_module_id` (`module_id`),
  KEY `idx_parent_tab_id` (`parent_tab_id`),
  CONSTRAINT `fk_t_module_id` FOREIGN KEY (`module_id`) REFERENCES `modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_t_parent_tab_id` FOREIGN KEY (`parent_tab_id`) REFERENCES `tabs` (`tab_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COMMENT='Tracks which `tabs` are available to the system';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabs`
--

LOCK TABLES `tabs` WRITE;
/*!40000 ALTER TABLE `tabs` DISABLE KEYS */;
INSERT INTO `tabs` VALUES (1,1,NULL,'tg_summary'),(2,1,NULL,'tg_usage'),(3,1,NULL,'about_xdmod'),(4,1,NULL,'metric_explorer'),(5,1,NULL,'data_export'),(6,1,NULL,'report_generator'),(7,1,NULL,'job_viewer');
/*!40000 ALTER TABLE `tabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_acl_group_by_parameters`
--

DROP TABLE IF EXISTS `user_acl_group_by_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_acl_group_by_parameters` (
  `user_acl_parameter_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `acl_id` int(11) DEFAULT NULL,
  `group_by_id` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_acl_parameter_id`) USING BTREE,
  KEY `idx_user_id` (`user_id`),
  KEY `idx_acl_id` (`acl_id`),
  KEY `idx_group_by_id` (`group_by_id`),
  CONSTRAINT `fk_uagbp_acl_id` FOREIGN KEY (`acl_id`) REFERENCES `acls` (`acl_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uagbp_group_by_id` FOREIGN KEY (`group_by_id`) REFERENCES `group_bys` (`group_by_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uagbp_user_id` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1 COMMENT='Tracks which `Users` have which `acls`';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_acl_group_by_parameters`
--

LOCK TABLES `user_acl_group_by_parameters` WRITE;
/*!40000 ALTER TABLE `user_acl_group_by_parameters` DISABLE KEYS */;
INSERT INTO `user_acl_group_by_parameters` VALUES (1,2,2,7,-1),(2,2,2,26,-1),(3,2,2,49,-1),(7,3,2,7,97),(8,3,2,26,97),(9,3,2,49,97),(10,3,3,5,1),(11,3,3,46,1),(12,3,3,58,1),(16,4,2,7,111),(17,4,2,26,111),(18,4,2,49,111),(19,4,5,5,1),(20,4,5,46,1),(21,4,5,58,1),(22,5,4,6,9),(23,5,4,27,9),(24,5,4,40,9),(25,5,2,7,9),(26,5,2,26,9),(27,5,2,49,9),(28,6,2,7,114),(29,6,2,26,114),(30,6,2,49,114);
/*!40000 ALTER TABLE `user_acl_group_by_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_acls`
--

DROP TABLE IF EXISTS `user_acls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_acls` (
  `user_acl_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `acl_id` int(11) NOT NULL,
  PRIMARY KEY (`user_acl_id`) USING BTREE,
  UNIQUE KEY `idx_user_id_acl_id` (`user_id`,`acl_id`) USING BTREE,
  KEY `idx_user_id` (`user_id`),
  KEY `idx_acl_id` (`acl_id`),
  CONSTRAINT `fk_ua_acl_id` FOREIGN KEY (`acl_id`) REFERENCES `acls` (`acl_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ua_user_id` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COMMENT='Tracks which `Users` have which `acls`';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_acls`
--

LOCK TABLES `user_acls` WRITE;
/*!40000 ALTER TABLE `user_acls` DISABLE KEYS */;
INSERT INTO `user_acls` VALUES (2,1,1),(3,2,2),(1,2,6),(5,3,2),(4,3,3),(7,4,2),(6,4,5),(9,5,2),(8,5,4),(10,6,2);
/*!40000 ALTER TABLE `user_acls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_tokens`
--

DROP TABLE IF EXISTS `user_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_tokens` (
  `user_token_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(512) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expires_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_token_id`) USING BTREE,
  UNIQUE KEY `idx_user_id` (`user_id`) USING BTREE,
  CONSTRAINT `fk_ut_user_id` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Tracks XDMoD Users API tokens for use with Data Analytics Framework endpoints.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_tokens`
--

LOCK TABLES `user_tokens` WRITE;
/*!40000 ALTER TABLE `user_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'moddb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-15 15:38:51
